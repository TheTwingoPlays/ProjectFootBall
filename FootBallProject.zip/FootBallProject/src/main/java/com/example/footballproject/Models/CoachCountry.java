package com.example.footballproject.Models;

public enum CoachCountry {
    ARGENTINA,
    BELGIUM,
    BRAZIL,
    CROATIA,
    ENGLAND,
    FRANCE,
    GERMANY,
    ITALY,
    MOLDOVA,
    NETHERLANDS,
    POLAND,
    PORTUGAL,
    ROMANIA,
    SPAIN,
    UKRAINE,
    URUGUAY,
    USA;

    @Override
    public String toString() {
        String text = name().toLowerCase().replace("_", " ");
        return text.substring(0, 1).toUpperCase() + text.substring(1);
    }
}
