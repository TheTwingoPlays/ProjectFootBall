package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.sql.SQLException;

public class TicketDialogController {

    @FXML private Label titleLabel;
    @FXML private ComboBox<OptionItem> gameComboBox;
    @FXML private TextField standardPriceField;
    @FXML private TextField vipPriceField;
    @FXML private TextField childPriceField;
    @FXML private ComboBox<String> statusComboBox;

    private boolean saved;
    private boolean editMode;
    private int editingTicketId = -1;

    @FXML
    private void initialize() {
        loadOptions();
        onlyDecimal(standardPriceField);
        onlyDecimal(vipPriceField);
        onlyDecimal(childPriceField);
        statusComboBox.setItems(FXCollections.observableArrayList("Доступен", "Продан"));
        statusComboBox.setValue("Доступен");
    }

    public void setEditTicketId(int ticketId) {
        editMode = true;
        editingTicketId = ticketId;
        titleLabel.setText("Редактировать тариф билета");
        loadTariffs(ticketId);
    }

    public boolean isSaved() {
        return saved;
    }

    private void loadOptions() {
        try {
            gameComboBox.setItems(DatabaseHandler.getGamesOptions());
        } catch (SQLException e) {
            showError("Ошибка загрузки данных: " + e.getMessage());
        }
    }

    private void loadTariffs(int ticketId) {
        try {
            Integer gameId = DatabaseHandler.getTicketById(ticketId).getGameId();
            selectOptionById(gameComboBox, gameId);

            if (gameId != null) {
                BigDecimal standardPrice = DatabaseHandler.findTicketTariffPrice(gameId, "Standard");
                BigDecimal vipPrice = DatabaseHandler.findTicketTariffPrice(gameId, "VIP");
                BigDecimal childPrice = DatabaseHandler.findTicketTariffPrice(gameId, "Child");

                standardPriceField.setText(standardPrice == null ? "" : standardPrice.toPlainString());
                vipPriceField.setText(vipPrice == null ? "" : vipPrice.toPlainString());
                childPriceField.setText(childPrice == null ? "" : childPrice.toPlainString());
            }
        } catch (SQLException e) {
            showError("Ошибка загрузки тарифов: " + e.getMessage());
        }
    }

    private void selectOptionById(ComboBox<OptionItem> comboBox, Integer id) {
        if (id == null) {
            comboBox.setValue(null);
            return;
        }

        for (OptionItem item : comboBox.getItems()) {
            if (item.getId() == id) {
                comboBox.setValue(item);
                return;
            }
        }
    }

    private void onlyNumbers(TextField field) {
        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.matches("\\d*")) {
                field.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    private void onlyDecimal(TextField field) {
        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.matches("\\d*(\\.\\d*)?")) {
                field.setText(oldValue);
            }
        });
    }

    @FXML
    private void handleSave() {
        if (!validateFields()) {
            return;
        }

        OptionItem game = gameComboBox.getValue();
        boolean available = "Доступен".equals(statusComboBox.getValue());

        try {
            DatabaseHandler.saveTicketTariffs(
                    game.getId(),
                    parsePrice(standardPriceField),
                    parsePrice(vipPriceField),
                    parsePrice(childPriceField),
                    available
            );

            saved = true;
            closeWindow();
        } catch (SQLException e) {
            showError("Ошибка сохранения билета: " + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (gameComboBox.getValue() == null) {
            showError("Выберите матч.");
            return false;
        }

        if (standardPriceField.getText().trim().isEmpty()
                && vipPriceField.getText().trim().isEmpty()
                && childPriceField.getText().trim().isEmpty()) {
            showError("Введите цену хотя бы для одного типа билета.");
            return false;
        }

        return validatePrice(standardPriceField, "Standard")
                && validatePrice(vipPriceField, "VIP")
                && validatePrice(childPriceField, "Child");
    }

    private boolean validatePrice(TextField field, String type) {
        if (field.getText().trim().isEmpty()) {
            return true;
        }

        BigDecimal price;
        try {
            price = new BigDecimal(field.getText().trim());
        } catch (NumberFormatException e) {
            showError("Введите корректную цену для " + type + ".");
            return false;
        }

        if (price.compareTo(BigDecimal.ZERO) <= 0) {
            showError("Цена для " + type + " должна быть больше 0.");
            return false;
        }

        return true;
    }

    private BigDecimal parsePrice(TextField field) {
        if (field.getText().trim().isEmpty()) {
            return null;
        }

        return new BigDecimal(field.getText().trim());
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) titleLabel.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
