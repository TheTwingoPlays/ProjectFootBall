package com.example.footballproject.Models;

public enum CoachLicenseType {
    UEFA_PRO("UEFA Pro"),
    UEFA_A("UEFA A"),
    UEFA_B("UEFA B"),
    UEFA_C("UEFA C"),
    NATIONAL_LICENSE("National License"),
    WITHOUT_LICENSE("Без лицензии");

    private final String title;

    CoachLicenseType(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return title;
    }
}
