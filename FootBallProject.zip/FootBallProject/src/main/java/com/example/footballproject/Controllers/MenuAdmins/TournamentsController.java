package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.TournamentModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;

public class TournamentsController {

    @FXML private TextField searchField;
    @FXML private ComboBox<OptionItem> teamFilterComboBox;
    @FXML private ComboBox<String> countryFilterComboBox;
    @FXML private ComboBox<OptionItem> stadiumFilterComboBox;

    @FXML private TableView<TournamentModel> tournamentsTable;

    @FXML private TableColumn<TournamentModel, Integer> colId;
    @FXML private TableColumn<TournamentModel, String> colName;
    @FXML private TableColumn<TournamentModel, Integer> colTeamsCount;
    @FXML private TableColumn<TournamentModel, Integer> colStadiumsCount;
    @FXML private TableColumn<TournamentModel, String> colTeams;
    @FXML private TableColumn<TournamentModel, String> colStadiums;

    @FXML
    private void initialize() {
        setupTable();
        loadFilters();
        loadTournaments();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colTeamsCount.setCellValueFactory(new PropertyValueFactory<>("teamsCount"));
        colStadiumsCount.setCellValueFactory(new PropertyValueFactory<>("stadiumsCount"));
        colTeams.setCellValueFactory(new PropertyValueFactory<>("teams"));
        colStadiums.setCellValueFactory(new PropertyValueFactory<>("stadiums"));
    }

    private void loadFilters() {
        try {
            teamFilterComboBox.setItems(DatabaseHandler.getTeamsOptions());
            countryFilterComboBox.setItems(DatabaseHandler.getTournamentTeamCountries());
            stadiumFilterComboBox.setItems(DatabaseHandler.getStadiumsOptions());
        } catch (SQLException e) {
            showError("Ошибка загрузки фильтров: " + e.getMessage());
        }
    }

    private void loadTournaments() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();

            OptionItem team = teamFilterComboBox.getValue();
            Integer teamId = team == null ? null : team.getId();

            String country = countryFilterComboBox.getValue();

            OptionItem stadium = stadiumFilterComboBox.getValue();
            Integer stadiumId = stadium == null ? null : stadium.getId();

            ObservableList<TournamentModel> tournaments = DatabaseHandler.getTournaments(keyword, teamId, stadiumId, country);

            tournamentsTable.getItems().clear();
            tournamentsTable.setItems(tournaments);
            tournamentsTable.refresh();
        } catch (SQLException e) {
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        loadTournaments();
    }

    @FXML
    private void handleFilter() {
        loadTournaments();
    }

    @FXML
    private void handleClearFilters() {
        searchField.clear();
        teamFilterComboBox.setValue(null);
        countryFilterComboBox.setValue(null);
        stadiumFilterComboBox.setValue(null);
        loadTournaments();
    }

    @FXML
    private void handleAdd() {
        openTournamentDialog(null);
    }

    @FXML
    private void handleEdit() {
        TournamentModel selectedTournament = tournamentsTable.getSelectionModel().getSelectedItem();

        if (selectedTournament == null) {
            showWarning("Выберите турнир для изменения.");
            return;
        }

        openTournamentDialog(selectedTournament.getId());
    }

    @FXML
    private void handleDelete() {
        TournamentModel selectedTournament = tournamentsTable.getSelectionModel().getSelectedItem();

        if (selectedTournament == null) {
            showWarning("Выберите турнир для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление турнира");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Удалить турнир \"" + selectedTournament.getName() + "\"?\n\n" +
                        "Связи с командами и стадионами будут удалены."
        );

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedTournament(selectedTournament);
            }
        });
    }

    private void openTournamentDialog(Integer tournamentId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/footballproject/MenuFxml/TournamentDialog.fxml"));
            Parent root = loader.load();

            TournamentDialogController controller = loader.getController();

            if (tournamentId != null) {
                controller.setEditTournamentId(tournamentId);
            }

            Stage stage = new Stage();
            stage.setTitle(tournamentId == null ? "Добавить турнир" : "Редактировать турнир");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadFilters();
                loadTournaments();
                showInfo("Успешно", tournamentId == null ? "Турнир добавлен." : "Турнир обновлён.");
            }
        } catch (Exception e) {
            showError("Не удалось открыть окно турнира: " + e.getMessage());
        }
    }

    private void deleteSelectedTournament(TournamentModel tournament) {
        try {
            DatabaseHandler.deleteTournamentById(tournament.getId());
            loadFilters();
            loadTournaments();
            showInfo("Успешно", "Турнир удалён.");
        } catch (SQLException e) {
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
