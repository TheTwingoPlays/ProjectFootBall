package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.TicketModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.sql.SQLException;

public class TicketsController {

    @FXML private TextField searchField;
    @FXML private ComboBox<OptionItem> gameFilterComboBox;
    @FXML private ComboBox<String> typeFilterComboBox;
    @FXML private ComboBox<String> sectorFilterComboBox;
    @FXML private ComboBox<String> statusFilterComboBox;

    @FXML private TableView<TicketModel> ticketsTable;

    @FXML private TableColumn<TicketModel, Integer> colId;
    @FXML private TableColumn<TicketModel, String> colGame;
    @FXML private TableColumn<TicketModel, String> colType;
    @FXML private TableColumn<TicketModel, BigDecimal> colCost;
    @FXML private TableColumn<TicketModel, String> colPlace;
    @FXML private TableColumn<TicketModel, String> colRow;
    @FXML private TableColumn<TicketModel, String> colSector;
    @FXML private TableColumn<TicketModel, String> colStatus;

    @FXML
    private void initialize() {
        setupTable();
        loadFilters();
        loadTickets();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colGame.setCellValueFactory(new PropertyValueFactory<>("gameName"));
        colType.setCellValueFactory(new PropertyValueFactory<>("type"));
        colCost.setCellValueFactory(new PropertyValueFactory<>("cost"));
        colPlace.setCellValueFactory(new PropertyValueFactory<>("placeText"));
        colRow.setCellValueFactory(new PropertyValueFactory<>("rowText"));
        colSector.setCellValueFactory(new PropertyValueFactory<>("sectorText"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("statusText"));

        colStatus.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);

                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                    return;
                }

                setText(status);
                setStyle("Доступен".equals(status)
                        ? "-fx-text-fill: #20934b; -fx-font-weight: 900;"
                        : "-fx-text-fill: #b42323; -fx-font-weight: 900;");
            }
        });
    }

    private void loadFilters() {
        try {
            gameFilterComboBox.setItems(DatabaseHandler.getGamesOptions());
            typeFilterComboBox.setItems(DatabaseHandler.getTicketTypes());
            sectorFilterComboBox.setItems(DatabaseHandler.getTicketSectors());
            statusFilterComboBox.setItems(FXCollections.observableArrayList("Доступен", "Продан"));
        } catch (SQLException e) {
            showError("Ошибка загрузки фильтров: " + e.getMessage());
        }
    }

    private void loadTickets() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();

            OptionItem game = gameFilterComboBox.getValue();
            Integer gameId = game == null ? null : game.getId();

            String type = typeFilterComboBox.getValue();
            String sector = sectorFilterComboBox.getValue();
            Boolean available = null;

            if ("Доступен".equals(statusFilterComboBox.getValue())) {
                available = true;
            } else if ("Продан".equals(statusFilterComboBox.getValue())) {
                available = false;
            }

            ObservableList<TicketModel> tickets = DatabaseHandler.getTickets(keyword, gameId, type, sector, available);

            ticketsTable.getItems().clear();
            ticketsTable.setItems(tickets);
            ticketsTable.refresh();
        } catch (SQLException e) {
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        loadTickets();
    }

    @FXML
    private void handleFilter() {
        loadTickets();
    }

    @FXML
    private void handleClearFilters() {
        searchField.clear();
        gameFilterComboBox.setValue(null);
        typeFilterComboBox.setValue(null);
        sectorFilterComboBox.setValue(null);
        statusFilterComboBox.setValue(null);
        loadTickets();
    }

    @FXML
    private void handleAdd() {
        openTicketDialog(null);
    }

    @FXML
    private void handleEdit() {
        TicketModel selectedTicket = ticketsTable.getSelectionModel().getSelectedItem();

        if (selectedTicket == null) {
            showWarning("Выберите билет для изменения.");
            return;
        }

        openTicketDialog(selectedTicket.getId());
    }

    @FXML
    private void handleDelete() {
        TicketModel selectedTicket = ticketsTable.getSelectionModel().getSelectedItem();

        if (selectedTicket == null) {
            showWarning("Выберите билет для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление билета");
        confirm.setHeaderText(null);
        confirm.setContentText("Удалить билет #" + selectedTicket.getId() + "?");

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);
        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedTicket(selectedTicket);
            }
        });
    }

    private void openTicketDialog(Integer ticketId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/footballproject/MenuFxml/TicketDialog.fxml"));
            Parent root = loader.load();

            TicketDialogController controller = loader.getController();

            if (ticketId != null) {
                controller.setEditTicketId(ticketId);
            }

            Stage stage = new Stage();
            stage.setTitle(ticketId == null ? "Добавить билет" : "Редактировать билет");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadFilters();
                loadTickets();
                showInfo("Успешно", ticketId == null ? "Билет добавлен." : "Билет обновлён.");
            }
        } catch (Exception e) {
            showError("Не удалось открыть окно билета: " + e.getMessage());
        }
    }

    private void deleteSelectedTicket(TicketModel ticket) {
        try {
            DatabaseHandler.deleteTicketById(ticket.getId());
            loadFilters();
            loadTickets();
            showInfo("Успешно", "Билет удалён.");
        } catch (SQLException e) {
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
