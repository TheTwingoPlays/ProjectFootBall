package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.PlayerModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;

public class PlayersController {

    @FXML private TextField searchField;

    @FXML private ComboBox<OptionItem> teamFilterComboBox;
    @FXML private ComboBox<String> positionFilterComboBox;
    @FXML private ComboBox<String> statusFilterComboBox;
    @FXML private ComboBox<String> nationalityFilterComboBox;

    @FXML private TableView<PlayerModel> playersTable;

    @FXML private TableColumn<PlayerModel, Integer> colId;
    @FXML private TableColumn<PlayerModel, String> colFullName;
    @FXML private TableColumn<PlayerModel, String> colTeam;
    @FXML private TableColumn<PlayerModel, String> colPosition;
    @FXML private TableColumn<PlayerModel, Integer> colNumber;
    @FXML private TableColumn<PlayerModel, Integer> colAge;
    @FXML private TableColumn<PlayerModel, String> colNationality;
    @FXML private TableColumn<PlayerModel, Integer> colGoals;
    @FXML private TableColumn<PlayerModel, Integer> colAssists;
    @FXML private TableColumn<PlayerModel, Integer> colYellowCards;
    @FXML private TableColumn<PlayerModel, Integer> colRedCards;
    @FXML private TableColumn<PlayerModel, String> colStatus;

    @FXML
    public void initialize() {
        setupTable();
        loadFilters();
        loadPlayers();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colFullName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colTeam.setCellValueFactory(new PropertyValueFactory<>("teamName"));
        colPosition.setCellValueFactory(new PropertyValueFactory<>("position"));
        colNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colNationality.setCellValueFactory(new PropertyValueFactory<>("nationality"));
        colGoals.setCellValueFactory(new PropertyValueFactory<>("goals"));
        colAssists.setCellValueFactory(new PropertyValueFactory<>("assists"));
        colYellowCards.setCellValueFactory(new PropertyValueFactory<>("yellowCards"));
        colRedCards.setCellValueFactory(new PropertyValueFactory<>("redCards"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("statusText"));

        colStatus.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);

                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                    return;
                }

                setText(status);

                if ("Травмирован".equals(status)) {
                    setStyle("-fx-text-fill: #c14444; -fx-font-weight: 900;");
                } else {
                    setStyle("-fx-text-fill: #3a5a40; -fx-font-weight: 900;");
                }
            }
        });
    }

    private void loadFilters() {
        try {
            teamFilterComboBox.setItems(DatabaseHandler.getTeamsOptions());

            positionFilterComboBox.setItems(FXCollections.observableArrayList(
                    "Вратарь",
                    "Защитник",
                    "Полузащитник",
                    "Нападающий"
            ));

            statusFilterComboBox.setItems(FXCollections.observableArrayList(
                    "Активен",
                    "Травмирован"
            ));

            nationalityFilterComboBox.setItems(DatabaseHandler.getPlayerNationalities());

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки фильтров: " + e.getMessage());
        }
    }

    private void loadPlayers() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();

            OptionItem team = teamFilterComboBox.getValue();
            Integer teamId = team == null ? null : team.getId();

            String position = positionFilterComboBox.getValue();

            String status = null;
            if ("Активен".equals(statusFilterComboBox.getValue())) {
                status = "ACTIVE";
            } else if ("Травмирован".equals(statusFilterComboBox.getValue())) {
                status = "INJURED";
            }

            String nationality = nationalityFilterComboBox.getValue();

            ObservableList<PlayerModel> players = DatabaseHandler.getPlayers(
                    keyword,
                    teamId,
                    position,
                    status,
                    nationality
            );

            playersTable.getItems().clear();
            playersTable.setItems(players);
            playersTable.refresh();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        loadPlayers();
    }

    @FXML
    private void handleFilter() {
        loadPlayers();
    }

    @FXML
    private void handleClearFilters() {
        searchField.clear();
        teamFilterComboBox.setValue(null);
        positionFilterComboBox.setValue(null);
        statusFilterComboBox.setValue(null);
        nationalityFilterComboBox.setValue(null);
        loadPlayers();
    }

    @FXML
    private void handleAdd() {
        openPlayerDialog(null);
    }

    @FXML
    private void handleEdit() {
        PlayerModel selectedPlayer = playersTable.getSelectionModel().getSelectedItem();

        if (selectedPlayer == null) {
            showWarning("Выберите игрока для изменения.");
            return;
        }

        openPlayerDialog(selectedPlayer.getId());
    }

    private void openPlayerDialog(Integer playerId) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/footballproject/MenuFxml/PlayerDialog.fxml")
            );

            Parent root = loader.load();

            PlayerDialogController controller = loader.getController();

            if (playerId != null) {
                controller.setEditPlayerId(playerId);
            }

            Stage stage = new Stage();
            stage.setTitle(playerId == null ? "Добавить игрока" : "Редактировать игрока");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadPlayers();
                showInfo("Успешно", playerId == null ? "Игрок добавлен." : "Игрок обновлён.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Не удалось открыть окно игрока: " + e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        PlayerModel selectedPlayer = playersTable.getSelectionModel().getSelectedItem();

        if (selectedPlayer == null) {
            showWarning("Выберите игрока для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление игрока");
        confirm.setHeaderText(null);
        confirm.setContentText("Удалить игрока \"" + selectedPlayer.getFullName() + "\"?");

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedPlayer(selectedPlayer);
            }
        });
    }

    private void deleteSelectedPlayer(PlayerModel player) {
        try {
            DatabaseHandler.deletePlayerById(player.getId());
            loadPlayers();
            showInfo("Успешно", "Игрок удалён.");

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
