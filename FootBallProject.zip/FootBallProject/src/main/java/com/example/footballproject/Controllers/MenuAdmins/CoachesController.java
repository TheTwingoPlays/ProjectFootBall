package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.CoachModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.function.Function;

public class CoachesController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> teamFilterComboBox;
    @FXML private ComboBox<String> positionFilterComboBox;
    @FXML private ComboBox<String> countryFilterComboBox;
    @FXML private ComboBox<String> statusFilterComboBox;
    @FXML private ComboBox<String> licenseFilterComboBox;
    @FXML private TableView<CoachModel> coachesTable;

    @FXML private TableColumn<CoachModel, Integer> idCoachColumn;
    @FXML private TableColumn<CoachModel, String> fullNameColumn;
    @FXML private TableColumn<CoachModel, String> teamColumn;
    @FXML private TableColumn<CoachModel, String> positionColumn;
    @FXML private TableColumn<CoachModel, Integer> ageColumn;
    @FXML private TableColumn<CoachModel, String> countryColumn;
    @FXML private TableColumn<CoachModel, Integer> experienceColumn;
    @FXML private TableColumn<CoachModel, String> statusColumn;
    @FXML private TableColumn<CoachModel, String> licenseColumn;

    private final ObservableList<CoachModel> allCoaches = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        setupTable();
        loadCoaches();

        searchField.textProperty().addListener((observable, oldValue, newValue) -> filterCoaches());
    }

    private void setupTable() {
        idCoachColumn.setCellValueFactory(new PropertyValueFactory<>("idCoach"));
        fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        teamColumn.setCellValueFactory(new PropertyValueFactory<>("teamName"));
        positionColumn.setCellValueFactory(new PropertyValueFactory<>("positionTitle"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
        countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
        experienceColumn.setCellValueFactory(new PropertyValueFactory<>("experienceYears"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("statusTitle"));
        licenseColumn.setCellValueFactory(new PropertyValueFactory<>("licenseTypeTitle"));
    }

    private Connection getConnection() throws Exception {
        return DatabaseHandler.getConnection();
    }

    private void loadCoaches() {
        allCoaches.clear();

        String sql = """
                SELECT co.id_coach,
                       co.id_comand,
                       COALESCE(c.namec, 'Без команды') AS team_name,
                       co.full_name,
                       co.position,
                       co.age,
                       co.country,
                       co.experience_years,
                       co.status,
                       COALESCE(co.license_type, '') AS license_type
                FROM Coaches co
                LEFT JOIN Command c ON co.id_comand = c.id_comand
                ORDER BY co.id_coach DESC
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Integer idComand = resultSet.getObject("id_comand") == null
                        ? null
                        : resultSet.getInt("id_comand");

                allCoaches.add(new CoachModel(
                        resultSet.getInt("id_coach"),
                        idComand,
                        resultSet.getString("team_name"),
                        resultSet.getString("full_name"),
                        resultSet.getString("position"),
                        resultSet.getInt("age"),
                        resultSet.getString("country"),
                        resultSet.getInt("experience_years"),
                        resultSet.getString("status"),
                        resultSet.getString("license_type")
                ));
            }

            coachesTable.setItems(allCoaches);
            updateFilterItems();

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка загрузки", "Не удалось загрузить тренеров:\n" + e.getMessage());
        }
    }

    @FXML
    private void filterCoaches() {
        String text = searchField.getText();
        String team = teamFilterComboBox.getValue();
        String position = positionFilterComboBox.getValue();
        String country = countryFilterComboBox.getValue();
        String status = statusFilterComboBox.getValue();
        String license = licenseFilterComboBox.getValue();

        boolean emptySearch = text == null || text.trim().isEmpty();
        boolean emptyFilters = team == null && position == null && country == null && status == null && license == null;

        if (emptySearch && emptyFilters) {
            coachesTable.setItems(allCoaches);
            return;
        }

        String search = emptySearch ? "" : text.trim().toLowerCase();
        ObservableList<CoachModel> filtered = FXCollections.observableArrayList();

        for (CoachModel coach : allCoaches) {
            boolean matchesSearch = emptySearch
                    || contains(coach.getFullName(), search)
                    || contains(coach.getTeamName(), search)
                    || contains(coach.getPositionTitle(), search)
                    || contains(coach.getCountry(), search)
                    || contains(coach.getStatusTitle(), search)
                    || contains(coach.getLicenseTypeTitle(), search);

            boolean matchesFilters = matches(coach.getTeamName(), team)
                    && matches(coach.getPositionTitle(), position)
                    && matches(coach.getCountry(), country)
                    && matches(coach.getStatusTitle(), status)
                    && matches(coach.getLicenseTypeTitle(), license);

            if (matchesSearch && matchesFilters) {
                filtered.add(coach);
            }
        }

        coachesTable.setItems(filtered);
    }

    private boolean contains(String value, String search) {
        return value != null && value.toLowerCase().contains(search);
    }

    private boolean matches(String value, String filter) {
        return filter == null || filter.equals(value);
    }

    private void updateFilterItems() {
        teamFilterComboBox.setItems(collectDistinct(CoachModel::getTeamName));
        positionFilterComboBox.setItems(collectDistinct(CoachModel::getPositionTitle));
        countryFilterComboBox.setItems(collectDistinct(CoachModel::getCountry));
        statusFilterComboBox.setItems(collectDistinct(CoachModel::getStatusTitle));
        licenseFilterComboBox.setItems(collectDistinct(CoachModel::getLicenseTypeTitle));
    }

    private ObservableList<String> collectDistinct(Function<CoachModel, String> getter) {
        ObservableList<String> values = FXCollections.observableArrayList();

        allCoaches.stream()
                .map(getter)
                .filter(value -> value != null && !value.isBlank())
                .distinct()
                .sorted()
                .forEach(values::add);

        return values;
    }

    @FXML
    private void addCoach() {
        openCoachDialog(null);
    }

    @FXML
    private void editCoach() {
        CoachModel selectedCoach = coachesTable.getSelectionModel().getSelectedItem();

        if (selectedCoach == null) {
            showAlert(Alert.AlertType.WARNING, "Тренер не выбран", "Выберите тренера в таблице для изменения.");
            return;
        }

        openCoachDialog(selectedCoach);
    }

    @FXML
    private void deleteCoach() {
        CoachModel selectedCoach = coachesTable.getSelectionModel().getSelectedItem();

        if (selectedCoach == null) {
            showAlert(Alert.AlertType.WARNING, "Тренер не выбран", "Выберите тренера в таблице для удаления.");
            return;
        }

        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Удаление тренера");
        confirmAlert.setHeaderText(null);
        confirmAlert.setContentText("Удалить тренера: " + selectedCoach.getFullName() + "?");

        if (confirmAlert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            return;
        }

        String sql = "DELETE FROM Coaches WHERE id_coach = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, selectedCoach.getIdCoach());
            statement.executeUpdate();

            loadCoaches();
            showAlert(Alert.AlertType.INFORMATION, "Готово", "Тренер удалён.");

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка удаления", "Не удалось удалить тренера:\n" + e.getMessage());
        }
    }

    @FXML
    private void refreshCoaches() {
        searchField.clear();
        clearFilterValues();
        loadCoaches();
    }

    @FXML
    private void clearFilters() {
        clearFilterValues();
        filterCoaches();
    }

    private void clearFilterValues() {
        teamFilterComboBox.setValue(null);
        positionFilterComboBox.setValue(null);
        countryFilterComboBox.setValue(null);
        statusFilterComboBox.setValue(null);
        licenseFilterComboBox.setValue(null);
    }

    private void openCoachDialog(CoachModel coach) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/footballproject/MenuFxml/CoachDialog.fxml"));
            Parent root = loader.load();

            CoachDialogController controller = loader.getController();
            controller.setCoach(coach);

            Stage stage = new Stage();
            stage.setTitle(coach == null ? "Добавить тренера" : "Изменить тренера");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadCoaches();
            }

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка окна", "Не удалось открыть окно тренера:\n" + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
