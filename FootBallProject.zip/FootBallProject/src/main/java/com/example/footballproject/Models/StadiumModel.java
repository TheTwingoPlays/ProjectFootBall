package com.example.footballproject.Models;

public class StadiumModel {
    private final int id;
    private final String name;
    private final String city;
    private final int capacity;

    public StadiumModel(int id, String name, String city, int capacity) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.capacity = capacity;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public int getCapacity() {
        return capacity;
    }
}
