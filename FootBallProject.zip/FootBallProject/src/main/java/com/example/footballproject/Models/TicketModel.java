package com.example.footballproject.Models;

import java.math.BigDecimal;

public class TicketModel {
    private final int id;
    private final Integer gameId;
    private final String gameName;
    private final String type;
    private final BigDecimal cost;
    private final int place;
    private final int row;
    private final String sector;
    private final boolean available;

    public TicketModel(
            int id,
            Integer gameId,
            String gameName,
            String type,
            BigDecimal cost,
            int place,
            int row,
            String sector,
            boolean available
    ) {
        this.id = id;
        this.gameId = gameId;
        this.gameName = gameName;
        this.type = type;
        this.cost = cost;
        this.place = place;
        this.row = row;
        this.sector = sector;
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public Integer getGameId() {
        return gameId;
    }

    public String getGameName() {
        return gameName;
    }

    public String getType() {
        return type;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public int getPlace() {
        return place;
    }

    public String getPlaceText() {
        return place <= 0 ? "Не выбрано" : String.valueOf(place);
    }

    public int getRow() {
        return row;
    }

    public String getRowText() {
        return row <= 0 ? "Не выбран" : String.valueOf(row);
    }

    public String getSector() {
        return sector;
    }

    public String getSectorText() {
        return sector == null || sector.isBlank() || "UNASSIGNED".equals(sector) ? "Не выбран" : sector;
    }

    public boolean isAvailable() {
        return available;
    }

    public String getStatusText() {
        return available ? "Доступен" : "Продан";
    }
}
