package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.UserModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;

public class UsersController {

    @FXML private TextField searchField;

    @FXML private TableView<UserModel> usersTable;

    @FXML private TableColumn<UserModel, Integer> colId;
    @FXML private TableColumn<UserModel, String> colUsername;
    @FXML private TableColumn<UserModel, String> colEmail;
    @FXML private TableColumn<UserModel, String> colRole;
    @FXML private TableColumn<UserModel, String> colStatus;
    @FXML private TableColumn<UserModel, String> colCreatedAt;

    @FXML private Button roleButton;
    @FXML private Button banButton;

    @FXML
    public void initialize() {
        setupTable();
        loadUsers();

        usersTable.getSelectionModel().selectedItemProperty().addListener((obs, oldUser, newUser) -> {
            updateActionButtons(newUser);
        });
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colCreatedAt.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

        colRole.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String role, boolean empty) {
                super.updateItem(role, empty);

                if (empty || role == null) {
                    setText(null);
                    setStyle("");
                    return;
                }

                setText(role);

                if ("ADMIN".equalsIgnoreCase(role)) {
                    setStyle("-fx-text-fill: #344e41; -fx-font-weight: 900;");
                } else {
                    setStyle("-fx-text-fill: #588157; -fx-font-weight: 700;");
                }
            }
        });

        colStatus.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);

                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                    return;
                }

                setText(status);

                if ("ACTIVE".equalsIgnoreCase(status)) {
                    setStyle("-fx-text-fill: #3a5a40; -fx-font-weight: 900;");
                } else {
                    setStyle("-fx-text-fill: #c14444; -fx-font-weight: 900;");
                }
            }
        });
    }

    private void loadUsers() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();

            ObservableList<UserModel> users = DatabaseHandler.getUsers(keyword);

            usersTable.getItems().clear();
            usersTable.setItems(users);
            usersTable.refresh();

            updateActionButtons(usersTable.getSelectionModel().getSelectedItem());

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        loadUsers();
    }

    @FXML
    private void handleRefresh() {
        searchField.clear();
        loadUsers();
    }

    @FXML
    private void handleChangeRole() {
        UserModel selectedUser = usersTable.getSelectionModel().getSelectedItem();

        if (selectedUser == null) {
            showWarning("Выберите пользователя.");
            return;
        }

        String newRole = selectedUser.isAdmin() ? "USER" : "ADMIN";

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Изменение прав");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Изменить роль пользователя " +
                        selectedUser.getUsername() +
                        " на " +
                        newRole +
                        "?"
        );

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                changeUserRole(selectedUser, newRole);
            }
        });
    }

    private void changeUserRole(UserModel user, String newRole) {
        try {
            DatabaseHandler.updateUserRole(user.getId(), newRole);
            loadUsers();
            showInfo("Успешно", "Роль пользователя изменена на " + newRole + ".");

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Role update error: " + e.getMessage());
        }
    }

    @FXML
    private void handleToggleBan() {
        UserModel selectedUser = usersTable.getSelectionModel().getSelectedItem();

        if (selectedUser == null) {
            showWarning("Выберите пользователя.");
            return;
        }

        boolean newActiveStatus = !selectedUser.isActive();

        String actionText = newActiveStatus ? "разбанить" : "забанить";

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Бан пользователя");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Вы уверены, что хотите " +
                        actionText +
                        " пользователя " +
                        selectedUser.getUsername() +
                        "?"
        );

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                toggleUserBan(selectedUser, newActiveStatus);
            }
        });
    }

    private void toggleUserBan(UserModel user, boolean active) {
        try {
            DatabaseHandler.updateUserActiveStatus(user.getId(), active);
            loadUsers();

            showInfo(
                    "Успешно",
                    active ? "Пользователь разбанен." : "Пользователь забанен."
            );

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ban error: " + e.getMessage());
        }
    }

    private void updateActionButtons(UserModel user) {
        if (user == null) {
            roleButton.setText("👑 Изменить права");
            banButton.setText("🚫 Бан / Разбан");
            return;
        }

        if (user.isAdmin()) {
            roleButton.setText("👤 Сделать USER");
        } else {
            roleButton.setText("👑 Сделать ADMIN");
        }

        if (user.isActive()) {
            banButton.setText("🚫 Забанить");
        } else {
            banButton.setText("✅ Разбанить");
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}