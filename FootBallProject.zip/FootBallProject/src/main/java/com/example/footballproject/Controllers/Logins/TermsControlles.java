package com.example.footballproject.Controllers.Logins;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import javafx.scene.control.ScrollPane;

public class TermsControlles {

    @FXML private ScrollPane scrollPane;

    public void handleClose(ActionEvent actionEvent) {
        Stage stage = (Stage) scrollPane.getScene().getWindow();
        stage.close();
    }
}