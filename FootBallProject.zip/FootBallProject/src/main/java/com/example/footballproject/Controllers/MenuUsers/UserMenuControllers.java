package com.example.footballproject.Controllers.MenuUsers;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UserMenuControllers {

    @FXML private StackPane contentPane;

    @FXML private Label pageTitleLabel;
    @FXML private Label pageSubtitleLabel;
    @FXML private Label userNameLabel;

    @FXML private Button btnLogout;
    private String currentUsername;

    @FXML
    public void initialize() {
        handleOverview();
    }

    public void setCurrentUser(String username) {
        this.currentUsername = username;
        if (userNameLabel != null) {
            userNameLabel.setText(username);
        }
    }

    @FXML
    private void handleOverview() {
        pageTitleLabel.setText("Обзор");
        pageSubtitleLabel.setText("Добро пожаловать в пользовательскую панель FootStats.");

        showPlaceholder(
                "Пользовательский обзор",
                "Здесь можно смотреть матчи, команды, игроков и доступные билеты."
        );
    }

    @FXML
    private void handleMatches() {
        pageTitleLabel.setText("Матчи");
        pageSubtitleLabel.setText("Список футбольных матчей.");

        loadPage("/com/example/footballproject/MenuFxml/UserGames.fxml");
    }

    @FXML
    private void handleTeams() {
        pageTitleLabel.setText("Команды");
        pageSubtitleLabel.setText("Список футбольных команд.");

        loadPage("/com/example/footballproject/MenuFxml/UserTeams.fxml");
    }

    @FXML
    private void handlePlayers() {
        pageTitleLabel.setText("Игроки");
        pageSubtitleLabel.setText("Список игроков и их статистика.");

        loadPage("/com/example/footballproject/MenuFxml/UserPlayers.fxml");
    }

    @FXML
    private void handleTickets() {
        pageTitleLabel.setText("Билеты");
        pageSubtitleLabel.setText("Доступные билеты на матчи.");

        loadPage("/com/example/footballproject/MenuFxml/UserTickets.fxml");
    }

    @FXML
    private void handleSettings() {
        pageTitleLabel.setText("Настройки");
        pageSubtitleLabel.setText("Настройки пользовательского аккаунта.");

        showPlaceholder(
                "Настройки",
                "Здесь будут настройки пользователя."
        );
    }

    @FXML
    private void handleLogout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Выход из аккаунта");
        alert.setHeaderText(null);
        alert.setContentText("Вы уверены, что хотите выйти?");

        ButtonType yesButton = new ButtonType("Да");
        ButtonType noButton = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(yesButton, noButton);

        alert.showAndWait().ifPresent(response -> {
            if (response == yesButton) {
                openLoginScreen();
            }
        });
    }

    private void loadPage(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent page = loader.load();

            Object controller = loader.getController();
            if (controller instanceof UserTicketsController ticketsController) {
                ticketsController.setCurrentUser(currentUsername);
            }

            contentPane.getChildren().setAll(page);

        } catch (Exception e) {
            e.printStackTrace();
            showPlaceholder(
                    "Страница в разработке",
                    "Эта вкладка пока не готова: " + fxmlPath
            );
        }
    }

    private void showPlaceholder(String title, String subtitle) {
        VBox box = new VBox(10);
        box.getStyleClass().add("placeholder-page");

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("placeholder-title");

        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.getStyleClass().add("placeholder-subtitle");
        subtitleLabel.setWrapText(true);

        box.getChildren().addAll(titleLabel, subtitleLabel);
        contentPane.getChildren().setAll(box);
    }

    private void openLoginScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/footballproject/LoginsFxml/Login.fxml")
            );

            Parent root = loader.load();

            Stage stage = (Stage) btnLogout.getScene().getWindow();
            Scene scene = new Scene(root);

            stage.setFullScreen(false);
            stage.setMaximized(false);

            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();

            Platform.runLater(() -> {
                stage.setMaximized(true);
                stage.toFront();
            });

        } catch (Exception e) {
            e.printStackTrace();

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Ошибка");
            error.setHeaderText(null);
            error.setContentText("Не удалось выйти из аккаунта.");
            error.showAndWait();
        }
    }
}
