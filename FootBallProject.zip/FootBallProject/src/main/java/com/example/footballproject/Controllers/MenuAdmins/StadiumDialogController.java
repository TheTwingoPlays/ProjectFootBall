package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.StadiumModel;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.SQLException;

public class StadiumDialogController {

    @FXML private Label titleLabel;
    @FXML private TextField nameField;
    @FXML private TextField cityField;
    @FXML private TextField capacityField;

    private StadiumModel stadium;
    private boolean saved;

    @FXML
    private void initialize() {
        onlyNumbers(capacityField);
    }

    public void setStadium(StadiumModel stadium) {
        this.stadium = stadium;

        if (stadium == null) {
            return;
        }

        titleLabel.setText("Редактировать стадион");
        nameField.setText(stadium.getName());
        cityField.setText(stadium.getCity());
        capacityField.setText(String.valueOf(stadium.getCapacity()));
    }

    public boolean isSaved() {
        return saved;
    }

    private void onlyNumbers(TextField field) {
        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.matches("\\d*")) {
                field.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    @FXML
    private void handleSave() {
        if (!validateFields()) {
            return;
        }

        String name = nameField.getText().trim();
        String city = cityField.getText() == null ? "" : cityField.getText().trim();
        int capacity = capacityField.getText().trim().isEmpty()
                ? 0
                : Integer.parseInt(capacityField.getText().trim());

        try {
            if (stadium == null) {
                DatabaseHandler.addStadium(name, city, capacity);
            } else {
                DatabaseHandler.updateStadium(stadium.getId(), name, city, capacity);
            }

            saved = true;
            closeWindow();
        } catch (SQLException e) {
            showError("Ошибка сохранения стадиона: " + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (nameField.getText() == null || nameField.getText().trim().isEmpty()) {
            showError("Введите название стадиона.");
            return false;
        }

        if (capacityField.getText() != null && !capacityField.getText().trim().isEmpty()) {
            int capacity = Integer.parseInt(capacityField.getText().trim());
            if (capacity < 0 || capacity > 300000) {
                showError("Вместимость должна быть от 0 до 300000.");
                return false;
            }
        }

        return true;
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) nameField.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
