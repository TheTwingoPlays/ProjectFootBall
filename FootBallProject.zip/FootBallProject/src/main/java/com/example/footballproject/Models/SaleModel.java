package com.example.footballproject.Models;

import java.math.BigDecimal;

public class SaleModel {
    private final int id;
    private final Integer ticketId;
    private final Integer userId;
    private final String ticketName;
    private final String username;
    private final BigDecimal amount;
    private final String saleDate;
    private final String paymentMethod;

    public SaleModel(int id, Integer ticketId, Integer userId, String ticketName, String username, BigDecimal amount, String saleDate, String paymentMethod) {
        this.id = id;
        this.ticketId = ticketId;
        this.userId = userId;
        this.ticketName = ticketName;
        this.username = username;
        this.amount = amount;
        this.saleDate = saleDate;
        this.paymentMethod = paymentMethod;
    }

    public int getId() {
        return id;
    }

    public Integer getTicketId() {
        return ticketId;
    }

    public Integer getUserId() {
        return userId;
    }

    public String getTicketName() {
        return ticketName;
    }

    public String getUsername() {
        return username;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getSaleDate() {
        return saleDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }
}
