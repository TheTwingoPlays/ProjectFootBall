package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.Nationality;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.PlayerModel;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.sql.SQLException;

public class PlayerDialogController {

    @FXML private Label titleLabel;
    @FXML private Label messageLabel;

    @FXML private ComboBox<OptionItem> teamComboBox;
    @FXML private TextField fullNameField;
    @FXML private ComboBox<String> positionComboBox;
    @FXML private TextField numberField;
    @FXML private TextField ageField;
    @FXML private ComboBox<Nationality> nationalityComboBox;

    private ObservableList<Nationality> allNationalities;
    private boolean updatingNationality = false;
    @FXML private TextField goalsField;
    @FXML private TextField assistsField;
    @FXML private TextField yellowCardsField;
    @FXML private TextField redCardsField;
    @FXML private ComboBox<String> statusComboBox;

    @FXML private Button saveButton;

    private boolean saved = false;
    private boolean editMode = false;
    private int editingPlayerId = -1;

    @FXML
    public void initialize() {
        loadComboBoxes();

        goalsField.setText("0");
        assistsField.setText("0");
        yellowCardsField.setText("0");
        redCardsField.setText("0");
    }

    private void loadComboBoxes() {
        try {
            teamComboBox.setItems(DatabaseHandler.getTeamsOptions());

            positionComboBox.setItems(FXCollections.observableArrayList(
                    "Вратарь",
                    "Защитник",
                    "Полузащитник",
                    "Нападающий"
            ));

            statusComboBox.setItems(FXCollections.observableArrayList(
                    "Активен",
                    "Травмирован"
            ));

            allNationalities = FXCollections.observableArrayList(Nationality.values());

            nationalityComboBox.setItems(allNationalities);
            nationalityComboBox.setEditable(true);
            nationalityComboBox.setValue(null);
            nationalityComboBox.setPromptText("Начните вводить страну...");

            nationalityComboBox.setConverter(new StringConverter<Nationality>() {
                @Override
                public String toString(Nationality nationality) {
                    return nationality == null ? "" : nationality.getDisplayName();
                }

                @Override
                public Nationality fromString(String text) {
                    if (text == null || text.isBlank()) {
                        return null;
                    }

                    for (Nationality nationality : Nationality.values()) {
                        if (nationality.getDisplayName().equalsIgnoreCase(text.trim())) {
                            return nationality;
                        }
                    }

                    return null;
                }
            });

            setupNationalitySearch();

            setupNationalitySearch();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки данных: " + e.getMessage());
        }
    }

    public void setEditPlayerId(int playerId) {
        this.editMode = true;
        this.editingPlayerId = playerId;

        titleLabel.setText("Редактировать игрока");
        saveButton.setText("Сохранить изменения");

        loadPlayerForEdit(playerId);
    }

    private void loadPlayerForEdit(int playerId) {
        try {
            PlayerModel player = DatabaseHandler.getPlayerById(playerId);

            selectOptionById(teamComboBox, player.getTeamId());

            fullNameField.setText(player.getFullName());
            positionComboBox.setValue(player.getPosition());
            numberField.setText(String.valueOf(player.getNumber()));
            ageField.setText(String.valueOf(player.getAge()));
            Nationality nationality = Nationality.fromDisplayName(player.getNationality());

            if (nationality == Nationality.OTHER && !"Other".equalsIgnoreCase(player.getNationality())) {
                nationalityComboBox.setValue(null);
                nationalityComboBox.getEditor().setText(player.getNationality());
            } else {
                nationalityComboBox.setValue(nationality);
                nationalityComboBox.getEditor().setText(nationality.getDisplayName());
            }
            goalsField.setText(String.valueOf(player.getGoals()));
            assistsField.setText(String.valueOf(player.getAssists()));
            yellowCardsField.setText(String.valueOf(player.getYellowCards()));
            redCardsField.setText(String.valueOf(player.getRedCards()));

            if ("INJURED".equalsIgnoreCase(player.getStatus())) {
                statusComboBox.setValue("Травмирован");
            } else {
                statusComboBox.setValue("Активен");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки игрока: " + e.getMessage());
        }
    }

    private void selectOptionById(ComboBox<OptionItem> comboBox, int id) {
        for (OptionItem item : comboBox.getItems()) {
            if (item.getId() == id) {
                comboBox.setValue(item);
                return;
            }
        }
    }

    @FXML
    private void handleSave() {
        clearMessage();

        OptionItem team = teamComboBox.getValue();

        String fullName = fullNameField.getText().trim();
        String position = positionComboBox.getValue();
        String nationalityText = nationalityComboBox.getEditor().getText().trim();

        if (nationalityText.isEmpty()) {
            showError("Выберите национальность.");
            return;
        }

        Nationality nationalityValue = null;

        for (Nationality nationality : Nationality.values()) {
            if (nationality.getDisplayName().equalsIgnoreCase(nationalityText)) {
                nationalityValue = nationality;
                break;
            }
        }

        if (nationalityValue == null) {
            showError("Выберите национальность из списка.");
            return;
        }

        String nationality = nationalityValue.getDisplayName();

        if (team == null) {
            showError("Выберите команду.");
            return;
        }

        if (fullName.isEmpty()) {
            showError("Введите ФИО игрока.");
            return;
        }

        if (position == null || position.isBlank()) {
            showError("Выберите позицию.");
            return;
        }

        int number;
        int age;
        int goals;
        int assists;
        int yellowCards;
        int redCards;

        try {
            number = parseInt(numberField.getText().trim(), "Номер");
            age = parseInt(ageField.getText().trim(), "Возраст");
            goals = parseInt(goalsField.getText().trim(), "Голы");
            assists = parseInt(assistsField.getText().trim(), "Ассисты");
            yellowCards = parseInt(yellowCardsField.getText().trim(), "Жёлтые карточки");
            redCards = parseInt(redCardsField.getText().trim(), "Красные карточки");
        } catch (NumberFormatException e) {
            showError(e.getMessage());
            return;
        }

        if (number < 1 || number > 99) {
            showError("Номер игрока должен быть от 1 до 99.");
            return;
        }

        if (age < 16 || age > 45) {
            showError("Возраст игрока должен быть от 16 до 45 лет.");
            return;
        }

        try {
            Integer excludePlayerId = editMode ? editingPlayerId : null;

            boolean numberExists = DatabaseHandler.playerNumberExistsInTeam(
                    team.getId(),
                    number,
                    excludePlayerId
            );

            if (numberExists) {
                showError("В этой команде уже есть игрок с номером " + number + ".");
                return;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка проверки номера игрока: " + e.getMessage());
            return;
        }

        if (goals < 0 || assists < 0 || yellowCards < 0 || redCards < 0) {
            showError("Статистика не может быть отрицательной.");
            return;
        }

        if (nationality.isEmpty()) {
            nationality = "Unknown";
        }

        String status = "Травмирован".equals(statusComboBox.getValue()) ? "INJURED" : "ACTIVE";

        try {
            if (editMode) {
                DatabaseHandler.updatePlayer(
                        editingPlayerId,
                        team.getId(),
                        fullName,
                        position,
                        number,
                        age,
                        nationality,
                        goals,
                        assists,
                        yellowCards,
                        redCards,
                        status
                );
            } else {
                DatabaseHandler.addPlayer(
                        team.getId(),
                        fullName,
                        position,
                        number,
                        age,
                        nationality,
                        goals,
                        assists,
                        yellowCards,
                        redCards,
                        status
                );
            }

            saved = true;
            closeWindow();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка сохранения игрока: " + e.getMessage());
        }
    }

    private int parseInt(String value, String fieldName) {
        try {
            if (value == null || value.isBlank()) {
                return 0;
            }

            return Integer.parseInt(value);
        } catch (Exception e) {
            throw new NumberFormatException(fieldName + " должен быть числом.");
        }
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    public boolean isSaved() {
        return saved;
    }

    private void closeWindow() {
        Stage stage = (Stage) messageLabel.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        messageLabel.setStyle("-fx-text-fill: #c14444;");
        messageLabel.setText(message);
    }

    private void clearMessage() {
        messageLabel.setText("");
    }

    private void setupNationalitySearch() {
        nationalityComboBox.getEditor().textProperty().addListener((obs, oldValue, newValue) -> {
            if (updatingNationality) {
                return;
            }

            if (!nationalityComboBox.isFocused()) {
                return;
            }

            String text = newValue == null ? "" : newValue.trim().toLowerCase();

            ObservableList<Nationality> filtered = FXCollections.observableArrayList();

            if (text.isEmpty()) {
                filtered.addAll(allNationalities);
            } else {
                for (Nationality nationality : allNationalities) {
                    if (nationality.getDisplayName().toLowerCase().contains(text)) {
                        filtered.add(nationality);
                    }
                }
            }

            updatingNationality = true;
            nationalityComboBox.setItems(filtered);
            updatingNationality = false;

            Platform.runLater(() -> {
                nationalityComboBox.getEditor().setText(newValue);
                nationalityComboBox.getEditor().positionCaret(newValue.length());

                if (!filtered.isEmpty()) {
                    nationalityComboBox.show();
                }
            });
        });

        nationalityComboBox.setOnAction(event -> {
            Nationality selected = nationalityComboBox.getValue();

            if (selected != null) {
                updatingNationality = true;
                nationalityComboBox.getEditor().setText(selected.getDisplayName());
                updatingNationality = false;
            }
        });

        nationalityComboBox.setOnHidden(event -> {
            String text = nationalityComboBox.getEditor().getText();

            updatingNationality = true;
            nationalityComboBox.setItems(allNationalities);
            nationalityComboBox.getEditor().setText(text);
            updatingNationality = false;
        });
    }
}