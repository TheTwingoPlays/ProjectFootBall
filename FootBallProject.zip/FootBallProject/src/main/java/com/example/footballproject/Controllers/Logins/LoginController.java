package com.example.footballproject.Controllers.Logins;


import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.shape.Ellipse;
import javafx.stage.Stage;


import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML private Button signInButton;
    @FXML private Button togglePasswordBtn;

    @FXML private TextField loginField;
    @FXML private PasswordField passwordField;
    @FXML private TextField passwordVisibleField;

    @FXML private Ellipse ringRed;
    @FXML private Ellipse ringYellow;
    @FXML private Ellipse ringGreen;

    private boolean passwordVisible = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        syncPasswordFields();
    }

    private void syncPasswordFields() {
        passwordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!passwordVisible) {
                passwordVisibleField.setText(newVal);
            }
        });

        passwordVisibleField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (passwordVisible) {
                passwordField.setText(newVal);
            }
        });
    }

    @FXML
    private void togglePasswordVisibility() {
        passwordVisible = !passwordVisible;

        if (passwordVisible) {
            passwordVisibleField.setText(passwordField.getText());
            passwordVisibleField.setVisible(true);
            passwordVisibleField.setManaged(true);

            passwordField.setVisible(false);
            passwordField.setManaged(false);

            togglePasswordBtn.setText("🙈");
        } else {
            passwordField.setText(passwordVisibleField.getText());
            passwordField.setVisible(true);
            passwordField.setManaged(true);

            passwordVisibleField.setVisible(false);
            passwordVisibleField.setManaged(false);

            togglePasswordBtn.setText("👁");
        }
    }

    @FXML
    public void handleSignIn(ActionEvent actionEvent) {
        String username = loginField.getText().trim();

        String password = passwordVisible ? passwordVisibleField.getText() : passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Fill in all fields.");
            return;
        }

        loginUser(username, password);
    }
    private void loginUser(String username, String password) {
        try {
            boolean success = DatabaseHandler.validateLogin(username, password);

            if (!success) {
                showAlert(Alert.AlertType.ERROR, "Ошибка", "Неверный логин или пароль.");
                return;
            }

            boolean active = DatabaseHandler.isUserActive(username);

            if (!active) {
                showAlert(Alert.AlertType.ERROR, "Аккаунт заблокирован", "Ваш аккаунт был забанен.");
                return;
            }

            String role = DatabaseHandler.getUserRole(username);

            if (role == null) {
                showAlert(Alert.AlertType.ERROR, "Ошибка", "Не удалось определить роль пользователя.");
                return;
            }

            if ("ADMIN".equalsIgnoreCase(role)) {
                openAdminMenu(username);
            } else {
                openUserMenu(username);
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Ошибка входа: " + e.getMessage());
        }
    }

    @FXML
    public void handleCreateAccount(ActionEvent actionEvent) {
        switchScene("/com/example/footballproject/LoginsFxml/Register.fxml", "Register");
    }

    @FXML
    public void handleForgotPassword(ActionEvent actionEvent) {
        switchScene("/com/example/footballproject/LoginsFxml/ForgetPasswd.fxml", "Reset Password");
    }

    private void switchScene(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            Stage stage = (Stage) signInButton.getScene().getWindow();
            Scene scene = new Scene(root);

            stage.setFullScreen(false);
            stage.setMaximized(false);

            stage.setScene(scene);
            stage.setTitle(title);
            stage.show();

            Platform.runLater(() -> {
                stage.setMaximized(true);
                stage.toFront();
            });

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Could not open: " + fxmlPath);
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void openAdminMenu(String username) {
        Platform.runLater(() -> {
            try {
                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource("/com/example/footballproject/MenuFxml/MainMenuFxml.fxml")
                );

                Parent root = loader.load();

                com.example.footballproject.Controllers.MenuAdmins.MenuController controller = loader.getController();
                controller.setCurrentUser(username);

                Stage stage = (Stage) signInButton.getScene().getWindow();
                Scene scene = new Scene(root);

                stage.setFullScreen(false);
                stage.setMaximized(false);

                stage.setScene(scene);
                stage.setTitle("FootStats - Admin Panel");
                stage.show();

                Platform.runLater(() -> {
                    stage.setMaximized(true);
                    stage.toFront();
                });

            } catch (Exception e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Не удалось открыть админ-панель: " + e.getMessage());
            }
        });
    }

    private void openUserMenu(String username) {
        Platform.runLater(() -> {
            try {
                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource("/com/example/footballproject/UserMenuFxml/UserMenu.fxml")
                );

                Parent root = loader.load();

                com.example.footballproject.Controllers.MenuUsers.UserMenuControllers controller = loader.getController();
                controller.setCurrentUser(username);

                Stage stage = (Stage) signInButton.getScene().getWindow();
                Scene scene = new Scene(root);

                stage.setFullScreen(false);
                stage.setMaximized(false);

                stage.setScene(scene);
                stage.setTitle("FootStats");
                stage.show();

                Platform.runLater(() -> {
                    stage.setMaximized(true);
                    stage.toFront();
                });

            } catch (Exception e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Не удалось открыть пользовательское меню: " + e.getMessage());
            }
        });
    }
}
