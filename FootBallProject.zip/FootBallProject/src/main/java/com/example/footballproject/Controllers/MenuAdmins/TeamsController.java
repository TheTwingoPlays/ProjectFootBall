package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.TeamModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;

public class TeamsController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> countryFilterComboBox;

    @FXML private TableView<TeamModel> teamsTable;

    @FXML private TableColumn<TeamModel, Integer> colId;
    @FXML private TableColumn<TeamModel, String> colName;
    @FXML private TableColumn<TeamModel, String> colCountry;

    private boolean loadingFilterItems;

    @FXML
    public void initialize() {
        setupTable();
        loadTeams();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colCountry.setCellValueFactory(new PropertyValueFactory<>("country"));
    }

    private void loadTeams() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();
            String country = countryFilterComboBox.getValue();

            ObservableList<TeamModel> teams = DatabaseHandler.getTeams(keyword, country);

            teamsTable.getItems().clear();
            teamsTable.setItems(teams);
            teamsTable.refresh();
            loadCountryFilterItems();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error: " + e.getMessage());
        }
    }

    private void loadCountryFilterItems() throws SQLException {
        String selectedCountry = countryFilterComboBox.getValue();
        loadingFilterItems = true;
        countryFilterComboBox.setItems(DatabaseHandler.getTeamCountries());
        countryFilterComboBox.setValue(selectedCountry);
        loadingFilterItems = false;
    }

    @FXML
    private void handleSearch() {
        loadTeams();
    }

    @FXML
    private void handleFilter() {
        if (loadingFilterItems) {
            return;
        }

        loadTeams();
    }

    @FXML
    private void handleRefresh() {
        searchField.clear();
        countryFilterComboBox.setValue(null);
        loadTeams();
    }

    @FXML
    private void handleAdd() {
        openTeamDialog(null);
    }

    @FXML
    private void handleEdit() {
        TeamModel selectedTeam = teamsTable.getSelectionModel().getSelectedItem();

        if (selectedTeam == null) {
            showWarning("Выберите команду для изменения.");
            return;
        }

        openTeamDialog(selectedTeam.getId());
    }

    private void openTeamDialog(Integer teamId) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/footballproject/MenuFxml/TeamDialog.fxml")
            );

            Parent root = loader.load();

            TeamDialogController controller = loader.getController();

            if (teamId != null) {
                controller.setEditTeamId(teamId);
            }

            Stage stage = new Stage();
            stage.setTitle(teamId == null ? "Добавить команду" : "Редактировать команду");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadTeams();
                showInfo("Успешно", teamId == null ? "Команда добавлена." : "Команда обновлена.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Не удалось открыть окно команды: " + e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        TeamModel selectedTeam = teamsTable.getSelectionModel().getSelectedItem();

        if (selectedTeam == null) {
            showWarning("Выберите команду для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление команды");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Удалить команду \"" + selectedTeam.getName() + "\"?\n\n" +
                        "Внимание: связанные игроки и матчи могут быть удалены или изменены согласно связям в базе."
        );

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedTeam(selectedTeam);
            }
        });
    }

    private void deleteSelectedTeam(TeamModel team) {
        try {
            DatabaseHandler.deleteTeamById(team.getId());
            loadTeams();
            showInfo("Успешно", "Команда удалена.");

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
