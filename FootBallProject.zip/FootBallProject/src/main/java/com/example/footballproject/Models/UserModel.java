package com.example.footballproject.Models;

public class UserModel {

    private int id;
    private String username;
    private String email;
    private String role;
    private boolean active;
    private String status;
    private String createdAt;

    public UserModel(int id,
                     String username,
                     String email,
                     String role,
                     boolean active,
                     String createdAt) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.role = role;
        this.active = active;
        this.status = active ? "ACTIVE" : "BANNED";
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public boolean isActive() {
        return active;
    }

    public String getStatus() {
        return status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(role);
    }
}