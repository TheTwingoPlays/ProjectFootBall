package com.example.footballproject.Controllers.MenuAdmins;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class MenuController {

    @FXML private BorderPane rootPane;

    @FXML private StackPane contentPane;

    @FXML private Label pageTitleLabel;
    @FXML private Label pageSubtitleLabel;
    @FXML private Label userNameLabel;

    @FXML private Button btnReport;
    @FXML private Button btnGames;
    @FXML private Button btnTeams;
    @FXML private Button btnPlayers;
    @FXML private Button btnTournaments;
    @FXML private Button btnStadiums;
    @FXML private Button btnTickets;
    @FXML private Button btnReceipts;
    @FXML private Button btnUsers;
    @FXML private Button btnSettings;
    @FXML private Button btnLogout;
    @FXML private Button btnCoaches;
    @FXML private Button btnReferees;
    @FXML private Button btnStandings;

    private List<Button> navButtons;

    public void setCurrentUser(String username) {
        userNameLabel.setText(username);
    }

    @FXML
    public void initialize() {
        navButtons = List.of(
                btnReport,
                btnGames,
                btnTeams,
                btnPlayers,
                btnCoaches,
                btnReferees,
                btnStandings,
                btnTournaments,
                btnStadiums,
                btnTickets,
                btnReceipts,
                btnUsers,
                btnSettings
        );

        handleReport();
    }

    @FXML
    private void handleReport() {
        setPage(
                "Общий отчет",
                "Графики и статистика по билетам, продажам, матчам и командам.",
                btnReport
        );

        loadPage("/com/example/footballproject/MenuFxml/GeneralReports.fxml");
    }

    @FXML
    private void handleGames() {
        setPage(
                "Матчи",
                "Расписание матчей, стадионы, судьи, команды и результаты.",
                btnGames
        );

        loadPage("/com/example/footballproject/MenuFxml/GameFxml.fxml");
    }

    @FXML
    private void handleTeams() {
        setPage(
                "Команды",
                "Список футбольных команд, страны и управление данными.",
                btnTeams
        );

        loadPage("/com/example/footballproject/MenuFxml/Teams.fxml");
    }

    @FXML
    private void handlePlayers() {
        setPage(
                "Игроки",
                "Список игроков, команды, позиции, статистика и статус.",
                btnPlayers
        );

        loadPage("/com/example/footballproject/MenuFxml/Players.fxml");
    }

    @FXML
    private void handleTournaments() {
        setPage(
                "Турниры",
                "Лиги, кубки и турниры.",
                btnTournaments
        );

        loadPage("/com/example/footballproject/MenuFxml/Tournaments.fxml");
    }

    @FXML
    private void handleStadiums() {
        setPage(
                "Стадионы",
                "Стадионы и места проведения матчей.",
                btnStadiums
        );

        loadPage("/com/example/footballproject/MenuFxml/Stadiums.fxml");
    }

    @FXML
    private void handleTickets() {
        setPage(
                "Билеты",
                "Управление билетами на матчи.",
                btnTickets
        );

        loadPage("/com/example/footballproject/MenuFxml/Tickets.fxml");
    }

    @FXML
    private void handleReceipts() {
        setPage(
                "Продажи",
                "История оплат и купленных билетов.",
                btnReceipts
        );

        loadPage("/com/example/footballproject/MenuFxml/Sales.fxml");
    }

    @FXML
    private void handleUsers() {
        setPage(
                "Пользователи",
                "Зарегистрированные аккаунты, роли и статусы доступа.",
                btnUsers
        );

        loadPage("/com/example/footballproject/MenuFxml/Users.fxml");
    }

    @FXML
    private void handleStandings() {
        setPage(
                "Турнирная таблица",
                "Очки, победы, поражения, голы и статистика команд.",
                btnStandings
        );

        loadPage("/com/example/footballproject/MenuFxml/Standings.fxml");
    }

    @FXML
    private void handleSettings() {
        setPage(
                "Настройки",
                "Персонализация интерфейса и параметров приложения.",
                btnSettings
        );

        loadPage("/com/example/footballproject/MenuFxml/Settings.fxml");
    }

    @FXML
    private void handleCoaches() {
        setPage(
                "Тренеры",
                "Список тренеров, команды и тренерский состав.",
                btnCoaches
        );

        loadPage("/com/example/footballproject/MenuFxml/Coaches.fxml");

    }

    @FXML
    private void handleReferees() {
        setPage(
                "Судьи",
                "Список судей и назначение на матчи.",
                btnReferees
        );

        loadPage("/com/example/footballproject/MenuFxml/Referees.fxml");
    }

    @FXML
    private void handleLogout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Выход из аккаунта");
        alert.setHeaderText(null);
        alert.setContentText("Вы уверены, что хотите выйти из аккаунта?");

        ButtonType yesButton = new ButtonType("Да");
        ButtonType noButton = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(yesButton, noButton);

        alert.showAndWait().ifPresent(response -> {
            if (response == yesButton) {
                openLoginScreen();
            }
        });
    }

    private void setPage(String title, String subtitle, Button activeButton) {
        pageTitleLabel.setText(title);
        pageSubtitleLabel.setText(subtitle);
        setActiveButton(activeButton);
    }

    private void setActiveButton(Button activeButton) {
        for (Button button : navButtons) {
            button.getStyleClass().remove("nav-active");
        }

        if (!activeButton.getStyleClass().contains("nav-active")) {
            activeButton.getStyleClass().add("nav-active");
        }
    }

    private void loadPage(String fxmlPath) {
        try {
            Parent page = FXMLLoader.load(getClass().getResource(fxmlPath));
            contentPane.getChildren().setAll(page);

        } catch (Exception e) {
            e.printStackTrace();

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setHeaderText(null);
            alert.setContentText("Не удалось загрузить страницу: " + fxmlPath);
            alert.showAndWait();
        }
    }

    private void showPlaceholder(String title, String subtitle) {
        VBox box = new VBox(10);
        box.getStyleClass().add("placeholder-page");

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("placeholder-title");

        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.getStyleClass().add("placeholder-subtitle");
        subtitleLabel.setWrapText(true);

        box.getChildren().addAll(titleLabel, subtitleLabel);
        contentPane.getChildren().setAll(box);
    }

    private void openLoginScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/footballproject/LoginsFxml/Login.fxml")
            );

            Parent root = loader.load();

            Stage stage = (Stage) btnLogout.getScene().getWindow();
            Scene scene = new Scene(root);

            stage.setFullScreen(false);
            stage.setMaximized(false);

            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();

            Platform.runLater(() -> {
                stage.setMaximized(true);
                stage.toFront();
            });

        } catch (Exception e) {
            e.printStackTrace();

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Ошибка");
            error.setHeaderText(null);
            error.setContentText("Не удалось выйти из аккаунта.");
            error.showAndWait();
        }
    }


}
