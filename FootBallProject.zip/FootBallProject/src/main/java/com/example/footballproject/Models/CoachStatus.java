package com.example.footballproject.Models;

public enum CoachStatus {
    ACTIVE("Активен"),
    INACTIVE("Неактивен"),
    ON_VACATION("В отпуске"),
    FIRED("Уволен");

    private final String title;

    CoachStatus(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return title;
    }
}
