package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.CoachCountry;
import com.example.footballproject.Models.CoachLicenseType;
import com.example.footballproject.Models.CoachModel;
import com.example.footballproject.Models.CoachPosition;
import com.example.footballproject.Models.CoachStatus;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CoachDialogController {

    @FXML private TextField fullNameField;
    @FXML private ComboBox<TeamItem> teamComboBox;
    @FXML private ComboBox<CoachPosition> positionComboBox;
    @FXML private TextField ageField;
    @FXML private ComboBox<CoachCountry> countryComboBox;
    @FXML private TextField experienceYearsField;
    @FXML private ComboBox<CoachStatus> statusComboBox;
    @FXML private ComboBox<CoachLicenseType> licenseTypeComboBox;

    private CoachModel coach;
    private boolean saved;

    @FXML
    private void initialize() {
        positionComboBox.setItems(FXCollections.observableArrayList(CoachPosition.values()));
        countryComboBox.setItems(FXCollections.observableArrayList(CoachCountry.values()));
        statusComboBox.setItems(FXCollections.observableArrayList(CoachStatus.values()));
        licenseTypeComboBox.setItems(FXCollections.observableArrayList(CoachLicenseType.values()));

        setupCountrySearch();
        loadTeams();
        onlyNumbers(ageField);
        onlyNumbers(experienceYearsField);

        positionComboBox.setValue(CoachPosition.HEAD_COACH);
        countryComboBox.setValue(CoachCountry.MOLDOVA);
        statusComboBox.setValue(CoachStatus.ACTIVE);
        licenseTypeComboBox.setValue(CoachLicenseType.UEFA_PRO);
    }

    public void setCoach(CoachModel coach) {
        this.coach = coach;

        if (coach == null) {
            return;
        }

        fullNameField.setText(coach.getFullName());
        ageField.setText(String.valueOf(coach.getAge()));
        experienceYearsField.setText(String.valueOf(coach.getExperienceYears()));

        selectTeam(coach.getIdComand());
        selectPosition(coach.getPosition());
        selectCountry(coach.getCountry());
        selectStatus(coach.getStatus());
        selectLicenseType(coach.getLicenseType());
    }

    public boolean isSaved() {
        return saved;
    }

    private Connection getConnection() throws Exception {
        return DatabaseHandler.getConnection();
    }

    private void loadTeams() {
        teamComboBox.getItems().clear();
        teamComboBox.getItems().add(new TeamItem(null, "Без команды"));

        String sql = "SELECT id_comand, namec FROM Command ORDER BY namec";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                teamComboBox.getItems().add(new TeamItem(
                        resultSet.getInt("id_comand"),
                        resultSet.getString("namec")
                ));
            }

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка команд", "Не удалось загрузить команды:\n" + e.getMessage());
        }

        teamComboBox.getSelectionModel().selectFirst();
    }

    private void setupCountrySearch() {
        countryComboBox.setEditable(true);
        countryComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(CoachCountry country) {
                return country == null ? "" : country.toString();
            }

            @Override
            public CoachCountry fromString(String text) {
                if (text == null || text.trim().isEmpty()) {
                    return null;
                }

                String normalized = text.trim().replace(" ", "_").toUpperCase();

                for (CoachCountry country : CoachCountry.values()) {
                    if (country.name().equalsIgnoreCase(normalized) || country.toString().equalsIgnoreCase(text.trim())) {
                        return country;
                    }
                }

                return null;
            }
        });
    }

    private void onlyNumbers(TextField field) {
        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.matches("\\d*")) {
                field.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    @FXML
    private void saveCoach() {
        if (!validateFields()) {
            return;
        }

        String sqlInsert = """
                INSERT INTO Coaches
                (id_comand, full_name, position, age, country, experience_years, status, license_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        String sqlUpdate = """
                UPDATE Coaches
                SET id_comand = ?,
                    full_name = ?,
                    position = ?,
                    age = ?,
                    country = ?,
                    experience_years = ?,
                    status = ?,
                    license_type = ?
                WHERE id_coach = ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(coach == null ? sqlInsert : sqlUpdate)) {

            TeamItem selectedTeam = teamComboBox.getValue();

            if (selectedTeam == null || selectedTeam.getIdComand() == null) {
                statement.setObject(1, null);
            } else {
                statement.setInt(1, selectedTeam.getIdComand());
            }

            statement.setString(2, fullNameField.getText().trim());
            statement.setString(3, positionComboBox.getValue().name());
            statement.setInt(4, Integer.parseInt(ageField.getText().trim()));
            statement.setString(5, getSelectedCountry().name());
            statement.setInt(6, Integer.parseInt(experienceYearsField.getText().trim()));
            statement.setString(7, statusComboBox.getValue().name());
            statement.setString(8, licenseTypeComboBox.getValue().name());

            if (coach != null) {
                statement.setInt(9, coach.getIdCoach());
            }

            statement.executeUpdate();
            saved = true;
            closeWindow();

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка сохранения", "Не удалось сохранить тренера:\n" + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (fullNameField.getText() == null || fullNameField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Введите ФИО тренера.");
            return false;
        }

        if (positionComboBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Выберите должность тренера.");
            return false;
        }

        if (getSelectedCountry() == null) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Выберите страну из списка.");
            return false;
        }

        if (statusComboBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Выберите статус тренера.");
            return false;
        }

        if (licenseTypeComboBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Выберите тип лицензии.");
            return false;
        }

        if (ageField.getText() == null || ageField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Введите возраст тренера.");
            return false;
        }

        int age = Integer.parseInt(ageField.getText().trim());
        if (age < 18 || age > 90) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Возраст тренера должен быть от 18 до 90 лет.");
            return false;
        }

        if (experienceYearsField.getText() == null || experienceYearsField.getText().trim().isEmpty()) {
            experienceYearsField.setText("0");
        }

        int experience = Integer.parseInt(experienceYearsField.getText().trim());
        if (experience < 0 || experience > 70) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Стаж тренера должен быть от 0 до 70 лет.");
            return false;
        }

        return true;
    }

    private void selectTeam(Integer idComand) {
        if (idComand == null) {
            teamComboBox.getSelectionModel().selectFirst();
            return;
        }

        for (TeamItem item : teamComboBox.getItems()) {
            if (item.getIdComand() != null && item.getIdComand().equals(idComand)) {
                teamComboBox.setValue(item);
                return;
            }
        }
    }

    private void selectPosition(String dbValue) {
        CoachPosition position = findEnumByName(CoachPosition.values(), dbValue);
        if (position != null) {
            positionComboBox.setValue(position);
        }
    }

    private void selectCountry(String dbValue) {
        CoachCountry country = findEnumByName(CoachCountry.values(), dbValue);
        if (country != null) {
            countryComboBox.setValue(country);
        }
    }

    private void selectStatus(String dbValue) {
        CoachStatus status = findEnumByName(CoachStatus.values(), dbValue);
        if (status != null) {
            statusComboBox.setValue(status);
        }
    }

    private void selectLicenseType(String dbValue) {
        CoachLicenseType licenseType = findEnumByName(CoachLicenseType.values(), dbValue);
        if (licenseType != null) {
            licenseTypeComboBox.setValue(licenseType);
        }
    }

    private <T extends Enum<T>> T findEnumByName(T[] values, String dbValue) {
        if (dbValue == null) {
            return null;
        }

        String normalized = dbValue.trim()
                .replace(" ", "_")
                .replace("-", "_")
                .toUpperCase();

        for (T value : values) {
            if (value.name().equalsIgnoreCase(normalized) || value.toString().equalsIgnoreCase(dbValue.trim())) {
                return value;
            }
        }

        return null;
    }

    private CoachCountry getSelectedCountry() {
        CoachCountry selectedCountry = countryComboBox.getValue();
        if (selectedCountry != null) {
            return selectedCountry;
        }

        String editorText = countryComboBox.getEditor() == null ? null : countryComboBox.getEditor().getText();
        return countryComboBox.getConverter().fromString(editorText);
    }

    @FXML
    private void cancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) fullNameField.getScene().getWindow();
        stage.close();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class TeamItem {
        private final Integer idComand;
        private final String name;

        public TeamItem(Integer idComand, String name) {
            this.idComand = idComand;
            this.name = name;
        }

        public Integer getIdComand() {
            return idComand;
        }

        @Override
        public String toString() {
            return name;
        }
    }
}
