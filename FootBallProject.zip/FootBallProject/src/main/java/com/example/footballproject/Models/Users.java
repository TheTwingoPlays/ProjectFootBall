package com.example.footballproject.Models;

public class Users {
    private int id;
    private String name;
    private String date;
    private String status;

    public Users(int id, String name, String date, String status) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.status = status;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDate() { return date; }
    public String getStatus() { return status; }

    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setDate(String date) { this.date = date; }
    public void setStatus(String status) { this.status = status; }
}
