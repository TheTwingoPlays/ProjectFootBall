package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.GameFormData;
import com.example.footballproject.Models.OptionItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

public class GameDialogController {

    @FXML private Label titleLabel;
    @FXML private Label messageLabel;

    @FXML private ComboBox<OptionItem> tournamentComboBox;
    @FXML private ComboBox<OptionItem> homeTeamComboBox;
    @FXML private ComboBox<OptionItem> awayTeamComboBox;
    @FXML private ComboBox<OptionItem> stadiumComboBox;
    @FXML private ComboBox<OptionItem> refereeComboBox;

    @FXML private DatePicker datePicker;
    @FXML private TextField timeField;
    @FXML private TextField scoreField;

    @FXML private Button saveButton;

    private boolean saved = false;
    private boolean editMode = false;
    private int editingGameId = -1;

    private boolean loadingEditData = false;
    private boolean updatingTeams = false;

    private ObservableList<OptionItem> tournamentTeams = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        loadComboBoxData();

        scoreField.setText("?-?");
        timeField.setText("20:00");

        tournamentComboBox.valueProperty().addListener((obs, oldTournament, newTournament) -> {
            if (!loadingEditData && !updatingTeams) {
                loadTeamsBySelectedTournament();
                loadStadiumsBySelectedTournament();
            }
        });

        homeTeamComboBox.valueProperty().addListener((obs, oldTeam, newTeam) -> {
            if (!loadingEditData && !updatingTeams) {
                updateTeamLists();
            }
        });

        awayTeamComboBox.valueProperty().addListener((obs, oldTeam, newTeam) -> {
            if (!loadingEditData && !updatingTeams) {
                updateTeamLists();
            }
        });

        datePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);

                if (date.isBefore(LocalDate.now())) {
                    setDisable(true);
                    setStyle("-fx-background-color: #ffe5e5;");
                }
            }
        });
    }

    public void setEditGameId(int gameId) {
        this.editMode = true;
        this.editingGameId = gameId;

        titleLabel.setText("Редактировать матч");
        saveButton.setText("Сохранить изменения");

        loadGameForEdit(gameId);
    }

    private void loadComboBoxData() {
        try {
            tournamentComboBox.setItems(DatabaseHandler.getTournamentsOptions());

            homeTeamComboBox.setDisable(true);
            awayTeamComboBox.setDisable(true);
            stadiumComboBox.setDisable(true);

            homeTeamComboBox.setPromptText("Сначала выберите турнир");
            awayTeamComboBox.setPromptText("Сначала выберите турнир");
            stadiumComboBox.setPromptText("Сначала выберите турнир");

            refereeComboBox.setItems(DatabaseHandler.getRefereesOptions());

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки данных: " + e.getMessage());
        }
    }

    private void loadTeamsBySelectedTournament() {
        OptionItem selectedTournament = tournamentComboBox.getValue();

        updatingTeams = true;

        homeTeamComboBox.setValue(null);
        awayTeamComboBox.setValue(null);

        homeTeamComboBox.getItems().clear();
        awayTeamComboBox.getItems().clear();

        tournamentTeams.clear();

        updatingTeams = false;

        if (selectedTournament == null) {
            homeTeamComboBox.setDisable(true);
            awayTeamComboBox.setDisable(true);

            homeTeamComboBox.setPromptText("Сначала выберите турнир");
            awayTeamComboBox.setPromptText("Сначала выберите турнир");
            return;
        }

        try {
            tournamentTeams = DatabaseHandler.getTeamsOptionsByTournament(selectedTournament.getId());

            if (tournamentTeams.isEmpty()) {
                showError("В этом турнире пока нет команд.");

                homeTeamComboBox.setDisable(true);
                awayTeamComboBox.setDisable(true);

                homeTeamComboBox.setPromptText("Нет команд");
                awayTeamComboBox.setPromptText("Нет команд");
                return;
            }

            updatingTeams = true;

            homeTeamComboBox.setItems(FXCollections.observableArrayList(tournamentTeams));
            awayTeamComboBox.setItems(FXCollections.observableArrayList(tournamentTeams));

            homeTeamComboBox.setDisable(false);
            awayTeamComboBox.setDisable(false);

            homeTeamComboBox.setPromptText("Выберите команду хозяев");
            awayTeamComboBox.setPromptText("Выберите команду гостей");

            updatingTeams = false;

            clearMessage();

        } catch (SQLException e) {
            updatingTeams = false;
            e.printStackTrace();
            showError("Ошибка загрузки команд турнира: " + e.getMessage());
        }
    }

    private void updateTeamLists() {
        if (tournamentTeams == null || tournamentTeams.isEmpty()) {
            return;
        }

        OptionItem selectedHome = homeTeamComboBox.getValue();
        OptionItem selectedAway = awayTeamComboBox.getValue();

        updatingTeams = true;

        ObservableList<OptionItem> homeList = FXCollections.observableArrayList();
        ObservableList<OptionItem> awayList = FXCollections.observableArrayList();

        for (OptionItem team : tournamentTeams) {
            if (selectedAway == null || team.getId() != selectedAway.getId()) {
                homeList.add(team);
            }

            if (selectedHome == null || team.getId() != selectedHome.getId()) {
                awayList.add(team);
            }
        }

        homeTeamComboBox.setItems(homeList);
        awayTeamComboBox.setItems(awayList);

        if (selectedHome != null) {
            selectOptionById(homeTeamComboBox, selectedHome.getId());
        }

        if (selectedAway != null) {
            selectOptionById(awayTeamComboBox, selectedAway.getId());
        }

        updatingTeams = false;
    }

    private void loadGameForEdit(int gameId) {
        try {
            loadingEditData = true;

            GameFormData game = DatabaseHandler.getGameFormDataById(gameId);

            selectOptionById(tournamentComboBox, game.getTournamentId());

            tournamentTeams = DatabaseHandler.getTeamsOptionsByTournament(game.getTournamentId());

            homeTeamComboBox.setItems(FXCollections.observableArrayList(tournamentTeams));
            awayTeamComboBox.setItems(FXCollections.observableArrayList(tournamentTeams));

            homeTeamComboBox.setDisable(false);
            awayTeamComboBox.setDisable(false);

            ObservableList<OptionItem> tournamentStadiums =
                    DatabaseHandler.getStadiumsOptionsByTournament(game.getTournamentId());

            stadiumComboBox.setItems(tournamentStadiums);
            stadiumComboBox.setDisable(false);
            stadiumComboBox.setPromptText("Выберите стадион");

            homeTeamComboBox.setPromptText("Выберите команду хозяев");
            awayTeamComboBox.setPromptText("Выберите команду гостей");

            selectOptionById(homeTeamComboBox, game.getHomeTeamId());
            selectOptionById(awayTeamComboBox, game.getAwayTeamId());

            selectOptionById(stadiumComboBox, game.getStadiumId());
            selectOptionById(refereeComboBox, game.getRefereeId());

            datePicker.setValue(game.getDate());
            timeField.setText(game.getTime().toString());
            scoreField.setText(game.getScore());

            loadingEditData = false;

            updateTeamLists();

        } catch (SQLException e) {
            loadingEditData = false;
            e.printStackTrace();
            showError("Ошибка загрузки матча: " + e.getMessage());
        }
    }

    private void selectOptionById(ComboBox<OptionItem> comboBox, int id) {
        for (OptionItem item : comboBox.getItems()) {
            if (item.getId() == id) {
                comboBox.setValue(item);
                return;
            }
        }
    }

    @FXML
    private void handleSave() {
        clearMessage();

        OptionItem tournament = tournamentComboBox.getValue();
        OptionItem homeTeam = homeTeamComboBox.getValue();
        OptionItem awayTeam = awayTeamComboBox.getValue();
        OptionItem stadium = stadiumComboBox.getValue();
        OptionItem referee = refereeComboBox.getValue();

        LocalDate date = datePicker.getValue();
        String timeText = timeField.getText().trim();
        String score = scoreField.getText().trim();

        if (tournament == null || homeTeam == null || awayTeam == null || stadium == null || referee == null) {
            showError("Выберите турнир, команды, стадион и судью.");
            return;
        }

        if (homeTeam.getId() == awayTeam.getId()) {
            showError("Команды не могут быть одинаковыми.");
            return;
        }

        if (date == null) {
            showError("Выберите дату матча.");
            return;
        }

        if (date.isBefore(LocalDate.now())) {
            showError("Дата матча не может быть прошедшей.");
            return;
        }

        LocalTime time;

        try {
            time = LocalTime.parse(timeText);
        } catch (DateTimeParseException e) {
            showError("Введите время в формате HH:mm. Например: 20:00");
            return;
        }

        if (score.isEmpty()) {
            score = "?-?";
        }

        if (!score.matches("^\\d+-\\d+$") && !score.equals("?-?")) {
            showError("Счёт должен быть в формате 2-1 или ?-?");
            return;
        }

        try {
            if (editMode) {
                DatabaseHandler.updateGame(
                        editingGameId,
                        homeTeam.getId(),
                        awayTeam.getId(),
                        tournament.getId(),
                        stadium.getId(),
                        referee.getId(),
                        date,
                        time,
                        score
                );
            } else {
                DatabaseHandler.addGame(
                        homeTeam.getId(),
                        awayTeam.getId(),
                        tournament.getId(),
                        stadium.getId(),
                        referee.getId(),
                        date,
                        time,
                        score
                );
            }

            saved = true;
            closeWindow();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка сохранения матча: " + e.getMessage());
        }
    }

    private void loadStadiumsBySelectedTournament() {
        OptionItem selectedTournament = tournamentComboBox.getValue();

        stadiumComboBox.setValue(null);
        stadiumComboBox.getItems().clear();

        if (selectedTournament == null) {
            stadiumComboBox.setDisable(true);
            stadiumComboBox.setPromptText("Сначала выберите турнир");
            return;
        }

        try {
            ObservableList<OptionItem> stadiums =
                    DatabaseHandler.getStadiumsOptionsByTournament(selectedTournament.getId());

            if (stadiums.isEmpty()) {
                showError("В этом турнире пока нет стадионов.");
                stadiumComboBox.setDisable(true);
                stadiumComboBox.setPromptText("Нет стадионов");
                return;
            }

            stadiumComboBox.setItems(stadiums);
            stadiumComboBox.setDisable(false);
            stadiumComboBox.setPromptText("Выберите стадион");

            clearMessage();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки стадионов турнира: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    public boolean isSaved() {
        return saved;
    }

    private void closeWindow() {
        Stage stage = (Stage) messageLabel.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        messageLabel.setStyle("-fx-text-fill: #c14444;");
        messageLabel.setText(message);
    }

    private void clearMessage() {
        messageLabel.setText("");
    }
}