package com.example.footballproject.Models;

public class PlayerModel {

    private int id;
    private int teamId;
    private String teamName;
    private String fullName;
    private String position;
    private int number;
    private int age;
    private String nationality;
    private int goals;
    private int assists;
    private int yellowCards;
    private int redCards;
    private String status;

    public PlayerModel(int id,
                       int teamId,
                       String teamName,
                       String fullName,
                       String position,
                       int number,
                       int age,
                       String nationality,
                       int goals,
                       int assists,
                       int yellowCards,
                       int redCards,
                       String status) {
        this.id = id;
        this.teamId = teamId;
        this.teamName = teamName;
        this.fullName = fullName;
        this.position = position;
        this.number = number;
        this.age = age;
        this.nationality = nationality;
        this.goals = goals;
        this.assists = assists;
        this.yellowCards = yellowCards;
        this.redCards = redCards;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public int getTeamId() {
        return teamId;
    }

    public String getTeamName() {
        return teamName;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPosition() {
        return position;
    }

    public int getNumber() {
        return number;
    }

    public int getAge() {
        return age;
    }

    public String getNationality() {
        return nationality;
    }

    public int getGoals() {
        return goals;
    }

    public int getAssists() {
        return assists;
    }

    public int getYellowCards() {
        return yellowCards;
    }

    public int getRedCards() {
        return redCards;
    }

    public String getStatus() {
        return status;
    }

    public String getStatusText() {
        if ("INJURED".equalsIgnoreCase(status)) {
            return "Травмирован";
        }

        return "Активен";
    }
}