package com.example.footballproject.Controllers.MenuUsers;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;

public class UserTicketsController {

    private static final int MAX_ROW = 20;
    private static final int MAX_PLACE = 30;

    private static final String FROM_EMAIL = "borisovdimap2414@gmail.com";
    private static final String FROM_PASSWORD = "nuen yild yuhl fdyn";

    @FXML private ComboBox<OptionItem> gameComboBox;
    @FXML private ComboBox<String> typeComboBox;
    @FXML private ComboBox<String> sectorComboBox;
    @FXML private ComboBox<Integer> rowComboBox;
    @FXML private ComboBox<Integer> placeComboBox;
    @FXML private Label priceLabel;
    @FXML private Label balanceLabel;

    private String username;
    private BigDecimal selectedPrice;

    @FXML
    private void initialize() {
        sectorComboBox.setItems(FXCollections.observableArrayList("A", "B", "C", "D"));

        rowComboBox.setItems(FXCollections.observableArrayList());
        for (int row = 1; row <= MAX_ROW; row++) {
            rowComboBox.getItems().add(row);
        }

        loadGames();
    }

    public void setCurrentUser(String username) {
        this.username = username;
        loadBalance();
    }

    private void loadGames() {
        try {
            gameComboBox.setItems(DatabaseHandler.getGamesWithTicketTariffsOptions());
        } catch (SQLException e) {
            showError("Ошибка загрузки матчей:\n" + e.getMessage());
        }
    }

    private void loadBalance() {
        if (username == null || username.isBlank() || balanceLabel == null) {
            return;
        }

        try {
            balanceLabel.setText(DatabaseHandler.getUserBalance(username).toPlainString() + " MDL");
        } catch (SQLException e) {
            showError("Ошибка загрузки баланса:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleTopUpBalance() {
        if (username == null || username.isBlank()) {
            showError("Пользователь не найден. Перезайдите в аккаунт.");
            return;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Пополнение баланса");
        dialog.setHeaderText(null);
        dialog.setContentText("Введите сумму пополнения:");

        Optional<String> result = dialog.showAndWait();
        if (result.isEmpty()) {
            return;
        }

        try {
            BigDecimal amount = new BigDecimal(result.get().trim());

            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                showError("Сумма должна быть больше 0.");
                return;
            }

            DatabaseHandler.topUpUserBalance(username, amount);
            loadBalance();

            showInfo("Готово", "Баланс пополнен на " + amount.toPlainString() + " MDL.");

        } catch (NumberFormatException e) {
            showError("Введите корректную сумму.");
        } catch (SQLException e) {
            showError("Не удалось пополнить баланс:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleGameSelected() {
        typeComboBox.setValue(null);
        typeComboBox.getItems().clear();

        selectedPrice = null;
        priceLabel.setText("0.00 MDL");

        placeComboBox.setValue(null);
        placeComboBox.getItems().clear();

        OptionItem game = gameComboBox.getValue();
        if (game == null) {
            return;
        }

        try {
            typeComboBox.setItems(DatabaseHandler.getAvailableTicketTypesForGame(game.getId()));
        } catch (SQLException e) {
            showError("Ошибка загрузки типов билетов:\n" + e.getMessage());
        }

        refreshAvailablePlaces();
    }

    @FXML
    private void handleTypeSelected() {
        selectedPrice = null;
        priceLabel.setText("0.00 MDL");

        OptionItem game = gameComboBox.getValue();
        String type = typeComboBox.getValue();

        if (game == null || type == null || type.isBlank()) {
            return;
        }

        try {
            selectedPrice = DatabaseHandler.getTicketPrice(game.getId(), type);
            priceLabel.setText(selectedPrice.toPlainString() + " MDL");
        } catch (SQLException e) {
            showError("Ошибка загрузки цены:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleSeatSelected() {
        refreshAvailablePlaces();
    }

    private void refreshAvailablePlaces() {
        placeComboBox.setValue(null);
        placeComboBox.getItems().clear();

        OptionItem game = gameComboBox.getValue();
        String sector = sectorComboBox.getValue();
        Integer row = rowComboBox.getValue();

        if (game == null || sector == null || row == null) {
            return;
        }

        try {
            placeComboBox.setItems(
                    DatabaseHandler.getAvailablePlacesForSeat(
                            game.getId(),
                            sector,
                            row,
                            MAX_PLACE
                    )
            );

            if (placeComboBox.getItems().isEmpty()) {
                showError("В этом секторе и ряду больше нет свободных мест.");
            }

        } catch (SQLException e) {
            showError("Ошибка загрузки свободных мест:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleBuyTicket() {
        if (!validateFields()) {
            return;
        }

        OptionItem game = gameComboBox.getValue();
        String type = typeComboBox.getValue();
        String sector = sectorComboBox.getValue();
        int row = rowComboBox.getValue();
        int place = placeComboBox.getValue();

        try {
            int ticketId = DatabaseHandler.purchaseTicket(
                    username,
                    game.getId(),
                    type,
                    sector,
                    row,
                    place
            );

            loadBalance();

            try {
                String sentTo = sendTicketEmail(
                        ticketId,
                        game.toString(),
                        type,
                        sector,
                        row,
                        place,
                        selectedPrice
                );

                showInfo(
                        "Билет куплен",
                        "Билет успешно куплен.\n\n" +
                                "Номер билета: #" + ticketId + "\n" +
                                "Письмо отправлено на: " + sentTo
                );

            } catch (SQLException | MessagingException | UnsupportedEncodingException e) {
                e.printStackTrace();

                showInfo(
                        "Билет куплен",
                        "Билет куплен, но письмо не отправилось.\n\n" +
                                "Причина:\n" +
                                e.getClass().getSimpleName() + "\n" +
                                e.getMessage() + "\n\n" +
                                "Проверьте email пользователя, интернет и пароль приложения Gmail."
                );
            }

            placeComboBox.setValue(null);
            refreshAvailablePlaces();

        } catch (SQLException e) {
            e.printStackTrace();

            showError(
                    "Не удалось купить билет:\n" +
                            e.getMessage()
            );

            refreshAvailablePlaces();
            loadBalance();
        }
    }

    private boolean validateFields() {
        if (username == null || username.isBlank()) {
            showError("Не найден текущий пользователь. Перезайдите в аккаунт.");
            return false;
        }

        if (gameComboBox.getValue() == null) {
            showError("Выберите матч.");
            return false;
        }

        if (typeComboBox.getValue() == null || typeComboBox.getValue().isBlank()) {
            showError("Выберите тип билета.");
            return false;
        }

        if (sectorComboBox.getValue() == null || sectorComboBox.getValue().isBlank()) {
            showError("Выберите сектор.");
            return false;
        }

        if (rowComboBox.getValue() == null) {
            showError("Выберите ряд.");
            return false;
        }

        if (placeComboBox.getValue() == null) {
            showError("Выберите свободное место.");
            return false;
        }

        if (selectedPrice == null) {
            handleTypeSelected();
        }

        if (selectedPrice == null) {
            showError("Не удалось определить цену билета.");
            return false;
        }

        return true;
    }

    private String sendTicketEmail(
            int ticketId,
            String game,
            String type,
            String sector,
            int row,
            int place,
            BigDecimal price
    ) throws SQLException, MessagingException, UnsupportedEncodingException {

        if (username == null || username.isBlank()) {
            throw new MessagingException("Не найден текущий пользователь. Username пустой.");
        }

        String toEmail = DatabaseHandler.getUserEmailByUsername(username);

        if (toEmail == null || toEmail.isBlank()) {
            throw new MessagingException("У пользователя не указан email в базе данных.");
        }

        System.out.println("========================================");
        System.out.println("Отправка билета FootStats");
        System.out.println("Пользователь: " + username);
        System.out.println("Email получателя: " + toEmail);
        System.out.println("Билет: #" + ticketId);
        System.out.println("========================================");

        Properties props = new Properties();

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.starttls.required", "true");

        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

        props.put("mail.smtp.connectiontimeout", "15000");
        props.put("mail.smtp.timeout", "15000");
        props.put("mail.smtp.writetimeout", "15000");

        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, FROM_PASSWORD);
            }
        });

        session.setDebug(true);

        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(FROM_EMAIL, "FootStats"));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
        message.setSubject("Ваш билет FootStats #" + ticketId, "UTF-8");
        message.setSentDate(new Date());

        String html = createTicketHtml(ticketId, game, type, sector, row, place, price);

        message.setContent(html, "text/html; charset=UTF-8");
        message.saveChanges();

        Transport.send(message);

        return toEmail;
    }

    private String createTicketHtml(
            int ticketId,
            String game,
            String type,
            String sector,
            int row,
            int place,
            BigDecimal price
    ) {
        return """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                </head>
                <body style="margin:0; padding:0; background:#eaf4ee; font-family:Arial, Helvetica, sans-serif;">
                    <div style="max-width:720px; margin:0 auto; padding:36px 18px;">
                        
                        <div style="
                            background:linear-gradient(135deg, #052e1a, #0f5132, #198754);
                            border-radius:30px;
                            overflow:hidden;
                            box-shadow:0 22px 50px rgba(15, 81, 50, 0.32);
                        ">
                            
                            <div style="padding:30px 34px 24px 34px; color:white;">
                                <div style="
                                    display:inline-block;
                                    padding:8px 14px;
                                    border-radius:999px;
                                    background:rgba(255,255,255,0.16);
                                    font-size:12px;
                                    letter-spacing:2px;
                                    text-transform:uppercase;
                                    font-weight:700;
                                ">
                                    FootStats Electronic Ticket
                                </div>

                                <div style="font-size:36px; font-weight:900; margin-top:18px; line-height:1.15;">
                                    Билет подтверждён
                                </div>

                                <div style="font-size:15px; margin-top:10px; opacity:0.9; line-height:1.6;">
                                    Покупка успешно завершена. Сохраните это письмо и покажите билет при входе на матч.
                                </div>
                            </div>
                            
                            <div style="
                                background:#ffffff;
                                margin:0 18px 18px 18px;
                                border-radius:26px;
                                overflow:hidden;
                            ">
                                
                                <div style="padding:28px 32px; border-bottom:2px dashed #cfe8d8;">
                                    <div style="
                                        font-size:12px;
                                        color:#198754;
                                        text-transform:uppercase;
                                        letter-spacing:2px;
                                        font-weight:800;
                                    ">
                                        Match
                                    </div>

                                    <div style="
                                        font-size:26px;
                                        font-weight:900;
                                        color:#123524;
                                        margin-top:9px;
                                        line-height:1.25;
                                    ">
                                        %s
                                    </div>
                                </div>
                                
                                <div style="padding:26px 32px;">
                                    <table style="width:100%%; border-collapse:collapse;">
                                        <tr>
                                            <td style="padding:13px 0; color:#6c757d; font-size:14px;">Номер билета</td>
                                            <td style="padding:13px 0; text-align:right; font-size:20px; font-weight:900; color:#198754;">
                                                #%d
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="padding:13px 0; color:#6c757d; font-size:14px; border-top:1px solid #edf3ef;">Тип билета</td>
                                            <td style="padding:13px 0; text-align:right; font-size:16px; font-weight:800; color:#123524; border-top:1px solid #edf3ef;">
                                                %s
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="padding:13px 0; color:#6c757d; font-size:14px; border-top:1px solid #edf3ef;">Сектор</td>
                                            <td style="padding:13px 0; text-align:right; font-size:16px; font-weight:800; color:#123524; border-top:1px solid #edf3ef;">
                                                %s
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="padding:13px 0; color:#6c757d; font-size:14px; border-top:1px solid #edf3ef;">Ряд</td>
                                            <td style="padding:13px 0; text-align:right; font-size:16px; font-weight:800; color:#123524; border-top:1px solid #edf3ef;">
                                                %d
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="padding:13px 0; color:#6c757d; font-size:14px; border-top:1px solid #edf3ef;">Место</td>
                                            <td style="padding:13px 0; text-align:right; font-size:16px; font-weight:800; color:#123524; border-top:1px solid #edf3ef;">
                                                %d
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div style="
                                    margin:0 32px 30px 32px;
                                    padding:22px;
                                    border-radius:22px;
                                    background:linear-gradient(135deg, #e8f7ef, #f7fffa);
                                    border:1px solid #cdebd9;
                                ">
                                    <div style="
                                        font-size:12px;
                                        color:#198754;
                                        text-transform:uppercase;
                                        letter-spacing:2px;
                                        font-weight:800;
                                    ">
                                        Стоимость
                                    </div>

                                    <div style="
                                        font-size:34px;
                                        font-weight:900;
                                        color:#0f5132;
                                        margin-top:7px;
                                    ">
                                        %s MDL
                                    </div>
                                </div>
                                
                                <div style="
                                    background:#f8faf9;
                                    padding:20px 32px;
                                    color:#66736b;
                                    font-size:13px;
                                    line-height:1.7;
                                ">
                                    Этот билет был автоматически создан системой FootStats.
                                    Не удаляйте письмо до окончания матча.
                                </div>
                            </div>
                        </div>
                        
                        <div style="
                            text-align:center;
                            color:#7d8b84;
                            font-size:12px;
                            margin-top:22px;
                            line-height:1.6;
                        ">
                            FootStats · Track the Game. Own the Stats.
                        </div>
                    </div>
                </body>
                </html>
                """.formatted(
                escapeHtml(game),
                ticketId,
                escapeHtml(type),
                escapeHtml(sector),
                row,
                place,
                price == null ? "0.00" : price.toPlainString()
        );
    }

    private String escapeHtml(String text) {
        if (text == null) {
            return "";
        }

        return text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}