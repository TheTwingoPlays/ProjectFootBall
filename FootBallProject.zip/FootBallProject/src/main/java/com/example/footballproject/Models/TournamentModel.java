package com.example.footballproject.Models;

public class TournamentModel {
    private final int id;
    private final String name;
    private final int teamsCount;
    private final int stadiumsCount;
    private final String teams;
    private final String stadiums;

    public TournamentModel(int id, String name, int teamsCount, int stadiumsCount, String teams, String stadiums) {
        this.id = id;
        this.name = name;
        this.teamsCount = teamsCount;
        this.stadiumsCount = stadiumsCount;
        this.teams = teams;
        this.stadiums = stadiums;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getTeamsCount() {
        return teamsCount;
    }

    public int getStadiumsCount() {
        return stadiumsCount;
    }

    public String getTeams() {
        return teams;
    }

    public String getStadiums() {
        return stadiums;
    }
}
