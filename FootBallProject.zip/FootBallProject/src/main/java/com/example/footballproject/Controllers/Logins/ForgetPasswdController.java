package com.example.footballproject.Controllers.Logins;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

public class ForgetPasswdController {

    @FXML private TextField emailField;
    @FXML private TextField codeField;

    @FXML private PasswordField newPasswordField;
    @FXML private PasswordField confirmPasswordField;

    @FXML private TextField newPasswordVisibleField;
    @FXML private TextField confirmPasswordVisibleField;

    @FXML private Button toggleNewPasswordBtn;
    @FXML private Button toggleConfirmPasswordBtn;

    @FXML private Button sendCodeButton;
    @FXML private Button resetButton;
    @FXML private Label messageLabel;

    private String generatedCode;
    private String codeEmail;

    private boolean newPasswordVisible = false;
    private boolean confirmPasswordVisible = false;

    private static final String FROM_EMAIL = "borisovdimap2414@gmail.com";
    private static final String FROM_PASSWORD = "nuen yild yuhl fdyn";

    @FXML
    public void initialize() {
        syncPasswordFields();
    }

    private void syncPasswordFields() {
        newPasswordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newPasswordVisible) {
                newPasswordVisibleField.setText(newVal);
            }
        });

        newPasswordVisibleField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newPasswordVisible) {
                newPasswordField.setText(newVal);
            }
        });

        confirmPasswordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!confirmPasswordVisible) {
                confirmPasswordVisibleField.setText(newVal);
            }
        });

        confirmPasswordVisibleField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (confirmPasswordVisible) {
                confirmPasswordField.setText(newVal);
            }
        });
    }

    @FXML
    private void toggleNewPasswordVisibility() {
        newPasswordVisible = !newPasswordVisible;

        if (newPasswordVisible) {
            newPasswordVisibleField.setText(newPasswordField.getText());
            newPasswordVisibleField.setVisible(true);
            newPasswordVisibleField.setManaged(true);

            newPasswordField.setVisible(false);
            newPasswordField.setManaged(false);

            toggleNewPasswordBtn.setText("🙈");
        } else {
            newPasswordField.setText(newPasswordVisibleField.getText());
            newPasswordField.setVisible(true);
            newPasswordField.setManaged(true);

            newPasswordVisibleField.setVisible(false);
            newPasswordVisibleField.setManaged(false);

            toggleNewPasswordBtn.setText("👁");
        }
    }

    @FXML
    private void toggleConfirmPasswordVisibility() {
        confirmPasswordVisible = !confirmPasswordVisible;

        if (confirmPasswordVisible) {
            confirmPasswordVisibleField.setText(confirmPasswordField.getText());
            confirmPasswordVisibleField.setVisible(true);
            confirmPasswordVisibleField.setManaged(true);

            confirmPasswordField.setVisible(false);
            confirmPasswordField.setManaged(false);

            toggleConfirmPasswordBtn.setText("🙈");
        } else {
            confirmPasswordField.setText(confirmPasswordVisibleField.getText());
            confirmPasswordField.setVisible(true);
            confirmPasswordField.setManaged(true);

            confirmPasswordVisibleField.setVisible(false);
            confirmPasswordVisibleField.setManaged(false);

            toggleConfirmPasswordBtn.setText("👁");
        }
    }

    @FXML
    public void handleSendCode(ActionEvent actionEvent) {
        clearMessage();

        String email = emailField.getText().trim();

        if (email.isEmpty()) {
            showError("Please enter your email.");
            return;
        }

        if (!isValidEmail(email)) {
            showError("Please enter a valid email address.");
            return;
        }

        try {
            if (!DatabaseHandler.emailExists(email)) {
                showError("No account found with this email.");
                return;
            }

            generatedCode = generateCode();
            codeEmail = email;

            sendResetCodeEmail(email, generatedCode);

            sendCodeButton.setText("Resend");
            showSuccess("Code sent to your email.");

        } catch (Exception e) {
            e.printStackTrace();

            System.out.println("Code for " + email + ": " + generatedCode);
            showError("Mail error. Check console.");
        }
    }

    @FXML
    public void handleResetPassword(ActionEvent actionEvent) {
        clearMessage();

        String email = emailField.getText().trim();
        String code = codeField.getText().trim();

        String newPassword = newPasswordVisible
                ? newPasswordVisibleField.getText()
                : newPasswordField.getText();

        String confirmPassword = confirmPasswordVisible
                ? confirmPasswordVisibleField.getText()
                : confirmPasswordField.getText();

        if (email.isEmpty() || code.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            showError("Please fill in all fields.");
            return;
        }

        if (!isValidEmail(email)) {
            showError("Please enter a valid email address.");
            return;
        }

        if (generatedCode == null) {
            showError("Please send reset code first.");
            return;
        }

        if (!email.equals(codeEmail)) {
            showError("Email was changed. Send code again.");
            return;
        }

        if (!code.equals(generatedCode)) {
            showError("Invalid verification code.");
            return;
        }

        if (newPassword.length() < 6) {
            showError("Password must be at least 6 characters.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            showError("Passwords do not match.");
            return;
        }

        try {
            DatabaseHandler.updatePasswordByEmail(email, newPassword);

            showSuccess("Password changed successfully!");

            clearFields();

            new Thread(() -> {
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Platform.runLater(this::goToLogin);
            }).start();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML
    public void handleBackToLogin(ActionEvent actionEvent) {
        goToLogin();
    }

    private void goToLogin() {
        try {
            Parent root = FXMLLoader.load(
                    getClass().getResource("/com/example/footballproject/LoginsFxml/Login.fxml")
            );

            Stage stage = (Stage) resetButton.getScene().getWindow();
            Scene scene = new Scene(root);

            stage.setFullScreen(false);
            stage.setMaximized(false);

            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();

            Platform.runLater(() -> {
                stage.setMaximized(true);
                stage.toFront();
            });

        } catch (Exception e) {
            e.printStackTrace();
            showError("Navigation error: " + e.getMessage());
        }
    }

    private void sendResetCodeEmail(String toEmail, String code)
            throws MessagingException, UnsupportedEncodingException {

        Properties props = new Properties();

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, FROM_PASSWORD);
            }
        });

        Message message = new MimeMessage(session);

        message.setFrom(new InternetAddress(FROM_EMAIL, "FootStats"));
        message.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(toEmail)
        );

        message.setSubject("FootStats password reset code");

        String htmlMessage = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                </head>
                <body style="margin:0; padding:0; background-color:#edf3ee; font-family:Arial, sans-serif;">
                    <table width="100%%" cellpadding="0" cellspacing="0" style="background-color:#edf3ee; padding:40px 0;">
                        <tr>
                            <td align="center">
                                <table width="520" cellpadding="0" cellspacing="0"
                                       style="background-color:#ffffff; border-radius:22px; overflow:hidden; box-shadow:0 14px 35px rgba(52,78,65,0.22);">
                                    
                                    <tr>
                                        <td style="background:linear-gradient(135deg, #344e41, #588157); padding:34px 30px; text-align:center;">
                                            <div style="font-size:34px; margin-bottom:8px;">⚽</div>
                                            <div style="font-size:28px; font-weight:900; color:#f8f7f4; letter-spacing:1px;">
                                                FootStats
                                            </div>
                                            <div style="font-size:14px; color:#dad7cd; margin-top:8px;">
                                                Password recovery
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td style="padding:36px 42px 18px 42px; text-align:center;">
                                            <h2 style="margin:0; color:#18231d; font-size:26px;">
                                                Reset your password
                                            </h2>
                                            
                                            <p style="color:#6c7a70; font-size:15px; line-height:1.6; margin:16px 0 26px 0;">
                                                Use the code below to reset your FootStats account password.
                                            </p>
                                            
                                            <div style="
                                                display:inline-block;
                                                background-color:#edf3ee;
                                                border:2px solid #a3b18a;
                                                color:#344e41;
                                                font-size:38px;
                                                font-weight:900;
                                                letter-spacing:8px;
                                                padding:18px 28px;
                                                border-radius:16px;">
                                                %s
                                            </div>
                                            
                                            <p style="color:#6c7a70; font-size:14px; margin:28px 0 0 0;">
                                                This code is valid only for this password reset request.
                                            </p>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td style="padding:22px 42px 34px 42px; text-align:center;">
                                            <div style="height:1px; background-color:#d9e1d4; margin-bottom:20px;"></div>
                                            
                                            <p style="color:#97a29a; font-size:12px; line-height:1.5; margin:0;">
                                                If you did not request password recovery, you can safely ignore this email.
                                            </p>
                                        </td>
                                    </tr>
                                    
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
                """.formatted(code);

        message.setContent(htmlMessage, "text/html; charset=UTF-8");

        Transport.send(message);
    }

    private void clearFields() {
        emailField.clear();
        codeField.clear();

        newPasswordField.clear();
        confirmPasswordField.clear();

        newPasswordVisibleField.clear();
        confirmPasswordVisibleField.clear();

        newPasswordVisible = false;
        confirmPasswordVisible = false;

        newPasswordField.setVisible(true);
        newPasswordField.setManaged(true);
        newPasswordVisibleField.setVisible(false);
        newPasswordVisibleField.setManaged(false);

        confirmPasswordField.setVisible(true);
        confirmPasswordField.setManaged(true);
        confirmPasswordVisibleField.setVisible(false);
        confirmPasswordVisibleField.setManaged(false);

        toggleNewPasswordBtn.setText("👁");
        toggleConfirmPasswordBtn.setText("👁");

        generatedCode = null;
        codeEmail = null;

        if (sendCodeButton != null) {
            sendCodeButton.setText("Send code");
        }
    }

    private String generateCode() {
        return String.valueOf(new Random().nextInt(900000) + 100000);
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$");
    }

    private void showError(String message) {
        messageLabel.setStyle("-fx-text-fill: #c14444;");
        messageLabel.setText(message);
    }

    private void showSuccess(String message) {
        messageLabel.setStyle("-fx-text-fill: #3a5a40;");
        messageLabel.setText(message);
    }

    private void clearMessage() {
        messageLabel.setText("");
        messageLabel.setStyle("-fx-text-fill: #c14444;");
    }
}