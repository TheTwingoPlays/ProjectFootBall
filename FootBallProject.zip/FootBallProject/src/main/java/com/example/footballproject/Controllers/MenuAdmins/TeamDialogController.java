package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.TeamModel;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.SQLException;

public class TeamDialogController {

    @FXML private Label titleLabel;
    @FXML private Label messageLabel;

    @FXML private TextField nameField;
    @FXML private TextField countryField;

    @FXML private Button saveButton;

    private boolean saved = false;
    private boolean editMode = false;
    private int editingTeamId = -1;

    public void setEditTeamId(int teamId) {
        this.editMode = true;
        this.editingTeamId = teamId;

        titleLabel.setText("Редактировать команду");
        saveButton.setText("Сохранить изменения");

        loadTeamForEdit(teamId);
    }

    private void loadTeamForEdit(int teamId) {
        try {
            TeamModel team = DatabaseHandler.getTeamById(teamId);

            nameField.setText(team.getName());
            countryField.setText(team.getCountry());

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки команды: " + e.getMessage());
        }
    }

    @FXML
    private void handleSave() {
        clearMessage();

        String name = nameField.getText().trim();
        String country = countryField.getText().trim();

        if (name.isEmpty()) {
            showError("Введите название команды.");
            return;
        }

        if (country.isEmpty()) {
            country = "Unknown";
        }

        try {
            if (editMode) {
                DatabaseHandler.updateTeam(editingTeamId, name, country);
            } else {
                DatabaseHandler.addTeam(name, country);
            }

            saved = true;
            closeWindow();

        } catch (SQLException e) {
            e.printStackTrace();

            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("duplicate")) {
                showError("Такая команда уже существует.");
            } else {
                showError("Ошибка сохранения команды: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    public boolean isSaved() {
        return saved;
    }

    private void closeWindow() {
        Stage stage = (Stage) messageLabel.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        messageLabel.setStyle("-fx-text-fill: #c14444;");
        messageLabel.setText(message);
    }

    private void clearMessage() {
        messageLabel.setText("");
    }
}