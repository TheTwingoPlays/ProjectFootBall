package com.example.footballproject.Controllers.Logins;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

public class RegisterController {

    @FXML public Button registerButton;
    @FXML public Label errorLabel;

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private TextField codeField;

    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;

    @FXML private TextField passwordVisibleField;
    @FXML private TextField confirmPasswordVisibleField;

    @FXML private Button togglePasswordBtn;
    @FXML private Button toggleConfirmPasswordBtn;

    @FXML private RadioButton termsRadio;
    @FXML private Button sendCodeButton;

    private static final String FROM_EMAIL = "borisovdimap2414@gmail.com";
    private static final String FROM_PASSWORD = "nuen yild yuhl fdyn";

    private String generatedCode;
    private String codeEmail;

    private boolean passwordVisible = false;
    private boolean confirmPasswordVisible = false;

    @FXML
    public void initialize() {
        syncPasswordFields();
    }

    private void syncPasswordFields() {
        passwordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!passwordVisible) {
                passwordVisibleField.setText(newVal);
            }
        });

        passwordVisibleField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (passwordVisible) {
                passwordField.setText(newVal);
            }
        });

        confirmPasswordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!confirmPasswordVisible) {
                confirmPasswordVisibleField.setText(newVal);
            }
        });

        confirmPasswordVisibleField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (confirmPasswordVisible) {
                confirmPasswordField.setText(newVal);
            }
        });
    }

    @FXML
    private void togglePasswordVisibility() {
        passwordVisible = !passwordVisible;

        if (passwordVisible) {
            passwordVisibleField.setText(passwordField.getText());
            passwordVisibleField.setVisible(true);
            passwordVisibleField.setManaged(true);

            passwordField.setVisible(false);
            passwordField.setManaged(false);

            togglePasswordBtn.setText("🙈");
        } else {
            passwordField.setText(passwordVisibleField.getText());
            passwordField.setVisible(true);
            passwordField.setManaged(true);

            passwordVisibleField.setVisible(false);
            passwordVisibleField.setManaged(false);

            togglePasswordBtn.setText("👁");
        }
    }

    @FXML
    private void toggleConfirmPasswordVisibility() {
        confirmPasswordVisible = !confirmPasswordVisible;

        if (confirmPasswordVisible) {
            confirmPasswordVisibleField.setText(confirmPasswordField.getText());
            confirmPasswordVisibleField.setVisible(true);
            confirmPasswordVisibleField.setManaged(true);

            confirmPasswordField.setVisible(false);
            confirmPasswordField.setManaged(false);

            toggleConfirmPasswordBtn.setText("🙈");
        } else {
            confirmPasswordField.setText(confirmPasswordVisibleField.getText());
            confirmPasswordField.setVisible(true);
            confirmPasswordField.setManaged(true);

            confirmPasswordVisibleField.setVisible(false);
            confirmPasswordVisibleField.setManaged(false);

            toggleConfirmPasswordBtn.setText("👁");
        }
    }

    @FXML
    public void handleTerms(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/footballproject/LoginsFxml/Teams.fxml")
            );

            Parent root = loader.load();

            Stage termsStage = new Stage();
            termsStage.setTitle("Terms of Service — FootStats");
            termsStage.setScene(new Scene(root, 800, 600));
            termsStage.initModality(Modality.APPLICATION_MODAL);
            termsStage.initOwner(registerButton.getScene().getWindow());
            termsStage.setResizable(false);
            termsStage.show();

        } catch (Exception e) {
            showError("Could not open Terms of Service: " + e.getMessage());
        }
    }

    @FXML
    public void handleSendCode(ActionEvent actionEvent) {
        String email = emailField.getText().trim();

        clearMessage();

        if (email.isEmpty()) {
            showError("Please enter your email first.");
            return;
        }

        if (!isValidEmail(email)) {
            showError("Please enter a valid email address.");
            return;
        }

        generatedCode = generateCode();
        codeEmail = email;

        try {
            sendEmailCode(email, generatedCode);

            showSuccess("Verification code sent to your email.");
            sendCodeButton.setText("Resend");

        } catch (Exception e) {
            e.printStackTrace();

            System.out.println("Verification code for " + email + ": " + generatedCode);

            showError("Mail error. Code in console: " + generatedCode);
        }
    }

    @FXML
    public void handleRegister(ActionEvent actionEvent) {
        clearMessage();

        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String code = codeField.getText().trim();

        String password = passwordVisible
                ? passwordVisibleField.getText()
                : passwordField.getText();

        String confirm = confirmPasswordVisible
                ? confirmPasswordVisibleField.getText()
                : confirmPasswordField.getText();

        if (username.isEmpty() || email.isEmpty() || code.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            showError("Please fill in all fields.");
            return;
        }

        if (!isValidEmail(email)) {
            showError("Please enter a valid email address.");
            return;
        }

        if (generatedCode == null) {
            showError("Please send verification code first.");
            return;
        }

        if (!email.equals(codeEmail)) {
            showError("Email was changed. Please send code again.");
            return;
        }

        if (!code.equals(generatedCode)) {
            showError("Invalid verification code.");
            return;
        }

        if (password.length() < 6) {
            showError("Password must be at least 6 characters.");
            return;
        }

        if (!password.equals(confirm)) {
            showError("Passwords do not match.");
            return;
        }

        if (!termsRadio.isSelected()) {
            showError("You must agree to the Terms of Service.");
            return;
        }

        try {
            DatabaseHandler.registerUser(username, email, password);

            showSuccess("Account created successfully!");

            clearFields();

            new Thread(() -> {
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Platform.runLater(this::goToLogin);
            }).start();

        } catch (SQLException e) {
            e.printStackTrace();

            if (e.getMessage() != null && e.getMessage().contains("duplicate key")) {
                showError("Username or Email already exists!");
            } else {
                showError("Database error: " + e.getMessage());
            }
        }
    }

    private void clearFields() {
        usernameField.clear();
        emailField.clear();
        codeField.clear();

        passwordField.clear();
        confirmPasswordField.clear();

        passwordVisibleField.clear();
        confirmPasswordVisibleField.clear();

        termsRadio.setSelected(false);

        generatedCode = null;
        codeEmail = null;

        passwordVisible = false;
        confirmPasswordVisible = false;

        passwordField.setVisible(true);
        passwordField.setManaged(true);
        passwordVisibleField.setVisible(false);
        passwordVisibleField.setManaged(false);

        confirmPasswordField.setVisible(true);
        confirmPasswordField.setManaged(true);
        confirmPasswordVisibleField.setVisible(false);
        confirmPasswordVisibleField.setManaged(false);

        if (togglePasswordBtn != null) {
            togglePasswordBtn.setText("👁");
        }

        if (toggleConfirmPasswordBtn != null) {
            toggleConfirmPasswordBtn.setText("👁");
        }

        if (sendCodeButton != null) {
            sendCodeButton.setText("Send code");
        }
    }

    @FXML
    public void handleGoToLogin(ActionEvent actionEvent) {
        goToLogin();
    }

    private void goToLogin() {
        try {
            Parent root = FXMLLoader.load(
                    getClass().getResource("/com/example/footballproject/LoginsFxml/Login.fxml")
            );

            Stage stage = (Stage) registerButton.getScene().getWindow();
            Scene scene = new Scene(root);

            stage.setFullScreen(false);
            stage.setMaximized(false);

            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();

            Platform.runLater(() -> {
                stage.setMaximized(true);
                stage.toFront();
            });

        } catch (Exception e) {
            showError("Navigation error: " + e.getMessage());
        }
    }

    private void sendEmailCode(String toEmail, String code)
            throws MessagingException, UnsupportedEncodingException {

        String fromEmail = FROM_EMAIL;
        String password = FROM_PASSWORD;

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });

        Message message = new MimeMessage(session);

        message.setFrom(new InternetAddress(fromEmail, "FootStats"));
        message.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(toEmail)
        );

        message.setSubject("Your FootStats verification code");

        String htmlMessage = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                </head>
                <body style="margin:0; padding:0; background-color:#edf3ee; font-family:Arial, sans-serif;">
                    <table width="100%%" cellpadding="0" cellspacing="0" style="background-color:#edf3ee; padding:40px 0;">
                        <tr>
                            <td align="center">
                                <table width="520" cellpadding="0" cellspacing="0"
                                       style="background-color:#ffffff; border-radius:22px; overflow:hidden; box-shadow:0 14px 35px rgba(52,78,65,0.22);">
                                    
                                    <tr>
                                        <td style="background:linear-gradient(135deg, #344e41, #588157); padding:34px 30px; text-align:center;">
                                            <div style="font-size:34px; margin-bottom:8px;">⚽</div>
                                            <div style="font-size:28px; font-weight:900; color:#f8f7f4; letter-spacing:1px;">
                                                FootStats
                                            </div>
                                            <div style="font-size:14px; color:#dad7cd; margin-top:8px;">
                                                Football analytics platform
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td style="padding:36px 42px 18px 42px; text-align:center;">
                                            <h2 style="margin:0; color:#18231d; font-size:26px;">
                                                Verify your email
                                            </h2>
                                            
                                            <p style="color:#6c7a70; font-size:15px; line-height:1.6; margin:16px 0 26px 0;">
                                                Thanks for joining FootStats. Use the verification code below to complete your registration.
                                            </p>
                                            
                                            <div style="
                                                display:inline-block;
                                                background-color:#edf3ee;
                                                border:2px solid #a3b18a;
                                                color:#344e41;
                                                font-size:38px;
                                                font-weight:900;
                                                letter-spacing:8px;
                                                padding:18px 28px;
                                                border-radius:16px;">
                                                %s
                                            </div>
                                            
                                            <p style="color:#6c7a70; font-size:14px; margin:28px 0 0 0;">
                                                This code is valid only for this registration.
                                            </p>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td style="padding:22px 42px 34px 42px; text-align:center;">
                                            <div style="height:1px; background-color:#d9e1d4; margin-bottom:20px;"></div>
                                            
                                            <p style="color:#97a29a; font-size:12px; line-height:1.5; margin:0;">
                                                If you did not request this code, you can safely ignore this email.
                                            </p>
                                        </td>
                                    </tr>
                                    
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
                """.formatted(code);

        message.setContent(htmlMessage, "text/html; charset=UTF-8");

        Transport.send(message);
    }

    private String generateCode() {
        return String.valueOf(new Random().nextInt(900000) + 100000);
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$");
    }

    private void showError(String message) {
        errorLabel.setStyle("-fx-text-fill: #c14444;");
        errorLabel.setText(message);
    }

    private void showSuccess(String message) {
        errorLabel.setStyle("-fx-text-fill: #3a5a40;");
        errorLabel.setText(message);
    }

    private void clearMessage() {
        errorLabel.setText("");
        errorLabel.setStyle("-fx-text-fill: #c14444;");
    }
}