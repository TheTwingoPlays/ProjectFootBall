package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.StandingModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;

public class StandingsController {

    @FXML private ComboBox<OptionItem> tournamentComboBox;
    @FXML private Label summaryLabel;
    @FXML private TableView<StandingModel> standingsTable;

    @FXML private TableColumn<StandingModel, Integer> colPosition;
    @FXML private TableColumn<StandingModel, String> colTeam;
    @FXML private TableColumn<StandingModel, Integer> colPlayed;
    @FXML private TableColumn<StandingModel, Integer> colWins;
    @FXML private TableColumn<StandingModel, Integer> colDraws;
    @FXML private TableColumn<StandingModel, Integer> colLosses;
    @FXML private TableColumn<StandingModel, Integer> colGoalsFor;
    @FXML private TableColumn<StandingModel, Integer> colGoalsAgainst;
    @FXML private TableColumn<StandingModel, Integer> colGoalDifference;
    @FXML private TableColumn<StandingModel, Integer> colPoints;

    @FXML
    private void initialize() {
        setupTable();
        loadTournaments();
    }

    private void setupTable() {
        colPosition.setCellValueFactory(new PropertyValueFactory<>("position"));
        colTeam.setCellValueFactory(new PropertyValueFactory<>("teamName"));
        colPlayed.setCellValueFactory(new PropertyValueFactory<>("played"));
        colWins.setCellValueFactory(new PropertyValueFactory<>("wins"));
        colDraws.setCellValueFactory(new PropertyValueFactory<>("draws"));
        colLosses.setCellValueFactory(new PropertyValueFactory<>("losses"));
        colGoalsFor.setCellValueFactory(new PropertyValueFactory<>("goalsFor"));
        colGoalsAgainst.setCellValueFactory(new PropertyValueFactory<>("goalsAgainst"));
        colGoalDifference.setCellValueFactory(new PropertyValueFactory<>("goalDifference"));
        colPoints.setCellValueFactory(new PropertyValueFactory<>("points"));
    }

    private void loadTournaments() {
        try {
            tournamentComboBox.setItems(DatabaseHandler.getTournamentsOptions());

            if (!tournamentComboBox.getItems().isEmpty()) {
                tournamentComboBox.getSelectionModel().selectFirst();
                loadStandings();
            } else {
                summaryLabel.setText("Нет турниров для отображения.");
            }
        } catch (SQLException e) {
            showError("Ошибка загрузки турниров: " + e.getMessage());
        }
    }

    @FXML
    private void loadStandings() {
        OptionItem tournament = tournamentComboBox.getValue();

        if (tournament == null) {
            standingsTable.getItems().clear();
            summaryLabel.setText("Выберите турнир.");
            return;
        }

        try {
            ObservableList<StandingModel> standings = DatabaseHandler.getStandingsByTournament(tournament.getId());
            standingsTable.setItems(standings);
            standingsTable.refresh();
            summaryLabel.setText("Турнир: " + tournament.getName() + ". Команд: " + standings.size() + ".");
        } catch (SQLException e) {
            showError("Ошибка загрузки таблицы: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
