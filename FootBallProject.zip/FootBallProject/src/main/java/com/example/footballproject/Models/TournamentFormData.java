package com.example.footballproject.Models;

import java.util.List;

public class TournamentFormData {
    private final int id;
    private final String name;
    private final List<Integer> teamIds;
    private final List<Integer> stadiumIds;

    public TournamentFormData(int id, String name, List<Integer> teamIds, List<Integer> stadiumIds) {
        this.id = id;
        this.name = name;
        this.teamIds = teamIds;
        this.stadiumIds = stadiumIds;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Integer> getTeamIds() {
        return teamIds;
    }

    public List<Integer> getStadiumIds() {
        return stadiumIds;
    }
}
