package com.example.footballproject.Controllers.MenuAdmins;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ToggleButton;

public class SettingController {

    @FXML private ToggleButton darkModeToggle;
    @FXML private ComboBox<String> languageComboBox;
    @FXML private ComboBox<String> scaleComboBox;

    private static boolean darkModeEnabled = false;

    @FXML
    public void initialize() {
        languageComboBox.getItems().addAll("Русский", "English", "Română");
        languageComboBox.setValue("Русский");

        scaleComboBox.getItems().addAll("90%", "100%", "110%", "125%");
        scaleComboBox.setValue("100%");

        darkModeToggle.setSelected(darkModeEnabled);
        darkModeToggle.setText(darkModeEnabled ? "ON" : "OFF");

        Platform.runLater(() -> applyTheme(darkModeEnabled));
    }

    @FXML
    private void handleDarkModeToggle() {
        darkModeEnabled = darkModeToggle.isSelected();
        darkModeToggle.setText(darkModeEnabled ? "ON" : "OFF");

        applyTheme(darkModeEnabled);
    }

    private void applyTheme(boolean enabled) {
        if (darkModeToggle.getScene() == null) {
            return;
        }

        Parent root = darkModeToggle.getScene().getRoot();

        if (enabled) {
            root.getStyleClass().remove("dash-root");

            if (!root.getStyleClass().contains("dash-root-dark")) {
                root.getStyleClass().add("dash-root-dark");
            }
        } else {
            root.getStyleClass().remove("dash-root-dark");

            if (!root.getStyleClass().contains("dash-root")) {
                root.getStyleClass().add("dash-root");
            }
        }
    }
}