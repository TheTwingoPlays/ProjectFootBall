package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.GameModel;
import com.example.footballproject.Models.OptionItem;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.LocalDate;

public class GameController {

    @FXML private TextField searchField;
    @FXML private ComboBox<OptionItem> tournamentFilterComboBox;
    @FXML private ComboBox<OptionItem> teamFilterComboBox;
    @FXML private ComboBox<OptionItem> stadiumFilterComboBox;
    @FXML private ComboBox<OptionItem> refereeFilterComboBox;
    @FXML private DatePicker dateFilterPicker;

    @FXML private TableView<GameModel> gamesTable;

    @FXML private TableColumn<GameModel, Integer> colId;
    @FXML private TableColumn<GameModel, String> colDate;
    @FXML private TableColumn<GameModel, String> colTime;
    @FXML private TableColumn<GameModel, String> colHomeTeam;
    @FXML private TableColumn<GameModel, String> colAwayTeam;
    @FXML private TableColumn<GameModel, String> colTournament;
    @FXML private TableColumn<GameModel, String> colStadium;
    @FXML private TableColumn<GameModel, String> colReferee;
    @FXML private TableColumn<GameModel, String> colScore;

    @FXML
    public void initialize() {
        setupTable();
        loadFilters();
        loadGames();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colTime.setCellValueFactory(new PropertyValueFactory<>("time"));
        colHomeTeam.setCellValueFactory(new PropertyValueFactory<>("homeTeam"));
        colAwayTeam.setCellValueFactory(new PropertyValueFactory<>("awayTeam"));
        colTournament.setCellValueFactory(new PropertyValueFactory<>("tournament"));
        colStadium.setCellValueFactory(new PropertyValueFactory<>("stadium"));
        colReferee.setCellValueFactory(new PropertyValueFactory<>("referee"));
        colScore.setCellValueFactory(new PropertyValueFactory<>("score"));
    }

    private void loadFilters() {
        try {
            tournamentFilterComboBox.setItems(DatabaseHandler.getTournamentsOptions());
            teamFilterComboBox.setItems(DatabaseHandler.getTeamsOptions());
            stadiumFilterComboBox.setItems(DatabaseHandler.getStadiumsOptions());
            refereeFilterComboBox.setItems(DatabaseHandler.getRefereesOptions());
        } catch (SQLException e) {
            e.printStackTrace();
            showError("Ошибка загрузки фильтров: " + e.getMessage());
        }
    }

    private void loadGames() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();

            OptionItem tournament = tournamentFilterComboBox.getValue();
            Integer tournamentId = tournament == null ? null : tournament.getId();

            OptionItem team = teamFilterComboBox.getValue();
            Integer teamId = team == null ? null : team.getId();

            OptionItem stadium = stadiumFilterComboBox.getValue();
            Integer stadiumId = stadium == null ? null : stadium.getId();

            OptionItem referee = refereeFilterComboBox.getValue();
            Integer refereeId = referee == null ? null : referee.getId();

            LocalDate date = dateFilterPicker.getValue();

            ObservableList<GameModel> games = DatabaseHandler.getGamesAnalytics(
                    keyword,
                    tournamentId,
                    date,
                    teamId,
                    stadiumId,
                    refereeId
            );

            System.out.println("Table items: " + games.size());

            gamesTable.getItems().clear();
            gamesTable.setItems(games);
            gamesTable.refresh();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        loadGames();
    }

    @FXML
    private void handleFilter() {
        loadGames();
    }

    @FXML
    private void handleClearFilters() {
        searchField.clear();
        tournamentFilterComboBox.setValue(null);
        teamFilterComboBox.setValue(null);
        stadiumFilterComboBox.setValue(null);
        refereeFilterComboBox.setValue(null);
        dateFilterPicker.setValue(null);
        loadGames();
    }

    @FXML
    private void handleAdd() {
        openGameDialog(null);
    }

    @FXML
    private void handleEdit() {
        GameModel selectedGame = gamesTable.getSelectionModel().getSelectedItem();

        if (selectedGame == null) {
            showWarning("Выберите матч для изменения.");
            return;
        }

        openGameDialog(selectedGame.getId());
    }

    private void openGameDialog(Integer gameId) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/footballproject/MenuFxml/GameDialog.fxml")
            );

            Parent root = loader.load();

            GameDialogController controller = loader.getController();

            if (gameId != null) {
                controller.setEditGameId(gameId);
            }

            Stage stage = new Stage();
            stage.setTitle(gameId == null ? "Добавить матч" : "Редактировать матч");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadGames();
                showInfo("Успешно", gameId == null ? "Матч добавлен." : "Матч обновлён.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Не удалось открыть окно матча: " + e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        GameModel selectedGame = gamesTable.getSelectionModel().getSelectedItem();

        if (selectedGame == null) {
            showWarning("Выберите матч для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление матча");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Удалить матч: " +
                        selectedGame.getHomeTeam() +
                        " vs " +
                        selectedGame.getAwayTeam() +
                        "?"
        );

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedGame(selectedGame);
            }
        });
    }

    private void deleteSelectedGame(GameModel game) {
        try {
            DatabaseHandler.deleteGameById(game.getId());
            loadGames();
            showInfo("Успешно", "Матч удалён.");

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
