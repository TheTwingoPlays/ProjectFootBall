package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.StadiumModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;

public class StadiumsController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> cityFilterComboBox;

    @FXML private TableView<StadiumModel> stadiumsTable;

    @FXML private TableColumn<StadiumModel, Integer> colId;
    @FXML private TableColumn<StadiumModel, String> colName;
    @FXML private TableColumn<StadiumModel, String> colCity;
    @FXML private TableColumn<StadiumModel, Integer> colCapacity;

    private boolean loadingFilterItems;

    @FXML
    private void initialize() {
        setupTable();
        loadStadiums();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        colCapacity.setCellValueFactory(new PropertyValueFactory<>("capacity"));
    }

    private void loadStadiums() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();
            String city = cityFilterComboBox.getValue();

            ObservableList<StadiumModel> stadiums = DatabaseHandler.getStadiums(keyword, city);

            stadiumsTable.getItems().clear();
            stadiumsTable.setItems(stadiums);
            stadiumsTable.refresh();
            loadCityFilterItems();
        } catch (SQLException e) {
            showError("Database error: " + e.getMessage());
        }
    }

    private void loadCityFilterItems() throws SQLException {
        String selectedCity = cityFilterComboBox.getValue();
        loadingFilterItems = true;
        cityFilterComboBox.setItems(DatabaseHandler.getStadiumCities());
        cityFilterComboBox.setValue(selectedCity);
        loadingFilterItems = false;
    }

    @FXML
    private void handleSearch() {
        loadStadiums();
    }

    @FXML
    private void handleFilter() {
        if (loadingFilterItems) {
            return;
        }

        loadStadiums();
    }

    @FXML
    private void handleClearFilters() {
        searchField.clear();
        cityFilterComboBox.setValue(null);
        loadStadiums();
    }

    @FXML
    private void handleAdd() {
        openStadiumDialog(null);
    }

    @FXML
    private void handleEdit() {
        StadiumModel selectedStadium = stadiumsTable.getSelectionModel().getSelectedItem();

        if (selectedStadium == null) {
            showWarning("Выберите стадион для изменения.");
            return;
        }

        openStadiumDialog(selectedStadium);
    }

    @FXML
    private void handleDelete() {
        StadiumModel selectedStadium = stadiumsTable.getSelectionModel().getSelectedItem();

        if (selectedStadium == null) {
            showWarning("Выберите стадион для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление стадиона");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Удалить стадион \"" + selectedStadium.getName() + "\"?\n\n" +
                        "Связи с турнирами будут удалены. Матчи могут помешать удалению, если база запрещает это."
        );

        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);

        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedStadium(selectedStadium);
            }
        });
    }

    private void openStadiumDialog(StadiumModel stadium) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/footballproject/MenuFxml/StadiumDialog.fxml"));
            Parent root = loader.load();

            StadiumDialogController controller = loader.getController();
            controller.setStadium(stadium);

            Stage stage = new Stage();
            stage.setTitle(stadium == null ? "Добавить стадион" : "Редактировать стадион");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadStadiums();
                showInfo("Успешно", stadium == null ? "Стадион добавлен." : "Стадион обновлён.");
            }
        } catch (Exception e) {
            showError("Не удалось открыть окно стадиона: " + e.getMessage());
        }
    }

    private void deleteSelectedStadium(StadiumModel stadium) {
        try {
            DatabaseHandler.deleteStadiumById(stadium.getId());
            loadStadiums();
            showInfo("Успешно", "Стадион удалён.");
        } catch (SQLException e) {
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
