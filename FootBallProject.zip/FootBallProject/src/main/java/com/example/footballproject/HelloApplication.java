package com.example.footballproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/com/example/footballproject/LoginsFxml/Login.fxml")
        );

        Parent root = loader.load();
        Scene scene = new Scene(root);

        stage.setTitle("FootStats");
        stage.getIcons().add(new Image(String.valueOf(
                getClass().getResource("/com/example/footballproject/foto/app-icon.png")
        )));
        stage.setScene(scene);


        stage.setMaximized(true);

        stage.show();
    }
}
