package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.TeamModel;
import com.example.footballproject.Models.TournamentFormData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TournamentDialogController {

    @FXML private Label titleLabel;
    @FXML private TextField nameField;
    @FXML private ComboBox<String> countryFilterComboBox;
    @FXML private VBox teamsBox;
    @FXML private VBox stadiumsBox;

    private boolean saved;
    private boolean editMode;
    private int editingTournamentId = -1;
    private final ObservableList<TeamModel> allTeams = FXCollections.observableArrayList();
    private final Set<Integer> selectedTeamIds = new HashSet<>();
    private final Map<Integer, CheckBox> teamChecks = new HashMap<>();
    private final Map<Integer, CheckBox> stadiumChecks = new HashMap<>();

    @FXML
    private void initialize() {
        loadOptions();
    }

    public void setEditTournamentId(int tournamentId) {
        editMode = true;
        editingTournamentId = tournamentId;
        titleLabel.setText("Редактировать турнир");
        loadTournament(tournamentId);
    }

    public boolean isSaved() {
        return saved;
    }

    private void loadOptions() {
        try {
            allTeams.setAll(DatabaseHandler.getTeams("", null));
            countryFilterComboBox.setItems(DatabaseHandler.getTeamCountries());
            fillTeamCheckBoxList();
            fillCheckBoxList(stadiumsBox, stadiumChecks, DatabaseHandler.getStadiumsOptions());
        } catch (SQLException e) {
            showError("Ошибка загрузки данных: " + e.getMessage());
        }
    }

    private void fillTeamCheckBoxList() {
        syncSelectedTeamIds();
        String selectedCountry = countryFilterComboBox.getValue();

        teamsBox.getChildren().clear();
        teamChecks.clear();

        for (TeamModel team : allTeams) {
            if (selectedCountry != null && !selectedCountry.equals(team.getCountry())) {
                continue;
            }

            CheckBox checkBox = new CheckBox(formatTeamName(team));
            checkBox.setUserData(team.getId());
            checkBox.setWrapText(true);
            checkBox.setSelected(selectedTeamIds.contains(team.getId()));
            checkBox.selectedProperty().addListener((observable, oldValue, selected) -> {
                if (selected) {
                    selectedTeamIds.add(team.getId());
                } else {
                    selectedTeamIds.remove(team.getId());
                }
            });
            teamChecks.put(team.getId(), checkBox);
            teamsBox.getChildren().add(checkBox);
        }
    }

    private void syncSelectedTeamIds() {
        for (Map.Entry<Integer, CheckBox> entry : teamChecks.entrySet()) {
            if (entry.getValue().isSelected()) {
                selectedTeamIds.add(entry.getKey());
            } else {
                selectedTeamIds.remove(entry.getKey());
            }
        }
    }

    private String formatTeamName(TeamModel team) {
        if (team.getCountry() == null || team.getCountry().isBlank()) {
            return team.getName();
        }

        return team.getName() + " / " + team.getCountry();
    }

    private void fillCheckBoxList(VBox box, Map<Integer, CheckBox> checks, ObservableList<OptionItem> items) {
        box.getChildren().clear();
        checks.clear();

        for (OptionItem item : items) {
            CheckBox checkBox = new CheckBox(item.getName());
            checkBox.setUserData(item.getId());
            checkBox.setWrapText(true);
            checks.put(item.getId(), checkBox);
            box.getChildren().add(checkBox);
        }
    }

    private void loadTournament(int tournamentId) {
        try {
            TournamentFormData tournament = DatabaseHandler.getTournamentById(tournamentId);
            nameField.setText(tournament.getName());
            selectedTeamIds.clear();
            selectedTeamIds.addAll(tournament.getTeamIds());
            countryFilterComboBox.setValue(null);
            fillTeamCheckBoxList();
            checkItemsByIds(teamChecks, tournament.getTeamIds());
            checkItemsByIds(stadiumChecks, tournament.getStadiumIds());
        } catch (SQLException e) {
            showError("Ошибка загрузки турнира: " + e.getMessage());
        }
    }

    private void checkItemsByIds(Map<Integer, CheckBox> checks, List<Integer> ids) {
        for (Integer id : ids) {
            CheckBox checkBox = checks.get(id);
            if (checkBox != null) {
                checkBox.setSelected(true);
            }
        }
    }

    @FXML
    private void handleSave() {
        if (!validateFields()) {
            return;
        }

        String name = nameField.getText().trim();
        List<Integer> teamIds = getSelectedTeamIds();
        List<Integer> stadiumIds = getCheckedIds(stadiumChecks);

        try {
            if (editMode) {
                DatabaseHandler.updateTournament(editingTournamentId, name, teamIds, stadiumIds);
            } else {
                DatabaseHandler.addTournament(name, teamIds, stadiumIds);
            }

            saved = true;
            closeWindow();
        } catch (SQLException e) {
            showError("Ошибка сохранения турнира: " + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (nameField.getText() == null || nameField.getText().trim().isEmpty()) {
            showError("Введите название турнира.");
            return false;
        }

        return true;
    }

    @FXML
    private void handleCountryFilter() {
        fillTeamCheckBoxList();
    }

    @FXML
    private void handleClearCountryFilter() {
        countryFilterComboBox.setValue(null);
        fillTeamCheckBoxList();
    }

    private List<Integer> getCheckedIds(Map<Integer, CheckBox> checks) {
        List<Integer> ids = new ArrayList<>();

        for (Map.Entry<Integer, CheckBox> entry : checks.entrySet()) {
            if (entry.getValue().isSelected()) {
                ids.add(entry.getKey());
            }
        }

        return ids;
    }

    private List<Integer> getSelectedTeamIds() {
        syncSelectedTeamIds();
        return new ArrayList<>(selectedTeamIds);
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) nameField.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
