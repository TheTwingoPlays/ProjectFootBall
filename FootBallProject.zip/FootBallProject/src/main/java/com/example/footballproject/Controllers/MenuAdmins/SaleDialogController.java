package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.SaleModel;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.sql.SQLException;

public class SaleDialogController {

    @FXML private Label titleLabel;
    @FXML private ComboBox<OptionItem> ticketComboBox;
    @FXML private ComboBox<OptionItem> userComboBox;
    @FXML private TextField amountField;
    @FXML private ComboBox<String> paymentMethodComboBox;

    private boolean saved;
    private boolean editMode;
    private int editingSaleId = -1;

    @FXML
    private void initialize() {
        loadOptions();
        onlyDecimal(amountField);
    }

    public void setEditSaleId(int saleId) {
        editMode = true;
        editingSaleId = saleId;
        titleLabel.setText("Редактировать продажу");
        loadSale(saleId);
    }

    public boolean isSaved() {
        return saved;
    }

    private void loadOptions() {
        try {
            ticketComboBox.setItems(DatabaseHandler.getTicketOptions());
            userComboBox.setItems(DatabaseHandler.getUserOptions());
            paymentMethodComboBox.setItems(DatabaseHandler.getPaymentMethods());

            if (paymentMethodComboBox.getItems().isEmpty()) {
                paymentMethodComboBox.setItems(FXCollections.observableArrayList("Card", "Cash", "Online"));
            }

            paymentMethodComboBox.setValue("Card");
        } catch (SQLException e) {
            showError("Ошибка загрузки данных: " + e.getMessage());
        }
    }

    private void loadSale(int saleId) {
        try {
            SaleModel sale = DatabaseHandler.getSaleById(saleId);
            selectOptionById(ticketComboBox, sale.getTicketId());
            selectOptionById(userComboBox, sale.getUserId());
            amountField.setText(sale.getAmount().toPlainString());
            paymentMethodComboBox.setValue(sale.getPaymentMethod());
        } catch (SQLException e) {
            showError("Ошибка загрузки продажи: " + e.getMessage());
        }
    }

    private void selectOptionById(ComboBox<OptionItem> comboBox, Integer id) {
        if (id == null) {
            comboBox.setValue(null);
            return;
        }

        for (OptionItem item : comboBox.getItems()) {
            if (item.getId() == id) {
                comboBox.setValue(item);
                return;
            }
        }
    }

    private void onlyDecimal(TextField field) {
        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.matches("\\d*(\\.\\d*)?")) {
                field.setText(oldValue);
            }
        });
    }

    @FXML
    private void handleSave() {
        if (!validateFields()) {
            return;
        }

        OptionItem ticket = ticketComboBox.getValue();
        OptionItem user = userComboBox.getValue();
        BigDecimal amount = new BigDecimal(amountField.getText().trim());
        String paymentMethod = paymentMethodComboBox.getValue();

        try {
            if (editMode) {
                DatabaseHandler.updateSale(
                        editingSaleId,
                        ticket == null ? null : ticket.getId(),
                        user == null ? null : user.getId(),
                        amount,
                        paymentMethod
                );
            } else {
                DatabaseHandler.addSale(
                        ticket == null ? null : ticket.getId(),
                        user == null ? null : user.getId(),
                        amount,
                        paymentMethod
                );
            }

            saved = true;
            closeWindow();
        } catch (SQLException e) {
            showError("Ошибка сохранения продажи: " + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (amountField.getText() == null || amountField.getText().trim().isEmpty()) {
            showError("Введите сумму продажи.");
            return false;
        }

        BigDecimal amount;
        try {
            amount = new BigDecimal(amountField.getText().trim());
        } catch (NumberFormatException e) {
            showError("Введите корректную сумму.");
            return false;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            showError("Сумма должна быть больше 0.");
            return false;
        }

        if (paymentMethodComboBox.getValue() == null || paymentMethodComboBox.getValue().isBlank()) {
            showError("Выберите способ оплаты.");
            return false;
        }

        return true;
    }

    @FXML
    private void handleCancel() {
        saved = false;
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) titleLabel.getScene().getWindow();
        stage.close();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
