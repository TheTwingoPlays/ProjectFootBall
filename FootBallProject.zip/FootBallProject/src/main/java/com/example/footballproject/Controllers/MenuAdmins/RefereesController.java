package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.RefereeModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;

public class RefereesController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> categoryFilterComboBox;
    @FXML private TableView<RefereeModel> refereesTable;

    @FXML private TableColumn<RefereeModel, Integer> idRefereeColumn;
    @FXML private TableColumn<RefereeModel, String> fullNameColumn;
    @FXML private TableColumn<RefereeModel, Integer> experienceColumn;
    @FXML private TableColumn<RefereeModel, String> categoryColumn;

    private final ObservableList<RefereeModel> allReferees = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        setupTable();
        loadReferees();
        searchField.textProperty().addListener((observable, oldValue, newValue) -> filterReferees());
    }

    private void setupTable() {
        idRefereeColumn.setCellValueFactory(new PropertyValueFactory<>("idReferee"));
        fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        experienceColumn.setCellValueFactory(new PropertyValueFactory<>("experienceYears"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
    }

    private void loadReferees() {
        try {
            allReferees.setAll(DatabaseHandler.getReferees(""));
            refereesTable.setItems(allReferees);
            updateCategoryFilterItems();
            filterReferees();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка загрузки", "Не удалось загрузить судей:\n" + e.getMessage());
        }
    }

    @FXML
    private void filterReferees() {
        String text = searchField.getText();
        String category = categoryFilterComboBox.getValue();

        boolean emptySearch = text == null || text.trim().isEmpty();
        boolean emptyFilter = category == null;

        if (emptySearch && emptyFilter) {
            refereesTable.setItems(allReferees);
            return;
        }

        String search = emptySearch ? "" : text.trim().toLowerCase();
        ObservableList<RefereeModel> filtered = FXCollections.observableArrayList();

        for (RefereeModel referee : allReferees) {
            boolean matchesSearch = emptySearch
                    || contains(referee.getFullName(), search)
                    || contains(referee.getCategory(), search)
                    || String.valueOf(referee.getIdReferee()).contains(search);

            boolean matchesCategory = category == null || category.equals(referee.getCategory());

            if (matchesSearch && matchesCategory) {
                filtered.add(referee);
            }
        }

        refereesTable.setItems(filtered);
    }

    private boolean contains(String value, String search) {
        return value != null && value.toLowerCase().contains(search);
    }

    private void updateCategoryFilterItems() {
        String selectedCategory = categoryFilterComboBox.getValue();
        ObservableList<String> categories = FXCollections.observableArrayList();

        allReferees.stream()
                .map(RefereeModel::getCategory)
                .filter(value -> value != null && !value.isBlank())
                .distinct()
                .sorted()
                .forEach(categories::add);

        categoryFilterComboBox.setItems(categories);
        categoryFilterComboBox.setValue(selectedCategory);
    }

    @FXML
    private void addReferee() {
        openRefereeDialog(null);
    }

    @FXML
    private void editReferee() {
        RefereeModel selectedReferee = refereesTable.getSelectionModel().getSelectedItem();

        if (selectedReferee == null) {
            showAlert(Alert.AlertType.WARNING, "Судья не выбран", "Выберите судью в таблице для изменения.");
            return;
        }

        openRefereeDialog(selectedReferee);
    }

    @FXML
    private void deleteReferee() {
        RefereeModel selectedReferee = refereesTable.getSelectionModel().getSelectedItem();

        if (selectedReferee == null) {
            showAlert(Alert.AlertType.WARNING, "Судья не выбран", "Выберите судью в таблице для удаления.");
            return;
        }

        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Удаление судьи");
        confirmAlert.setHeaderText(null);
        confirmAlert.setContentText("Удалить судью: " + selectedReferee.getFullName() + "?");

        if (confirmAlert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            return;
        }

        try {
            DatabaseHandler.deleteRefereeById(selectedReferee.getIdReferee());
            loadReferees();
            showAlert(Alert.AlertType.INFORMATION, "Готово", "Судья удалён.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка удаления", "Не удалось удалить судью:\n" + e.getMessage());
        }
    }

    @FXML
    private void refreshReferees() {
        searchField.clear();
        categoryFilterComboBox.setValue(null);
        loadReferees();
    }

    private void openRefereeDialog(RefereeModel referee) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/footballproject/MenuFxml/RefereeDialog.fxml"));
            Parent root = loader.load();

            RefereeDialogController controller = loader.getController();
            controller.setReferee(referee);

            Stage stage = new Stage();
            stage.setTitle(referee == null ? "Добавить судью" : "Изменить судью");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadReferees();
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка окна", "Не удалось открыть окно судьи:\n" + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
