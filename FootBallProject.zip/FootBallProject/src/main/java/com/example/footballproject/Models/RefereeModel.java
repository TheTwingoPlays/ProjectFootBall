package com.example.footballproject.Models;

public class RefereeModel {
    private final int idReferee;
    private final String fullName;
    private final int experienceYears;
    private final String category;

    public RefereeModel(int idReferee, String fullName, int experienceYears, String category) {
        this.idReferee = idReferee;
        this.fullName = fullName;
        this.experienceYears = experienceYears;
        this.category = category;
    }

    public int getIdReferee() {
        return idReferee;
    }

    public String getFullName() {
        return fullName;
    }

    public int getExperienceYears() {
        return experienceYears;
    }

    public String getCategory() {
        return category;
    }
}
