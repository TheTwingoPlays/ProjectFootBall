package com.example.footballproject.Models;

public enum Nationality {

    AFGHANISTAN("Afghanistan"),
    ALBANIA("Albania"),
    ALGERIA("Algeria"),
    ANDORRA("Andorra"),
    ANGOLA("Angola"),
    ARGENTINA("Argentina"),
    ARMENIA("Armenia"),
    AUSTRALIA("Australia"),
    AUSTRIA("Austria"),
    AZERBAIJAN("Azerbaijan"),

    BAHRAIN("Bahrain"),
    BELARUS("Belarus"),
    BELGIUM("Belgium"),
    BOLIVIA("Bolivia"),
    BOSNIA_AND_HERZEGOVINA("Bosnia and Herzegovina"),
    BRAZIL("Brazil"),
    BULGARIA("Bulgaria"),

    CAMEROON("Cameroon"),
    CANADA("Canada"),
    CHILE("Chile"),
    CHINA("China"),
    COLOMBIA("Colombia"),
    COSTA_RICA("Costa Rica"),
    CROATIA("Croatia"),
    CZECH_REPUBLIC("Czech Republic"),

    DENMARK("Denmark"),
    DR_CONGO("DR Congo"),

    ECUADOR("Ecuador"),
    EGYPT("Egypt"),
    ENGLAND("England"),
    ETHIOPIA,

    FINLAND("Finland"),
    FRANCE("France"),

    GABON("Gabon"),
    GAMBIA("Gambia"),
    GEORGIA("Georgia"),
    GERMANY("Germany"),
    GHANA("Ghana"),
    GREECE("Greece"),
    GUINEA("Guinea"),

    HONDURAS("Honduras"),
    HUNGARY("Hungary"),

    ICELAND("Iceland"),
    INDIA("India"),
    INDONESIA("Indonesia"),
    IRAN("Iran"),
    IRAQ("Iraq"),
    IRELAND("Ireland"),
    ISRAEL("Israel"),
    ITALY("Italy"),
    IVORY_COAST("Ivory Coast"),

    JAMAICA("Jamaica"),
    JAPAN("Japan"),

    KAZAKHSTAN("Kazakhstan"),
    KENYA("Kenya"),
    KOSOVO("Kosovo"),

    LATVIA("Latvia"),
    LITHUANIA("Lithuania"),
    LUXEMBOURG("Luxembourg"),

    MALI("Mali"),
    MEXICO("Mexico"),
    MOLDOVA("Moldova"),
    MONTENEGRO("Montenegro"),
    MOROCCO("Morocco"),

    NETHERLANDS("Netherlands"),
    NEW_ZEALAND("New Zealand"),
    NIGERIA("Nigeria"),
    NORTH_MACEDONIA("North Macedonia"),
    NORTHERN_IRELAND("Northern Ireland"),
    NORWAY("Norway"),

    PARAGUAY("Paraguay"),
    PERU("Peru"),
    POLAND("Poland"),
    PORTUGAL("Portugal"),

    QATAR("Qatar"),

    ROMANIA("Romania"),
    RUSSIA("Russia"),

    SCOTLAND("Scotland"),
    SENEGAL("Senegal"),
    SERBIA("Serbia"),
    SLOVAKIA("Slovakia"),
    SLOVENIA("Slovenia"),
    SOUTH_AFRICA("South Africa"),
    SOUTH_KOREA("South Korea"),
    SPAIN("Spain"),
    SWEDEN("Sweden"),
    SWITZERLAND("Switzerland"),

    TUNISIA("Tunisia"),
    TURKEY("Turkey"),

    UKRAINE("Ukraine"),
    UNITED_STATES("United States"),
    URUGUAY("Uruguay"),

    VENEZUELA("Venezuela"),

    WALES("Wales"),

    ZAMBIA("Zambia"),
    ZIMBABWE("Zimbabwe"),

    OTHER("Other");

    private final String displayName;

    Nationality() {
        this.displayName = name();
    }

    Nationality(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static Nationality fromDisplayName(String value) {
        if (value == null || value.isBlank()) {
            return OTHER;
        }

        for (Nationality nationality : values()) {
            if (nationality.displayName.equalsIgnoreCase(value.trim())) {
                return nationality;
            }
        }

        return OTHER;
    }

    @Override
    public String toString() {
        return displayName;
    }
}