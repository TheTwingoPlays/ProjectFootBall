package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.OptionItem;
import com.example.footballproject.Models.SaleModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.sql.SQLException;

public class SalesController {

    @FXML private TextField searchField;
    @FXML private ComboBox<OptionItem> ticketFilterComboBox;
    @FXML private ComboBox<OptionItem> userFilterComboBox;
    @FXML private ComboBox<String> paymentFilterComboBox;

    @FXML private TableView<SaleModel> salesTable;

    @FXML private TableColumn<SaleModel, Integer> colId;
    @FXML private TableColumn<SaleModel, String> colTicket;
    @FXML private TableColumn<SaleModel, String> colUser;
    @FXML private TableColumn<SaleModel, BigDecimal> colAmount;
    @FXML private TableColumn<SaleModel, String> colDate;
    @FXML private TableColumn<SaleModel, String> colPayment;

    @FXML
    private void initialize() {
        setupTable();
        loadFilters();
        loadSales();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTicket.setCellValueFactory(new PropertyValueFactory<>("ticketName"));
        colUser.setCellValueFactory(new PropertyValueFactory<>("username"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("saleDate"));
        colPayment.setCellValueFactory(new PropertyValueFactory<>("paymentMethod"));
    }

    private void loadFilters() {
        try {
            ticketFilterComboBox.setItems(DatabaseHandler.getTicketOptions());
            userFilterComboBox.setItems(DatabaseHandler.getUserOptions());
            paymentFilterComboBox.setItems(DatabaseHandler.getPaymentMethods());
        } catch (SQLException e) {
            showError("Ошибка загрузки фильтров: " + e.getMessage());
        }
    }

    private void loadSales() {
        try {
            String keyword = searchField.getText() == null ? "" : searchField.getText().trim();
            OptionItem ticket = ticketFilterComboBox.getValue();
            OptionItem user = userFilterComboBox.getValue();
            String paymentMethod = paymentFilterComboBox.getValue();

            ObservableList<SaleModel> sales = DatabaseHandler.getSales(
                    keyword,
                    ticket == null ? null : ticket.getId(),
                    user == null ? null : user.getId(),
                    paymentMethod
            );

            salesTable.getItems().clear();
            salesTable.setItems(sales);
            salesTable.refresh();
        } catch (SQLException e) {
            showError("Database error: " + e.getMessage());
        }
    }

    @FXML private void handleSearch() { loadSales(); }
    @FXML private void handleFilter() { loadSales(); }

    @FXML
    private void handleClearFilters() {
        searchField.clear();
        ticketFilterComboBox.setValue(null);
        userFilterComboBox.setValue(null);
        paymentFilterComboBox.setValue(null);
        loadSales();
    }

    @FXML private void handleAdd() { openSaleDialog(null); }

    @FXML
    private void handleEdit() {
        SaleModel selectedSale = salesTable.getSelectionModel().getSelectedItem();
        if (selectedSale == null) {
            showWarning("Выберите продажу для изменения.");
            return;
        }
        openSaleDialog(selectedSale.getId());
    }

    @FXML
    private void handleDelete() {
        SaleModel selectedSale = salesTable.getSelectionModel().getSelectedItem();
        if (selectedSale == null) {
            showWarning("Выберите продажу для удаления.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Удаление продажи");
        confirm.setHeaderText(null);
        confirm.setContentText("Удалить продажу #" + selectedSale.getId() + "?");
        ButtonType yes = new ButtonType("Да");
        ButtonType no = new ButtonType("Нет", ButtonBar.ButtonData.CANCEL_CLOSE);
        confirm.getButtonTypes().setAll(yes, no);

        confirm.showAndWait().ifPresent(response -> {
            if (response == yes) {
                deleteSelectedSale(selectedSale);
            }
        });
    }

    private void openSaleDialog(Integer saleId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/footballproject/MenuFxml/SaleDialog.fxml"));
            Parent root = loader.load();
            SaleDialogController controller = loader.getController();

            if (saleId != null) {
                controller.setEditSaleId(saleId);
            }

            Stage stage = new Stage();
            stage.setTitle(saleId == null ? "Добавить продажу" : "Редактировать продажу");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isSaved()) {
                loadFilters();
                loadSales();
                showInfo("Успешно", saleId == null ? "Продажа добавлена." : "Продажа обновлена.");
            }
        } catch (Exception e) {
            showError("Не удалось открыть окно продажи: " + e.getMessage());
        }
    }

    private void deleteSelectedSale(SaleModel sale) {
        try {
            DatabaseHandler.deleteSaleById(sale.getId());
            loadFilters();
            loadSales();
            showInfo("Успешно", "Продажа удалена.");
        } catch (SQLException e) {
            showError("Delete error: " + e.getMessage());
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Внимание");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
