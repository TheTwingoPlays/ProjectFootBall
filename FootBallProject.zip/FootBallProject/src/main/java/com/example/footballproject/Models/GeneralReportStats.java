package com.example.footballproject.Models;

import java.math.BigDecimal;

public class GeneralReportStats {

    private int totalTickets;
    private int soldTickets;
    private int availableTickets;
    private int matchesCount;
    private int teamsCount;
    private int playersCount;
    private int tournamentsCount;
    private int stadiumsCount;
    private int usersCount;
    private int coachesCount;
    private int refereesCount;
    private BigDecimal totalRevenue;

    public GeneralReportStats() {
        this.totalRevenue = BigDecimal.ZERO;
    }

    public int getTotalTickets() {
        return totalTickets;
    }

    public void setTotalTickets(int totalTickets) {
        this.totalTickets = totalTickets;
    }

    public int getSoldTickets() {
        return soldTickets;
    }

    public void setSoldTickets(int soldTickets) {
        this.soldTickets = soldTickets;
    }

    public int getAvailableTickets() {
        return availableTickets;
    }

    public void setAvailableTickets(int availableTickets) {
        this.availableTickets = availableTickets;
    }

    public int getMatchesCount() {
        return matchesCount;
    }

    public void setMatchesCount(int matchesCount) {
        this.matchesCount = matchesCount;
    }

    public int getTeamsCount() {
        return teamsCount;
    }

    public void setTeamsCount(int teamsCount) {
        this.teamsCount = teamsCount;
    }

    public int getPlayersCount() {
        return playersCount;
    }

    public void setPlayersCount(int playersCount) {
        this.playersCount = playersCount;
    }

    public int getTournamentsCount() {
        return tournamentsCount;
    }

    public void setTournamentsCount(int tournamentsCount) {
        this.tournamentsCount = tournamentsCount;
    }

    public int getStadiumsCount() {
        return stadiumsCount;
    }

    public void setStadiumsCount(int stadiumsCount) {
        this.stadiumsCount = stadiumsCount;
    }

    public int getUsersCount() {
        return usersCount;
    }

    public void setUsersCount(int usersCount) {
        this.usersCount = usersCount;
    }

    public int getCoachesCount() {
        return coachesCount;
    }

    public void setCoachesCount(int coachesCount) {
        this.coachesCount = coachesCount;
    }

    public int getRefereesCount() {
        return refereesCount;
    }

    public void setRefereesCount(int refereesCount) {
        this.refereesCount = refereesCount;
    }

    public BigDecimal getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }
}