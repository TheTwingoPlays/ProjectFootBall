package com.example.footballproject.Models;

public class CoachModel {
    private final int idCoach;
    private final Integer idComand;
    private final String teamName;
    private final String fullName;
    private final String position;
    private final int age;
    private final String country;
    private final int experienceYears;
    private final String status;
    private final String licenseType;

    public CoachModel(int idCoach,
                      Integer idComand,
                      String teamName,
                      String fullName,
                      String position,
                      int age,
                      String country,
                      int experienceYears,
                      String status,
                      String licenseType) {
        this.idCoach = idCoach;
        this.idComand = idComand;
        this.teamName = teamName;
        this.fullName = fullName;
        this.position = position;
        this.age = age;
        this.country = country;
        this.experienceYears = experienceYears;
        this.status = status;
        this.licenseType = licenseType;
    }

    public int getIdCoach() {
        return idCoach;
    }

    public Integer getIdComand() {
        return idComand;
    }

    public String getTeamName() {
        return teamName;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPosition() {
        return position;
    }

    public String getPositionTitle() {
        return getEnumTitle(CoachPosition.values(), position);
    }

    public int getAge() {
        return age;
    }

    public String getCountry() {
        return country;
    }

    public int getExperienceYears() {
        return experienceYears;
    }

    public String getStatus() {
        return status;
    }

    public String getStatusTitle() {
        return getEnumTitle(CoachStatus.values(), status);
    }

    public String getLicenseType() {
        return licenseType;
    }

    public String getLicenseTypeTitle() {
        return getEnumTitle(CoachLicenseType.values(), licenseType);
    }

    private <T extends Enum<T>> String getEnumTitle(T[] values, String dbValue) {
        if (dbValue == null || dbValue.trim().isEmpty()) {
            return "";
        }

        String normalized = dbValue.trim()
                .replace(" ", "_")
                .replace("-", "_")
                .toUpperCase();

        for (T value : values) {
            if (value.name().equalsIgnoreCase(normalized)) {
                return value.toString();
            }
        }

        return dbValue;
    }
}
