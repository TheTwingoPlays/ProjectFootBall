package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.GeneralReportStats;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.SQLException;
import java.text.DecimalFormat;

public class GeneralReportController {

    @FXML private Label totalTicketsLabel;
    @FXML private Label soldTicketsLabel;
    @FXML private Label revenueLabel;
    @FXML private Label matchesLabel;

    @FXML private Label teamsLabel;
    @FXML private Label playersLabel;
    @FXML private Label tournamentsLabel;
    @FXML private Label stadiumsLabel;
    @FXML private Label coachesLabel;
    @FXML private Label refereesLabel;

    @FXML private PieChart ticketTypesChart;
    @FXML private BarChart<String, Number> salesByDateChart;

    private final DecimalFormat moneyFormat = new DecimalFormat("#,##0.00");

    @FXML
    public void initialize() {
        loadReportData();
    }

    private void loadReportData() {
        try {
            GeneralReportStats stats = DatabaseHandler.getGeneralReportStats();

            totalTicketsLabel.setText(String.valueOf(stats.getTotalTickets()));
            soldTicketsLabel.setText(String.valueOf(stats.getSoldTickets()));
            matchesLabel.setText(String.valueOf(stats.getMatchesCount()));

            teamsLabel.setText(String.valueOf(stats.getTeamsCount()));
            playersLabel.setText(String.valueOf(stats.getPlayersCount()));
            tournamentsLabel.setText(String.valueOf(stats.getTournamentsCount()));
            stadiumsLabel.setText(String.valueOf(stats.getStadiumsCount()));
            coachesLabel.setText(String.valueOf(stats.getCoachesCount()));
            refereesLabel.setText(String.valueOf(stats.getRefereesCount()));

            BigDecimal revenue = stats.getTotalRevenue();
            revenueLabel.setText(moneyFormat.format(revenue) + " MDL");

            ticketTypesChart.setData(DatabaseHandler.getTicketTypesChartData());

            salesByDateChart.getData().clear();
            XYChart.Series<String, Number> salesSeries = DatabaseHandler.getSalesByDateChartData();
            salesByDateChart.getData().add(salesSeries);

        } catch (SQLException e) {
            e.printStackTrace();

            totalTicketsLabel.setText("ERR");
            soldTicketsLabel.setText("ERR");
            revenueLabel.setText("ERR");
            matchesLabel.setText("ERR");
        }
    }

    @FXML
    private void exportReportCsv() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Сохранить отчет CSV");
        fileChooser.setInitialFileName("football-report.csv");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV files", "*.csv"));

        File file = fileChooser.showSaveDialog(getWindow());
        if (file == null) {
            return;
        }

        try {
            DatabaseHandler.exportGeneralReportCsv(file.toPath());
            showInfo("Готово", "Отчет сохранен:\n" + file.getAbsolutePath());
        } catch (Exception e) {
            showError("Не удалось сохранить CSV:\n" + e.getMessage());
        }
    }

    @FXML
    private void importCsv() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Выбрать CSV для импорта");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV files", "*.csv"));

        File file = fileChooser.showOpenDialog(getWindow());
        if (file == null) {
            return;
        }

        try {
            int importedRows = DatabaseHandler.importReportCsv(Path.of(file.toURI()));
            loadReportData();
            showInfo("Готово", "Импортировано строк: " + importedRows);
        } catch (Exception e) {
            showError("Не удалось импортировать CSV:\n" + e.getMessage());
        }
    }

    private Window getWindow() {
        return totalTicketsLabel.getScene().getWindow();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
