package com.example.footballproject.Models;

import java.time.LocalDate;
import java.time.LocalTime;

public class GameFormData {

    private int id;
    private int homeTeamId;
    private int awayTeamId;
    private int tournamentId;
    private int stadiumId;
    private int refereeId;
    private LocalDate date;
    private LocalTime time;
    private String score;

    public GameFormData(int id,
                        int homeTeamId,
                        int awayTeamId,
                        int tournamentId,
                        int stadiumId,
                        int refereeId,
                        LocalDate date,
                        LocalTime time,
                        String score) {
        this.id = id;
        this.homeTeamId = homeTeamId;
        this.awayTeamId = awayTeamId;
        this.tournamentId = tournamentId;
        this.stadiumId = stadiumId;
        this.refereeId = refereeId;
        this.date = date;
        this.time = time;
        this.score = score;
    }

    public int getId() {
        return id;
    }

    public int getHomeTeamId() {
        return homeTeamId;
    }

    public int getAwayTeamId() {
        return awayTeamId;
    }

    public int getTournamentId() {
        return tournamentId;
    }

    public int getStadiumId() {
        return stadiumId;
    }

    public int getRefereeId() {
        return refereeId;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getTime() {
        return time;
    }

    public String getScore() {
        return score;
    }
}