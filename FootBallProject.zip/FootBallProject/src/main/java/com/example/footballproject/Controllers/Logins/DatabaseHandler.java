package com.example.footballproject.Controllers.Logins;

import com.example.footballproject.Models.*;
import org.mindrot.jbcrypt.BCrypt;
import java.sql.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.sql.Statement;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseHandler {

    private static final String URL = "jdbc:postgresql://localhost:5432/football";
    private static final String USER = "postgres";
    private static final String PASSWORD = "MarxNumb1*";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("PostgreSQL Driver not found", e);
        }
    }

    public static void registerUser(String username, String email, String password) throws SQLException {
        String sql = "INSERT INTO AppUsers (username, email, password_hash, user_role) VALUES (?, ?, ?, 'USER')";
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setString(3, hashedPassword);
            pstmt.executeUpdate();
        }
    }

    public static boolean validateLogin(String username, String enteredPassword) {
        String sql = """
            SELECT password_hash, is_active
            FROM AppUsers
            WHERE username = ?
            """;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                boolean active = rs.getBoolean("is_active");

                if (!active) {
                    return false;
                }

                String storedHash = rs.getString("password_hash");
                return BCrypt.checkpw(enteredPassword, storedHash);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static boolean emailExists(String email) throws SQLException {
        String sql = "SELECT id_user FROM AppUsers WHERE email = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, email);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public static void updatePasswordByEmail(String email, String newPassword) throws SQLException {
        String sql = "UPDATE AppUsers SET password_hash = ? WHERE email = ?";

        // ВАЖНО: Хешируем новый пароль перед сохранением в базу
        String hashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt());

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, hashedPassword);
            statement.setString(2, email);
            int rows = statement.executeUpdate();
            if (rows == 0) {
                throw new SQLException("No account found with this email.");
            }
        }
    }

    public static GeneralReportStats getGeneralReportStats() throws SQLException {
        GeneralReportStats stats = new GeneralReportStats();

        stats.setTotalTickets(getCount("SELECT COUNT(*) FROM Ticket"));
        stats.setSoldTickets(getCount("SELECT COUNT(*) FROM Sales"));
        stats.setAvailableTickets(getCount("SELECT COUNT(*) FROM Ticket WHERE is_available = TRUE"));

        stats.setMatchesCount(getCount("SELECT COUNT(*) FROM Game"));
        stats.setTeamsCount(getCount("SELECT COUNT(*) FROM Command"));
        stats.setPlayersCount(getCount("SELECT COUNT(*) FROM Players"));
        stats.setTournamentsCount(getCount("SELECT COUNT(*) FROM Tourner"));
        stats.setStadiumsCount(getCount("SELECT COUNT(*) FROM Stadiums"));
        stats.setUsersCount(getCount("SELECT COUNT(*) FROM AppUsers"));
        stats.setCoachesCount(getCount("SELECT COUNT(*) FROM Coaches"));
        stats.setRefereesCount(getCount("SELECT COUNT(*) FROM Referees"));

        stats.setTotalRevenue(getTotalRevenue());

        return stats;
    }

    private static int getCount(String sql) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            if (resultSet.next()) {
                return resultSet.getInt(1);
            }

            return 0;
        }
    }

    private static BigDecimal getTotalRevenue() throws SQLException {
        String sql = "SELECT COALESCE(SUM(summa), 0) FROM Sales";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            if (resultSet.next()) {
                return resultSet.getBigDecimal(1);
            }

            return BigDecimal.ZERO;
        }
    }

    public static ObservableList<PieChart.Data> getTicketTypesChartData() throws SQLException {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();

        String sql = """
            SELECT typese, COUNT(*) AS total
            FROM Ticket
            GROUP BY typese
            ORDER BY total DESC
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String type = resultSet.getString("typese");
                int total = resultSet.getInt("total");

                data.add(new PieChart.Data(type, total));
            }
        }

        return data;
    }

    public static XYChart.Series<String, Number> getSalesByDateChartData() throws SQLException {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Продажи");

        String sql = """
            SELECT DATE(sale_date) AS sale_day, COUNT(*) AS total_sales
            FROM Sales
            GROUP BY DATE(sale_date)
            ORDER BY sale_day
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String date = resultSet.getString("sale_day");
                int totalSales = resultSet.getInt("total_sales");

                series.getData().add(new XYChart.Data<>(date, totalSales));
            }
        }

        return series;
    }

    public static void exportGeneralReportCsv(Path outputPath) throws Exception {
        GeneralReportStats stats = getGeneralReportStats();
        List<String> lines = new ArrayList<>();

        lines.add("section,name,value");
        lines.add(csvLine("metric", "total_tickets", String.valueOf(stats.getTotalTickets())));
        lines.add(csvLine("metric", "sold_tickets", String.valueOf(stats.getSoldTickets())));
        lines.add(csvLine("metric", "available_tickets", String.valueOf(stats.getAvailableTickets())));
        lines.add(csvLine("metric", "revenue_mdl", String.valueOf(stats.getTotalRevenue())));
        lines.add(csvLine("metric", "matches", String.valueOf(stats.getMatchesCount())));
        lines.add(csvLine("metric", "teams", String.valueOf(stats.getTeamsCount())));
        lines.add(csvLine("metric", "players", String.valueOf(stats.getPlayersCount())));
        lines.add(csvLine("metric", "tournaments", String.valueOf(stats.getTournamentsCount())));
        lines.add(csvLine("metric", "stadiums", String.valueOf(stats.getStadiumsCount())));
        lines.add(csvLine("metric", "coaches", String.valueOf(stats.getCoachesCount())));
        lines.add(csvLine("metric", "referees", String.valueOf(stats.getRefereesCount())));

        for (PieChart.Data data : getTicketTypesChartData()) {
            lines.add(csvLine("ticket_type", data.getName(), String.valueOf((int) data.getPieValue())));
        }

        for (XYChart.Data<String, Number> data : getSalesByDateChartData().getData()) {
            lines.add(csvLine("sales_by_date", data.getXValue(), String.valueOf(data.getYValue())));
        }

        Files.write(outputPath, lines, StandardCharsets.UTF_8);
    }

    public static int importReportCsv(Path inputPath) throws Exception {
        List<String> lines = Files.readAllLines(inputPath, StandardCharsets.UTF_8);
        if (lines.isEmpty()) {
            return 0;
        }

        List<String> headers = parseCsvLine(lines.get(0));
        Map<String, Integer> headerIndex = new HashMap<>();

        for (int i = 0; i < headers.size(); i++) {
            headerIndex.put(headers.get(i).trim().toLowerCase(), i);
        }

        if (headerIndex.containsKey("typese") && headerIndex.containsKey("coust")) {
            return importTicketsCsv(lines, headerIndex);
        }

        if (headerIndex.containsKey("summa") && headerIndex.containsKey("payment_method")) {
            return importSalesCsv(lines, headerIndex);
        }

        throw new SQLException("CSV должен содержать заголовки Ticket (id_game,typese,coust,place,rowse,sector,is_available) или Sales (id_ticket,id_user,summa,payment_method).");
    }

    private static int importTicketsCsv(List<String> lines, Map<String, Integer> headerIndex) throws SQLException {
        int importedRows = 0;

        for (int i = 1; i < lines.size(); i++) {
            if (lines.get(i).isBlank()) {
                continue;
            }

            List<String> row = parseCsvLine(lines.get(i));
            Integer gameId = getOptionalInteger(row, headerIndex, "id_game");
            String type = getRequiredValue(row, headerIndex, "typese");
            BigDecimal cost = new BigDecimal(getRequiredValue(row, headerIndex, "coust"));
            int place = Integer.parseInt(getRequiredValue(row, headerIndex, "place"));
            int rowNumber = Integer.parseInt(getRequiredValue(row, headerIndex, "rowse"));
            String sector = getRequiredValue(row, headerIndex, "sector");
            boolean available = Boolean.parseBoolean(getValue(row, headerIndex, "is_available", "true"));

            addTicket(gameId, type, cost, place, rowNumber, sector, available);
            importedRows++;
        }

        return importedRows;
    }

    private static int importSalesCsv(List<String> lines, Map<String, Integer> headerIndex) throws SQLException {
        int importedRows = 0;

        for (int i = 1; i < lines.size(); i++) {
            if (lines.get(i).isBlank()) {
                continue;
            }

            List<String> row = parseCsvLine(lines.get(i));
            Integer ticketId = getOptionalInteger(row, headerIndex, "id_ticket");
            Integer userId = getOptionalInteger(row, headerIndex, "id_user");
            BigDecimal amount = new BigDecimal(getRequiredValue(row, headerIndex, "summa"));
            String paymentMethod = getValue(row, headerIndex, "payment_method", "Card");

            addSale(ticketId, userId, amount, paymentMethod);
            importedRows++;
        }

        return importedRows;
    }

    private static String csvLine(String... values) {
        List<String> escaped = new ArrayList<>();

        for (String value : values) {
            String safeValue = value == null ? "" : value;
            escaped.add("\"" + safeValue.replace("\"", "\"\"") + "\"");
        }

        return String.join(",", escaped);
    }

    private static List<String> parseCsvLine(String line) {
        List<String> values = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;

        for (int i = 0; i < line.length(); i++) {
            char character = line.charAt(i);

            if (character == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    quoted = !quoted;
                }
            } else if (character == ',' && !quoted) {
                values.add(current.toString());
                current.setLength(0);
            } else {
                current.append(character);
            }
        }

        values.add(current.toString());
        return values;
    }

    private static String getRequiredValue(List<String> row, Map<String, Integer> headerIndex, String columnName) throws SQLException {
        String value = getValue(row, headerIndex, columnName, "");
        if (value.isBlank()) {
            throw new SQLException("В CSV не заполнена колонка: " + columnName);
        }

        return value;
    }

    private static String getValue(List<String> row, Map<String, Integer> headerIndex, String columnName, String defaultValue) {
        Integer index = headerIndex.get(columnName);
        if (index == null || index >= row.size()) {
            return defaultValue;
        }

        String value = row.get(index).trim();
        return value.isEmpty() ? defaultValue : value;
    }

    private static Integer getOptionalInteger(List<String> row, Map<String, Integer> headerIndex, String columnName) {
        String value = getValue(row, headerIndex, columnName, "");
        return value.isBlank() ? null : Integer.parseInt(value);
    }

    public static ObservableList<GameModel> getGamesAnalytics(
            String keyword,
            Integer tournamentId,
            LocalDate date
    ) throws SQLException {
        return getGamesAnalytics(keyword, tournamentId, date, null, null, null);
    }

    public static ObservableList<GameModel> getGamesAnalytics(
            String keyword,
            Integer tournamentId,
            LocalDate date,
            Integer teamId,
            Integer stadiumId,
            Integer refereeId
    ) throws SQLException {

        ObservableList<GameModel> games = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT
                g.id_game AS match_id,
                g.datas AS match_date,
                g.times AS match_time,
                home.namec AS home_team_name,
                away.namec AS away_team_name,
                t.namet AS tournament_name,
                s.name_stadium AS stadium_name,
                s.city AS stadium_city,
                r.full_name AS referee_name,
                g.score AS match_score
            FROM Game g
            LEFT JOIN Command home ON g.id_comand1 = home.id_comand
            LEFT JOIN Command away ON g.id_comand2 = away.id_comand
            LEFT JOIN Tourner t ON g.id_tourner = t.id_tourner
            LEFT JOIN Stadiums s ON g.id_stadium = s.id_stadium
            LEFT JOIN Referees r ON g.id_referee = r.id_referee
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(g.id_game AS TEXT)) LIKE LOWER(?)
                    OR LOWER(COALESCE(home.namec, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(away.namec, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(t.namet, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(s.name_stadium, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(s.city, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(r.full_name, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(g.score, '')) LIKE LOWER(?)
                )
                """);
        }

        if (tournamentId != null) {
            sql.append(" AND g.id_tourner = ? ");
        }

        if (date != null) {
            sql.append(" AND g.datas = ? ");
        }

        if (teamId != null) {
            sql.append(" AND (g.id_comand1 = ? OR g.id_comand2 = ?) ");
        }

        if (stadiumId != null) {
            sql.append(" AND g.id_stadium = ? ");
        }

        if (refereeId != null) {
            sql.append(" AND g.id_referee = ? ");
        }

        sql.append(" ORDER BY g.id_game DESC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword + "%";

                for (int i = 0; i < 8; i++) {
                    statement.setString(index++, searchValue);
                }
            }

            if (tournamentId != null) {
                statement.setInt(index++, tournamentId);
            }

            if (date != null) {
                statement.setDate(index++, java.sql.Date.valueOf(date));
            }

            if (teamId != null) {
                statement.setInt(index++, teamId);
                statement.setInt(index++, teamId);
            }

            if (stadiumId != null) {
                statement.setInt(index++, stadiumId);
            }

            if (refereeId != null) {
                statement.setInt(index++, refereeId);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {

                    String stadium = resultSet.getString("stadium_name");

                    if (stadium == null || stadium.isBlank()) {
                        stadium = "No stadium";
                    }

                    String city = resultSet.getString("stadium_city");

                    if (city != null && !city.isBlank()) {
                        stadium += " / " + city;
                    }

                    String referee = resultSet.getString("referee_name");

                    if (referee == null || referee.isBlank()) {
                        referee = "No referee";
                    }

                    String score = resultSet.getString("match_score");

                    if (score == null || score.isBlank()) {
                        score = "?-?";
                    }

                    GameModel game = new GameModel(
                            resultSet.getInt("match_id"),
                            String.valueOf(resultSet.getDate("match_date")),
                            String.valueOf(resultSet.getTime("match_time")),
                            resultSet.getString("home_team_name"),
                            resultSet.getString("away_team_name"),
                            resultSet.getString("tournament_name"),
                            stadium,
                            referee,
                            score
                    );

                    games.add(game);
                }
            }
        }

        System.out.println("Loaded games: " + games.size());

        return games;
    }

    private static GameModel mapGame(ResultSet resultSet) throws SQLException {
        int id = resultSet.getInt("match_id");

        String date = resultSet.getString("match_date");
        String time = resultSet.getString("match_time");

        String homeTeam = resultSet.getString("home_team_name");
        String awayTeam = resultSet.getString("away_team_name");
        String tournament = resultSet.getString("tournament_name");

        String stadiumName = resultSet.getString("stadium_name");
        String stadiumCity = resultSet.getString("stadium_city");

        String stadium = stadiumName == null ? "No stadium" : stadiumName;

        if (stadiumCity != null && !stadiumCity.isBlank()) {
            stadium += " / " + stadiumCity;
        }

        String referee = resultSet.getString("referee_name");

        if (referee == null || referee.isBlank()) {
            referee = "No referee";
        }

        String score = resultSet.getString("match_score");

        if (score == null || score.isBlank()) {
            score = "?-?";
        }

        return new GameModel(
                id,
                date,
                time,
                homeTeam,
                awayTeam,
                tournament,
                stadium,
                referee,
                score
        );
    }

    public static GameFormData getGameFormDataById(int gameId) throws SQLException {
        String sql = """
            SELECT
                id_game,
                id_comand1,
                id_comand2,
                id_tourner,
                id_stadium,
                id_referee,
                datas,
                times,
                score
            FROM Game
            WHERE id_game = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, gameId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new GameFormData(
                            resultSet.getInt("id_game"),
                            resultSet.getInt("id_comand1"),
                            resultSet.getInt("id_comand2"),
                            resultSet.getInt("id_tourner"),
                            resultSet.getInt("id_stadium"),
                            resultSet.getInt("id_referee"),
                            resultSet.getDate("datas").toLocalDate(),
                            resultSet.getTime("times").toLocalTime(),
                            resultSet.getString("score")
                    );
                }
            }
        }

        throw new SQLException("Match not found.");
    }

    public static void addGame(
            int homeTeamId,
            int awayTeamId,
            int tournamentId,
            int stadiumId,
            int refereeId,
            LocalDate date,
            LocalTime time,
            String score
    ) throws SQLException {
        String matchCode = generateMatchCode();

        String insertMatchCodeSql = """
            INSERT INTO MatchNumbers (MatchCode)
            VALUES (?)
            """;

        String insertGameSql = """
            INSERT INTO Game (
                id_comand1,
                id_comand2,
                id_tourner,
                id_stadium,
                datas,
                times,
                MatchCode,
                score,
                id_referee
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try {
                try (PreparedStatement codeStatement = connection.prepareStatement(insertMatchCodeSql)) {
                    codeStatement.setString(1, matchCode);
                    codeStatement.executeUpdate();
                }

                try (PreparedStatement gameStatement = connection.prepareStatement(insertGameSql)) {
                    gameStatement.setInt(1, homeTeamId);
                    gameStatement.setInt(2, awayTeamId);
                    gameStatement.setInt(3, tournamentId);
                    gameStatement.setInt(4, stadiumId);
                    gameStatement.setDate(5, java.sql.Date.valueOf(date));
                    gameStatement.setTime(6, java.sql.Time.valueOf(time));
                    gameStatement.setString(7, matchCode);
                    gameStatement.setString(8, score);
                    gameStatement.setInt(9, refereeId);
                    gameStatement.executeUpdate();
                }

                connection.commit();

            } catch (SQLException e) {
                connection.rollback();
                throw e;

            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public static void updateGame(
            int gameId,
            int homeTeamId,
            int awayTeamId,
            int tournamentId,
            int stadiumId,
            int refereeId,
            LocalDate date,
            LocalTime time,
            String score
    ) throws SQLException {
        String sql = """
            UPDATE Game
            SET
                id_comand1 = ?,
                id_comand2 = ?,
                id_tourner = ?,
                id_stadium = ?,
                id_referee = ?,
                datas = ?,
                times = ?,
                score = ?
            WHERE id_game = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, homeTeamId);
            statement.setInt(2, awayTeamId);
            statement.setInt(3, tournamentId);
            statement.setInt(4, stadiumId);
            statement.setInt(5, refereeId);
            statement.setDate(6, java.sql.Date.valueOf(date));
            statement.setTime(7, java.sql.Time.valueOf(time));
            statement.setString(8, score);
            statement.setInt(9, gameId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Match not found.");
            }
        }
    }

    public static void deleteGameById(int gameId) throws SQLException {
        String sql = "DELETE FROM Game WHERE id_game = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, gameId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Match was not found.");
            }
        }
    }

    public static ObservableList<OptionItem> getTournamentsOptions() throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT id_tourner, namet
            FROM Tourner
            ORDER BY namet
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                list.add(new OptionItem(
                        resultSet.getInt("id_tourner"),
                        resultSet.getString("namet")
                ));
            }
        }

        return list;
    }

    public static ObservableList<OptionItem> getGamesOptions() throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT
                g.id_game,
                g.datas,
                home.namec AS home_team_name,
                away.namec AS away_team_name
            FROM Game g
            LEFT JOIN Command home ON g.id_comand1 = home.id_comand
            LEFT JOIN Command away ON g.id_comand2 = away.id_comand
            ORDER BY g.id_game DESC
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String homeTeam = resultSet.getString("home_team_name");
                String awayTeam = resultSet.getString("away_team_name");
                String date = String.valueOf(resultSet.getDate("datas"));

                list.add(new OptionItem(
                        resultSet.getInt("id_game"),
                        "#" + resultSet.getInt("id_game") + " " + homeTeam + " - " + awayTeam + " / " + date
                ));
            }
        }

        return list;
    }

    public static ObservableList<OptionItem> getGamesWithTicketTariffsOptions() throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT
                g.id_game,
                g.datas,
                home.namec AS home_team_name,
                away.namec AS away_team_name
            FROM Game g
            JOIN Ticket t ON g.id_game = t.id_game
            LEFT JOIN Command home ON g.id_comand1 = home.id_comand
            LEFT JOIN Command away ON g.id_comand2 = away.id_comand
            WHERE COALESCE(t.is_available, TRUE) = TRUE
              AND t.place = 0
              AND t.rowse = 0
              AND t.sector = 'UNASSIGNED'
            ORDER BY g.id_game DESC
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                list.add(new OptionItem(
                        resultSet.getInt("id_game"),
                        "#" + resultSet.getInt("id_game")
                                + " " + resultSet.getString("home_team_name")
                                + " - " + resultSet.getString("away_team_name")
                                + " / " + resultSet.getDate("datas")
                ));
            }
        }

        return list;
    }

    public static ObservableList<String> getAvailableTicketTypesForGame(int gameId) throws SQLException {
        ObservableList<String> types = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT typese
            FROM Ticket
            WHERE id_game = ?
              AND COALESCE(is_available, TRUE) = TRUE
              AND place = 0
              AND rowse = 0
              AND sector = 'UNASSIGNED'
            ORDER BY typese
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, gameId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    types.add(resultSet.getString("typese"));
                }
            }
        }

        return types;
    }

    public static BigDecimal getTicketPrice(int gameId, String type) throws SQLException {
        String sql = """
            SELECT coust
            FROM Ticket
            WHERE id_game = ?
              AND typese = ?
              AND COALESCE(is_available, TRUE) = TRUE
              AND place = 0
              AND rowse = 0
              AND sector = 'UNASSIGNED'
            ORDER BY id_ticket DESC
            LIMIT 1
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, gameId);
            statement.setString(2, type);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getBigDecimal("coust");
                }
            }
        }

        throw new SQLException("Цена для выбранного типа билета не найдена.");
    }

    public static BigDecimal findTicketTariffPrice(int gameId, String type) throws SQLException {
        String sql = """
            SELECT coust
            FROM Ticket
            WHERE id_game = ?
              AND typese = ?
              AND place = 0
              AND rowse = 0
              AND sector = 'UNASSIGNED'
            ORDER BY id_ticket DESC
            LIMIT 1
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, gameId);
            statement.setString(2, type);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getBigDecimal("coust");
                }
            }
        }

        return null;
    }

    public static void saveTicketTariffs(
            int gameId,
            BigDecimal standardPrice,
            BigDecimal vipPrice,
            BigDecimal childPrice,
            boolean available
    ) throws SQLException {
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try {
                upsertTicketTariff(connection, gameId, "Standard", standardPrice, available);
                upsertTicketTariff(connection, gameId, "VIP", vipPrice, available);
                upsertTicketTariff(connection, gameId, "Child", childPrice, available);
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    private static void upsertTicketTariff(
            Connection connection,
            int gameId,
            String type,
            BigDecimal price,
            boolean available
    ) throws SQLException {
        if (price == null) {
            return;
        }

        String selectSql = """
            SELECT id_ticket
            FROM Ticket
            WHERE id_game = ?
              AND typese = ?
              AND place = 0
              AND rowse = 0
              AND sector = 'UNASSIGNED'
            ORDER BY id_ticket DESC
            LIMIT 1
            """;

        Integer ticketId = null;

        try (PreparedStatement statement = connection.prepareStatement(selectSql)) {
            statement.setInt(1, gameId);
            statement.setString(2, type);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    ticketId = resultSet.getInt("id_ticket");
                }
            }
        }

        if (ticketId == null) {
            try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO Ticket (id_game, typese, coust, place, rowse, sector, is_available)
                VALUES (?, ?, ?, 0, 0, 'UNASSIGNED', ?)
                """)) {

                statement.setInt(1, gameId);
                statement.setString(2, type);
                statement.setBigDecimal(3, price);
                statement.setBoolean(4, available);
                statement.executeUpdate();
            }

            return;
        }

        try (PreparedStatement statement = connection.prepareStatement("""
            UPDATE Ticket
            SET coust = ?,
                is_available = ?
            WHERE id_ticket = ?
            """)) {

            statement.setBigDecimal(1, price);
            statement.setBoolean(2, available);
            statement.setInt(3, ticketId);
            statement.executeUpdate();
        }
    }

    public static int purchaseTicket(
            String username,
            int gameId,
            String type,
            String sector,
            int row,
            int place
    ) throws SQLException {
        ensureUserBalanceColumn();

        BigDecimal price = getTicketPrice(gameId, type);
        if (username == null || username.isBlank()) {
            throw new SQLException("Пользователь не найден.");
        }

        String normalizedSector = sector == null ? "" : sector.trim().toUpperCase();

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try {
                Integer userId = getUserIdByUsername(connection, username);
                if (userId == null) {
                    throw new SQLException("Пользователь не найден.");
                }

                BigDecimal balance = getUserBalanceForUpdate(connection, userId);
                if (balance.compareTo(price) < 0) {
                    throw new SQLException("Недостаточно средств. Баланс: " + balance.toPlainString() + " MDL, цена: " + price.toPlainString() + " MDL.");
                }

                if (seatExists(connection, gameId, normalizedSector, row, place)) {
                    throw new SQLException("Это место уже занято для выбранного матча.");
                }

                updateUserBalance(connection, userId, balance.subtract(price));

                int ticketId;
                String ticketSql = """
                    INSERT INTO Ticket (id_game, typese, coust, place, rowse, sector, is_available)
                    VALUES (?, ?, ?, ?, ?, ?, FALSE)
                    RETURNING id_ticket
                    """;

                try (PreparedStatement statement = connection.prepareStatement(ticketSql)) {
                    statement.setInt(1, gameId);
                    statement.setString(2, type);
                    statement.setBigDecimal(3, price);
                    statement.setInt(4, place);
                    statement.setInt(5, row);
                    statement.setString(6, normalizedSector);

                    try (ResultSet resultSet = statement.executeQuery()) {
                        if (!resultSet.next()) {
                            throw new SQLException("Ticket id was not generated.");
                        }

                        ticketId = resultSet.getInt("id_ticket");
                    }
                }

                String saleSql = "INSERT INTO Sales (id_ticket, id_user, summa, payment_method) VALUES (?, ?, ?, 'Card')";
                try (PreparedStatement statement = connection.prepareStatement(saleSql)) {
                    statement.setInt(1, ticketId);
                    setNullableInt(statement, 2, userId);
                    statement.setBigDecimal(3, price);
                    statement.executeUpdate();
                }

                connection.commit();
                return ticketId;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    private static boolean seatExists(Connection connection, int gameId, String sector, int row, int place) throws SQLException {
        String sql = """
            SELECT id_ticket
            FROM Ticket
            WHERE id_game = ?
              AND UPPER(sector) = UPPER(?)
              AND rowse = ?
              AND place = ?
            """;

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, gameId);
            statement.setString(2, sector);
            statement.setInt(3, row);
            statement.setInt(4, place);

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public static ObservableList<Integer> getAvailablePlacesForSeat(int gameId, String sector, int row, int maxPlace) throws SQLException {
        ObservableList<Integer> places = FXCollections.observableArrayList();
        if (sector == null || sector.isBlank() || row <= 0 || maxPlace <= 0) {
            return places;
        }

        List<Integer> occupiedPlaces = new ArrayList<>();
        String sql = """
            SELECT place
            FROM Ticket
            WHERE id_game = ?
              AND UPPER(sector) = UPPER(?)
              AND rowse = ?
              AND place > 0
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, gameId);
            statement.setString(2, sector.trim());
            statement.setInt(3, row);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    occupiedPlaces.add(resultSet.getInt("place"));
                }
            }
        }

        for (int placeNumber = 1; placeNumber <= maxPlace; placeNumber++) {
            if (!occupiedPlaces.contains(placeNumber)) {
                places.add(placeNumber);
            }
        }

        return places;
    }

    public static BigDecimal getUserBalance(String username) throws SQLException {
        ensureUserBalanceColumn();

        String sql = "SELECT balance FROM AppUsers WHERE username = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    BigDecimal balance = resultSet.getBigDecimal("balance");
                    return balance == null ? BigDecimal.ZERO : balance;
                }
            }
        }

        return BigDecimal.ZERO;
    }

    public static void topUpUserBalance(String username, BigDecimal amount) throws SQLException {
        ensureUserBalanceColumn();

        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new SQLException("Сумма пополнения должна быть больше 0.");
        }

        String sql = "UPDATE AppUsers SET balance = COALESCE(balance, 0) + ? WHERE username = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setBigDecimal(1, amount);
            statement.setString(2, username);

            if (statement.executeUpdate() == 0) {
                throw new SQLException("Пользователь не найден.");
            }
        }
    }

    public static String getUserEmailByUsername(String username) throws SQLException {
        String sql = "SELECT email FROM AppUsers WHERE username = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("email");
                }
            }
        }

        return null;
    }

    private static void ensureUserBalanceColumn() throws SQLException {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {

            statement.execute("""
                ALTER TABLE AppUsers
                ADD COLUMN IF NOT EXISTS balance NUMERIC(10,2) NOT NULL DEFAULT 0
                """);
        }
    }

    private static Integer getUserIdByUsername(Connection connection, String username) throws SQLException {
        String sql = "SELECT id_user FROM AppUsers WHERE username = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("id_user");
                }
            }
        }

        return null;
    }

    private static BigDecimal getUserBalanceForUpdate(Connection connection, int userId) throws SQLException {
        String sql = "SELECT balance FROM AppUsers WHERE id_user = ? FOR UPDATE";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, userId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    BigDecimal balance = resultSet.getBigDecimal("balance");
                    return balance == null ? BigDecimal.ZERO : balance;
                }
            }
        }

        throw new SQLException("Пользователь не найден.");
    }

    private static void updateUserBalance(Connection connection, int userId, BigDecimal balance) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE AppUsers SET balance = ? WHERE id_user = ?")) {
            statement.setBigDecimal(1, balance);
            statement.setInt(2, userId);
            statement.executeUpdate();
        }
    }

    private static Integer getUserIdByUsername(String username) throws SQLException {
        String sql = "SELECT id_user FROM AppUsers WHERE username = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("id_user");
                }
            }
        }

        return null;
    }

    public static ObservableList<TicketModel> getTickets(
            String keyword,
            Integer gameId,
            String type,
            String sector,
            Boolean available
    ) throws SQLException {
        ObservableList<TicketModel> tickets = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT
                t.id_ticket,
                t.id_game,
                t.typese,
                t.coust,
                t.place,
                t.rowse,
                t.sector,
                COALESCE(t.is_available, TRUE) AS is_available,
                g.datas,
                home.namec AS home_team_name,
                away.namec AS away_team_name
            FROM Ticket t
            LEFT JOIN Game g ON t.id_game = g.id_game
            LEFT JOIN Command home ON g.id_comand1 = home.id_comand
            LEFT JOIN Command away ON g.id_comand2 = away.id_comand
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(t.id_ticket AS TEXT)) LIKE LOWER(?)
                    OR LOWER(COALESCE(t.typese, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(t.sector, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(home.namec, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(away.namec, '')) LIKE LOWER(?)
                )
                """);
        }

        if (gameId != null) {
            sql.append(" AND t.id_game = ? ");
        }

        if (type != null && !type.isBlank()) {
            sql.append(" AND t.typese = ? ");
        }

        if (sector != null && !sector.isBlank()) {
            sql.append(" AND t.sector = ? ");
        }

        if (available != null) {
            sql.append(" AND COALESCE(t.is_available, TRUE) = ? ");
        }

        sql.append(" ORDER BY t.id_ticket DESC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword.trim() + "%";
                for (int i = 0; i < 5; i++) {
                    statement.setString(index++, searchValue);
                }
            }

            if (gameId != null) {
                statement.setInt(index++, gameId);
            }

            if (type != null && !type.isBlank()) {
                statement.setString(index++, type);
            }

            if (sector != null && !sector.isBlank()) {
                statement.setString(index++, sector);
            }

            if (available != null) {
                statement.setBoolean(index++, available);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    tickets.add(mapTicket(resultSet));
                }
            }
        }

        return tickets;
    }

    public static TicketModel getTicketById(int ticketId) throws SQLException {
        String sql = """
            SELECT
                t.id_ticket,
                t.id_game,
                t.typese,
                t.coust,
                t.place,
                t.rowse,
                t.sector,
                COALESCE(t.is_available, TRUE) AS is_available,
                g.datas,
                home.namec AS home_team_name,
                away.namec AS away_team_name
            FROM Ticket t
            LEFT JOIN Game g ON t.id_game = g.id_game
            LEFT JOIN Command home ON g.id_comand1 = home.id_comand
            LEFT JOIN Command away ON g.id_comand2 = away.id_comand
            WHERE t.id_ticket = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, ticketId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapTicket(resultSet);
                }
            }
        }

        throw new SQLException("Ticket not found.");
    }

    private static TicketModel mapTicket(ResultSet resultSet) throws SQLException {
        Integer gameId = resultSet.getObject("id_game") == null ? null : resultSet.getInt("id_game");
        String gameName = "Без матча";

        if (gameId != null) {
            gameName = "#" + gameId + " "
                    + resultSet.getString("home_team_name")
                    + " - "
                    + resultSet.getString("away_team_name")
                    + " / "
                    + resultSet.getDate("datas");
        }

        return new TicketModel(
                resultSet.getInt("id_ticket"),
                gameId,
                gameName,
                resultSet.getString("typese"),
                resultSet.getBigDecimal("coust"),
                resultSet.getInt("place"),
                resultSet.getInt("rowse"),
                resultSet.getString("sector"),
                resultSet.getBoolean("is_available")
        );
    }

    public static ObservableList<String> getTicketTypes() throws SQLException {
        ObservableList<String> types = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT typese
            FROM Ticket
            WHERE typese IS NOT NULL AND typese <> ''
            ORDER BY typese
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                types.add(resultSet.getString("typese"));
            }
        }

        if (types.isEmpty()) {
            types.addAll("Standard", "VIP", "Child");
        }

        return types;
    }

    public static ObservableList<String> getTicketSectors() throws SQLException {
        ObservableList<String> sectors = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT sector
            FROM Ticket
            WHERE sector IS NOT NULL AND sector <> ''
            ORDER BY sector
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                sectors.add(resultSet.getString("sector"));
            }
        }

        return sectors;
    }

    public static void addTicket(
            Integer gameId,
            String type,
            BigDecimal cost,
            int place,
            int row,
            String sector,
            boolean available
    ) throws SQLException {
        String sql = """
            INSERT INTO Ticket (id_game, typese, coust, place, rowse, sector, is_available)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            if (gameId == null) {
                statement.setObject(1, null);
            } else {
                statement.setInt(1, gameId);
            }

            statement.setString(2, type);
            statement.setBigDecimal(3, cost);
            statement.setInt(4, place);
            statement.setInt(5, row);
            statement.setString(6, sector);
            statement.setBoolean(7, available);
            statement.executeUpdate();
        }
    }

    public static void updateTicket(
            int ticketId,
            Integer gameId,
            String type,
            BigDecimal cost,
            int place,
            int row,
            String sector,
            boolean available
    ) throws SQLException {
        String sql = """
            UPDATE Ticket
            SET id_game = ?,
                typese = ?,
                coust = ?,
                place = ?,
                rowse = ?,
                sector = ?,
                is_available = ?
            WHERE id_ticket = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            if (gameId == null) {
                statement.setObject(1, null);
            } else {
                statement.setInt(1, gameId);
            }

            statement.setString(2, type);
            statement.setBigDecimal(3, cost);
            statement.setInt(4, place);
            statement.setInt(5, row);
            statement.setString(6, sector);
            statement.setBoolean(7, available);
            statement.setInt(8, ticketId);

            int rows = statement.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Ticket not found.");
            }
        }
    }

    public static void deleteTicketById(int ticketId) throws SQLException {
        String sql = "DELETE FROM Ticket WHERE id_ticket = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, ticketId);

            int rows = statement.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Ticket not found.");
            }
        }
    }

    public static ObservableList<OptionItem> getTicketOptions() throws SQLException {
        ObservableList<OptionItem> tickets = FXCollections.observableArrayList();

        String sql = """
            SELECT id_ticket, typese, sector, rowse, place, coust
            FROM Ticket
            ORDER BY id_ticket DESC
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                tickets.add(new OptionItem(
                        resultSet.getInt("id_ticket"),
                        "#" + resultSet.getInt("id_ticket")
                                + " " + resultSet.getString("typese")
                                + " / " + resultSet.getString("sector")
                                + "-" + resultSet.getInt("rowse")
                                + "-" + resultSet.getInt("place")
                                + " / " + resultSet.getBigDecimal("coust")
                ));
            }
        }

        return tickets;
    }

    public static ObservableList<OptionItem> getUserOptions() throws SQLException {
        ObservableList<OptionItem> users = FXCollections.observableArrayList();

        String sql = "SELECT id_user, username FROM AppUsers ORDER BY username";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                users.add(new OptionItem(resultSet.getInt("id_user"), resultSet.getString("username")));
            }
        }

        return users;
    }

    public static ObservableList<SaleModel> getSales(
            String keyword,
            Integer ticketId,
            Integer userId,
            String paymentMethod
    ) throws SQLException {
        ObservableList<SaleModel> sales = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT
                s.id_sale,
                s.id_ticket,
                s.id_user,
                s.summa,
                s.sale_date,
                s.payment_method,
                u.username,
                t.typese,
                t.sector,
                t.rowse,
                t.place
            FROM Sales s
            LEFT JOIN AppUsers u ON s.id_user = u.id_user
            LEFT JOIN Ticket t ON s.id_ticket = t.id_ticket
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(s.id_sale AS TEXT)) LIKE LOWER(?)
                    OR LOWER(COALESCE(u.username, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(t.typese, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(s.payment_method, '')) LIKE LOWER(?)
                )
                """);
        }

        if (ticketId != null) {
            sql.append(" AND s.id_ticket = ? ");
        }

        if (userId != null) {
            sql.append(" AND s.id_user = ? ");
        }

        if (paymentMethod != null && !paymentMethod.isBlank()) {
            sql.append(" AND s.payment_method = ? ");
        }

        sql.append(" ORDER BY s.id_sale DESC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword.trim() + "%";
                for (int i = 0; i < 4; i++) {
                    statement.setString(index++, searchValue);
                }
            }

            if (ticketId != null) {
                statement.setInt(index++, ticketId);
            }

            if (userId != null) {
                statement.setInt(index++, userId);
            }

            if (paymentMethod != null && !paymentMethod.isBlank()) {
                statement.setString(index++, paymentMethod);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    sales.add(mapSale(resultSet));
                }
            }
        }

        return sales;
    }

    public static SaleModel getSaleById(int saleId) throws SQLException {
        String sql = """
            SELECT
                s.id_sale,
                s.id_ticket,
                s.id_user,
                s.summa,
                s.sale_date,
                s.payment_method,
                u.username,
                t.typese,
                t.sector,
                t.rowse,
                t.place
            FROM Sales s
            LEFT JOIN AppUsers u ON s.id_user = u.id_user
            LEFT JOIN Ticket t ON s.id_ticket = t.id_ticket
            WHERE s.id_sale = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, saleId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapSale(resultSet);
                }
            }
        }

        throw new SQLException("Sale not found.");
    }

    private static SaleModel mapSale(ResultSet resultSet) throws SQLException {
        Integer ticketId = resultSet.getObject("id_ticket") == null ? null : resultSet.getInt("id_ticket");
        Integer userId = resultSet.getObject("id_user") == null ? null : resultSet.getInt("id_user");

        String ticketName = "Без билета";
        if (ticketId != null) {
            ticketName = "#" + ticketId
                    + " " + resultSet.getString("typese")
                    + " / " + resultSet.getString("sector")
                    + "-" + resultSet.getInt("rowse")
                    + "-" + resultSet.getInt("place");
        }

        return new SaleModel(
                resultSet.getInt("id_sale"),
                ticketId,
                userId,
                ticketName,
                resultSet.getString("username") == null ? "Без пользователя" : resultSet.getString("username"),
                resultSet.getBigDecimal("summa"),
                String.valueOf(resultSet.getTimestamp("sale_date")),
                resultSet.getString("payment_method")
        );
    }

    public static ObservableList<String> getPaymentMethods() throws SQLException {
        ObservableList<String> methods = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT payment_method
            FROM Sales
            WHERE payment_method IS NOT NULL AND payment_method <> ''
            ORDER BY payment_method
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                methods.add(resultSet.getString("payment_method"));
            }
        }

        if (methods.isEmpty()) {
            methods.addAll("Card", "Cash", "Online");
        }

        return methods;
    }

    public static void addSale(Integer ticketId, Integer userId, BigDecimal amount, String paymentMethod) throws SQLException {
        String sql = "INSERT INTO Sales (id_ticket, id_user, summa, payment_method) VALUES (?, ?, ?, ?)";

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                setNullableInt(statement, 1, ticketId);
                setNullableInt(statement, 2, userId);
                statement.setBigDecimal(3, amount);
                statement.setString(4, paymentMethod);
                statement.executeUpdate();

                updateTicketAvailability(connection, ticketId, false);
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public static void updateSale(int saleId, Integer ticketId, Integer userId, BigDecimal amount, String paymentMethod) throws SQLException {
        String sql = "UPDATE Sales SET id_ticket = ?, id_user = ?, summa = ?, payment_method = ? WHERE id_sale = ?";

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                setNullableInt(statement, 1, ticketId);
                setNullableInt(statement, 2, userId);
                statement.setBigDecimal(3, amount);
                statement.setString(4, paymentMethod);
                statement.setInt(5, saleId);

                int rows = statement.executeUpdate();
                if (rows == 0) {
                    throw new SQLException("Sale not found.");
                }

                updateTicketAvailability(connection, ticketId, false);
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public static void deleteSaleById(int saleId) throws SQLException {
        String sql = "DELETE FROM Sales WHERE id_sale = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, saleId);

            int rows = statement.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Sale not found.");
            }
        }
    }

    private static void updateTicketAvailability(Connection connection, Integer ticketId, boolean available) throws SQLException {
        if (ticketId == null) {
            return;
        }

        try (PreparedStatement statement = connection.prepareStatement("UPDATE Ticket SET is_available = ? WHERE id_ticket = ?")) {
            statement.setBoolean(1, available);
            statement.setInt(2, ticketId);
            statement.executeUpdate();
        }
    }

    private static void setNullableInt(PreparedStatement statement, int index, Integer value) throws SQLException {
        if (value == null) {
            statement.setObject(index, null);
        } else {
            statement.setInt(index, value);
        }
    }

    public static ObservableList<TournamentModel> getTournaments(
            String keyword,
            Integer teamId,
            Integer stadiumId
    ) throws SQLException {
        return getTournaments(keyword, teamId, stadiumId, null);
    }

    public static ObservableList<TournamentModel> getTournaments(
            String keyword,
            Integer teamId,
            Integer stadiumId,
            String country
    ) throws SQLException {
        ObservableList<TournamentModel> list = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT
                t.id_tourner,
                t.namet,
                COUNT(DISTINCT tt.id_comand) AS teams_count,
                COUNT(DISTINCT ts.id_stadium) AS stadiums_count,
                COALESCE(STRING_AGG(DISTINCT c.namec, ', ' ORDER BY c.namec), '') AS teams,
                COALESCE(STRING_AGG(DISTINCT s.name_stadium, ', ' ORDER BY s.name_stadium), '') AS stadiums
            FROM Tourner t
            LEFT JOIN TournamentTeams tt ON t.id_tourner = tt.id_tourner
            LEFT JOIN Command c ON tt.id_comand = c.id_comand
            LEFT JOIN TournamentStadiums ts ON t.id_tourner = ts.id_tourner
            LEFT JOIN Stadiums s ON ts.id_stadium = s.id_stadium
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(t.id_tourner AS TEXT)) LIKE LOWER(?)
                    OR LOWER(t.namet) LIKE LOWER(?)
                    OR EXISTS (
                        SELECT 1
                        FROM TournamentTeams ttf
                        JOIN Command cf ON ttf.id_comand = cf.id_comand
                        WHERE ttf.id_tourner = t.id_tourner
                          AND (LOWER(cf.namec) LIKE LOWER(?) OR LOWER(COALESCE(cf.country, '')) LIKE LOWER(?))
                    )
                    OR EXISTS (
                        SELECT 1
                        FROM TournamentStadiums tsf
                        JOIN Stadiums sf ON tsf.id_stadium = sf.id_stadium
                        WHERE tsf.id_tourner = t.id_tourner
                          AND LOWER(sf.name_stadium) LIKE LOWER(?)
                    )
                )
                """);
        }

        if (teamId != null) {
            sql.append("""
                AND EXISTS (
                    SELECT 1
                    FROM TournamentTeams ttf
                    WHERE ttf.id_tourner = t.id_tourner
                      AND ttf.id_comand = ?
                )
                """);
        }

        if (country != null && !country.isBlank()) {
            sql.append("""
                AND EXISTS (
                    SELECT 1
                    FROM TournamentTeams ttf
                    JOIN Command cf ON ttf.id_comand = cf.id_comand
                    WHERE ttf.id_tourner = t.id_tourner
                      AND cf.country = ?
                )
                """);
        }

        if (stadiumId != null) {
            sql.append("""
                AND EXISTS (
                    SELECT 1
                    FROM TournamentStadiums tsf
                    WHERE tsf.id_tourner = t.id_tourner
                      AND tsf.id_stadium = ?
                )
                """);
        }

        sql.append("""
            GROUP BY t.id_tourner, t.namet
            ORDER BY t.id_tourner DESC
            """);

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword.trim() + "%";
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
            }

            if (teamId != null) {
                statement.setInt(index++, teamId);
            }

            if (country != null && !country.isBlank()) {
                statement.setString(index++, country);
            }

            if (stadiumId != null) {
                statement.setInt(index++, stadiumId);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    list.add(new TournamentModel(
                            resultSet.getInt("id_tourner"),
                            resultSet.getString("namet"),
                            resultSet.getInt("teams_count"),
                            resultSet.getInt("stadiums_count"),
                            resultSet.getString("teams"),
                            resultSet.getString("stadiums")
                    ));
                }
            }
        }

        return list;
    }

    public static ObservableList<StandingModel> getStandingsByTournament(int tournamentId) throws SQLException {
        List<StandingAccumulator> standings = new ArrayList<>();

        String teamsSql = """
            SELECT c.id_comand, c.namec
            FROM TournamentTeams tt
            JOIN Command c ON tt.id_comand = c.id_comand
            WHERE tt.id_tourner = ?
            ORDER BY c.namec
            """;

        try (Connection connection = getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(teamsSql)) {
                statement.setInt(1, tournamentId);

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        standings.add(new StandingAccumulator(
                                resultSet.getInt("id_comand"),
                                resultSet.getString("namec")
                        ));
                    }
                }
            }

            applyTournamentResults(connection, tournamentId, standings);
        }

        standings.sort((left, right) -> {
            int byPoints = Integer.compare(right.points, left.points);
            if (byPoints != 0) {
                return byPoints;
            }

            int byGoalDifference = Integer.compare(right.goalDifference(), left.goalDifference());
            if (byGoalDifference != 0) {
                return byGoalDifference;
            }

            int byGoalsFor = Integer.compare(right.goalsFor, left.goalsFor);
            if (byGoalsFor != 0) {
                return byGoalsFor;
            }

            return left.teamName.compareToIgnoreCase(right.teamName);
        });

        ObservableList<StandingModel> rows = FXCollections.observableArrayList();

        for (int i = 0; i < standings.size(); i++) {
            StandingAccumulator standing = standings.get(i);
            rows.add(standing.toModel(i + 1));
        }

        return rows;
    }

    private static void applyTournamentResults(
            Connection connection,
            int tournamentId,
            List<StandingAccumulator> standings
    ) throws SQLException {
        String gamesSql = """
            SELECT id_comand1, id_comand2, score
            FROM Game
            WHERE id_tourner = ?
              AND score IS NOT NULL
              AND score ~ '^[0-9]+-[0-9]+$'
            """;

        try (PreparedStatement statement = connection.prepareStatement(gamesSql)) {
            statement.setInt(1, tournamentId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    StandingAccumulator home = findStanding(standings, resultSet.getInt("id_comand1"));
                    StandingAccumulator away = findStanding(standings, resultSet.getInt("id_comand2"));

                    if (home == null || away == null) {
                        continue;
                    }

                    String[] scoreParts = resultSet.getString("score").split("-");
                    int homeGoals = Integer.parseInt(scoreParts[0]);
                    int awayGoals = Integer.parseInt(scoreParts[1]);

                    home.applyMatch(homeGoals, awayGoals);
                    away.applyMatch(awayGoals, homeGoals);
                }
            }
        }
    }

    private static StandingAccumulator findStanding(List<StandingAccumulator> standings, int teamId) {
        for (StandingAccumulator standing : standings) {
            if (standing.teamId == teamId) {
                return standing;
            }
        }

        return null;
    }

    private static class StandingAccumulator {
        private final int teamId;
        private final String teamName;
        private int played;
        private int wins;
        private int draws;
        private int losses;
        private int goalsFor;
        private int goalsAgainst;
        private int points;

        private StandingAccumulator(int teamId, String teamName) {
            this.teamId = teamId;
            this.teamName = teamName;
        }

        private void applyMatch(int scored, int conceded) {
            played++;
            goalsFor += scored;
            goalsAgainst += conceded;

            if (scored > conceded) {
                wins++;
                points += 3;
            } else if (scored == conceded) {
                draws++;
                points++;
            } else {
                losses++;
            }
        }

        private int goalDifference() {
            return goalsFor - goalsAgainst;
        }

        private StandingModel toModel(int position) {
            return new StandingModel(
                    position,
                    teamId,
                    teamName,
                    played,
                    wins,
                    draws,
                    losses,
                    goalsFor,
                    goalsAgainst,
                    points
            );
        }
    }

    public static ObservableList<String> getTournamentTeamCountries() throws SQLException {
        ObservableList<String> countries = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT c.country
            FROM TournamentTeams tt
            JOIN Command c ON tt.id_comand = c.id_comand
            WHERE c.country IS NOT NULL AND c.country <> ''
            ORDER BY c.country
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                countries.add(resultSet.getString("country"));
            }
        }

        return countries;
    }

    public static TournamentFormData getTournamentById(int tournamentId) throws SQLException {
        String sql = "SELECT id_tourner, namet FROM Tourner WHERE id_tourner = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, tournamentId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new TournamentFormData(
                            resultSet.getInt("id_tourner"),
                            resultSet.getString("namet"),
                            getTournamentTeamIds(connection, tournamentId),
                            getTournamentStadiumIds(connection, tournamentId)
                    );
                }
            }
        }

        throw new SQLException("Tournament not found.");
    }

    public static void addTournament(String name, List<Integer> teamIds, List<Integer> stadiumIds) throws SQLException {
        String sql = "INSERT INTO Tourner (namet) VALUES (?)";

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, name);
                statement.executeUpdate();

                try (ResultSet keys = statement.getGeneratedKeys()) {
                    if (!keys.next()) {
                        throw new SQLException("Tournament id was not generated.");
                    }

                    int tournamentId = keys.getInt(1);
                    replaceTournamentLinks(connection, tournamentId, teamIds, stadiumIds);
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public static void updateTournament(int tournamentId, String name, List<Integer> teamIds, List<Integer> stadiumIds) throws SQLException {
        String sql = "UPDATE Tourner SET namet = ? WHERE id_tourner = ?";

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setInt(2, tournamentId);

                int rows = statement.executeUpdate();
                if (rows == 0) {
                    throw new SQLException("Tournament not found.");
                }

                replaceTournamentLinks(connection, tournamentId, teamIds, stadiumIds);
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public static void deleteTournamentById(int tournamentId) throws SQLException {
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try {
                deleteTournamentLinks(connection, tournamentId);

                try (PreparedStatement statement = connection.prepareStatement("DELETE FROM Tourner WHERE id_tourner = ?")) {
                    statement.setInt(1, tournamentId);

                    int rows = statement.executeUpdate();
                    if (rows == 0) {
                        throw new SQLException("Tournament not found.");
                    }
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    private static List<Integer> getTournamentTeamIds(Connection connection, int tournamentId) throws SQLException {
        return getLinkedIds(connection, "SELECT id_comand FROM TournamentTeams WHERE id_tourner = ?", tournamentId);
    }

    private static List<Integer> getTournamentStadiumIds(Connection connection, int tournamentId) throws SQLException {
        return getLinkedIds(connection, "SELECT id_stadium FROM TournamentStadiums WHERE id_tourner = ?", tournamentId);
    }

    private static List<Integer> getLinkedIds(Connection connection, String sql, int tournamentId) throws SQLException {
        List<Integer> ids = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, tournamentId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    ids.add(resultSet.getInt(1));
                }
            }
        }

        return ids;
    }

    private static void replaceTournamentLinks(
            Connection connection,
            int tournamentId,
            List<Integer> teamIds,
            List<Integer> stadiumIds
    ) throws SQLException {
        deleteTournamentLinks(connection, tournamentId);
        insertTournamentLinks(connection, "INSERT INTO TournamentTeams (id_tourner, id_comand) VALUES (?, ?)", tournamentId, teamIds);
        insertTournamentLinks(connection, "INSERT INTO TournamentStadiums (id_tourner, id_stadium) VALUES (?, ?)", tournamentId, stadiumIds);
    }

    private static void deleteTournamentLinks(Connection connection, int tournamentId) throws SQLException {
        try (PreparedStatement teamsStatement = connection.prepareStatement("DELETE FROM TournamentTeams WHERE id_tourner = ?");
             PreparedStatement stadiumsStatement = connection.prepareStatement("DELETE FROM TournamentStadiums WHERE id_tourner = ?")) {

            teamsStatement.setInt(1, tournamentId);
            teamsStatement.executeUpdate();

            stadiumsStatement.setInt(1, tournamentId);
            stadiumsStatement.executeUpdate();
        }
    }

    private static void insertTournamentLinks(Connection connection, String sql, int tournamentId, List<Integer> ids) throws SQLException {
        if (ids == null || ids.isEmpty()) {
            return;
        }

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            for (Integer id : ids) {
                statement.setInt(1, tournamentId);
                statement.setInt(2, id);
                statement.addBatch();
            }

            statement.executeBatch();
        }
    }

    public static ObservableList<OptionItem> getTeamsOptions() throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT id_comand, namec
            FROM Command
            ORDER BY namec
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                list.add(new OptionItem(
                        resultSet.getInt("id_comand"),
                        resultSet.getString("namec")
                ));
            }
        }

        return list;
    }

    public static ObservableList<OptionItem> getStadiumsOptions() throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT id_stadium, name_stadium, city
            FROM Stadiums
            ORDER BY name_stadium
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String name = resultSet.getString("name_stadium");
                String city = resultSet.getString("city");

                if (city != null && !city.isBlank()) {
                    name += " / " + city;
                }

                list.add(new OptionItem(
                        resultSet.getInt("id_stadium"),
                        name
                ));
            }
        }

        return list;
    }

    public static ObservableList<StadiumModel> getStadiums(String keyword, String cityFilter) throws SQLException {
        ObservableList<StadiumModel> list = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT id_stadium, name_stadium, city, capacity
            FROM Stadiums
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(id_stadium AS TEXT)) LIKE LOWER(?)
                    OR LOWER(COALESCE(name_stadium, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(city, '')) LIKE LOWER(?)
                )
                """);
        }

        if (cityFilter != null && !cityFilter.isBlank()) {
            sql.append(" AND city = ? ");
        }

        sql.append(" ORDER BY id_stadium DESC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword.trim() + "%";
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
            }

            if (cityFilter != null && !cityFilter.isBlank()) {
                statement.setString(index++, cityFilter);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    list.add(new StadiumModel(
                            resultSet.getInt("id_stadium"),
                            resultSet.getString("name_stadium"),
                            resultSet.getString("city"),
                            resultSet.getInt("capacity")
                    ));
                }
            }
        }

        return list;
    }

    public static ObservableList<String> getStadiumCities() throws SQLException {
        ObservableList<String> cities = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT city
            FROM Stadiums
            WHERE city IS NOT NULL AND city <> ''
            ORDER BY city
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                cities.add(resultSet.getString("city"));
            }
        }

        return cities;
    }

    public static void addStadium(String name, String city, int capacity) throws SQLException {
        String sql = """
            INSERT INTO Stadiums (name_stadium, city, capacity)
            VALUES (?, ?, ?)
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, name);
            statement.setString(2, city);
            statement.setInt(3, capacity);
            statement.executeUpdate();
        }
    }

    public static void updateStadium(int stadiumId, String name, String city, int capacity) throws SQLException {
        String sql = """
            UPDATE Stadiums
            SET name_stadium = ?,
                city = ?,
                capacity = ?
            WHERE id_stadium = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, name);
            statement.setString(2, city);
            statement.setInt(3, capacity);
            statement.setInt(4, stadiumId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Stadium not found.");
            }
        }
    }

    public static void deleteStadiumById(int stadiumId) throws SQLException {
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);

            try {
                try (PreparedStatement linksStatement = connection.prepareStatement("DELETE FROM TournamentStadiums WHERE id_stadium = ?")) {
                    linksStatement.setInt(1, stadiumId);
                    linksStatement.executeUpdate();
                }

                try (PreparedStatement statement = connection.prepareStatement("DELETE FROM Stadiums WHERE id_stadium = ?")) {
                    statement.setInt(1, stadiumId);

                    int rows = statement.executeUpdate();
                    if (rows == 0) {
                        throw new SQLException("Stadium not found.");
                    }
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public static ObservableList<OptionItem> getRefereesOptions() throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT id_referee, full_name, category
            FROM Referees
            ORDER BY full_name
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String name = resultSet.getString("full_name");
                String category = resultSet.getString("category");

                if (category != null && !category.isBlank()) {
                    name += " / " + category;
                }

                list.add(new OptionItem(
                        resultSet.getInt("id_referee"),
                        name
                ));
            }
        }

        return list;
    }

    public static ObservableList<RefereeModel> getReferees(String keyword) throws SQLException {
        ObservableList<RefereeModel> list = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT id_referee, full_name, experience_years, category
            FROM Referees
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(id_referee AS TEXT)) LIKE LOWER(?)
                    OR LOWER(COALESCE(full_name, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(category, '')) LIKE LOWER(?)
                )
                """);
        }

        sql.append(" ORDER BY id_referee DESC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword.trim() + "%";
                statement.setString(1, searchValue);
                statement.setString(2, searchValue);
                statement.setString(3, searchValue);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    list.add(new RefereeModel(
                            resultSet.getInt("id_referee"),
                            resultSet.getString("full_name"),
                            resultSet.getInt("experience_years"),
                            resultSet.getString("category")
                    ));
                }
            }
        }

        return list;
    }

    public static void addReferee(String fullName, int experienceYears, String category) throws SQLException {
        String sql = """
            INSERT INTO Referees (full_name, experience_years, category)
            VALUES (?, ?, ?)
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, fullName);
            statement.setInt(2, experienceYears);
            statement.setString(3, category);
            statement.executeUpdate();
        }
    }

    public static void updateReferee(int refereeId, String fullName, int experienceYears, String category) throws SQLException {
        String sql = """
            UPDATE Referees
            SET full_name = ?,
                experience_years = ?,
                category = ?
            WHERE id_referee = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, fullName);
            statement.setInt(2, experienceYears);
            statement.setString(3, category);
            statement.setInt(4, refereeId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Referee not found.");
            }
        }
    }

    public static void deleteRefereeById(int refereeId) throws SQLException {
        String sql = "DELETE FROM Referees WHERE id_referee = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, refereeId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Referee not found.");
            }
        }
    }

    private static String generateMatchCode() {
        return "M" + System.currentTimeMillis();
    }

    public static ObservableList<OptionItem> getTeamsOptionsByTournament(int tournamentId) throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT c.id_comand, c.namec
            FROM Command c
            JOIN TournamentTeams tt ON c.id_comand = tt.id_comand
            WHERE tt.id_tourner = ?
            ORDER BY c.namec
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, tournamentId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    list.add(new OptionItem(
                            resultSet.getInt("id_comand"),
                            resultSet.getString("namec")
                    ));
                }
            }
        }

        return list;
    }

    public static ObservableList<OptionItem> getStadiumsOptionsByTournament(int tournamentId) throws SQLException {
        ObservableList<OptionItem> list = FXCollections.observableArrayList();

        String sql = """
            SELECT s.id_stadium, s.name_stadium, s.city
            FROM Stadiums s
            JOIN TournamentStadiums ts ON s.id_stadium = ts.id_stadium
            WHERE ts.id_tourner = ?
            ORDER BY s.name_stadium
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, tournamentId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String name = resultSet.getString("name_stadium");
                    String city = resultSet.getString("city");

                    if (city != null && !city.isBlank()) {
                        name += " / " + city;
                    }

                    list.add(new OptionItem(
                            resultSet.getInt("id_stadium"),
                            name
                    ));
                }
            }
        }

        return list;
    }

    public static ObservableList<UserModel> getUsers(String keyword) throws SQLException {
        ObservableList<UserModel> users = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT
                id_user,
                username,
                email,
                user_role,
                is_active,
                created_at
            FROM AppUsers
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(id_user AS TEXT)) LIKE LOWER(?)
                    OR LOWER(username) LIKE LOWER(?)
                    OR LOWER(email) LIKE LOWER(?)
                    OR LOWER(user_role) LIKE LOWER(?)
                )
                """);
        }

        sql.append(" ORDER BY id_user ASC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword + "%";

                statement.setString(1, searchValue);
                statement.setString(2, searchValue);
                statement.setString(3, searchValue);
                statement.setString(4, searchValue);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    users.add(new UserModel(
                            resultSet.getInt("id_user"),
                            resultSet.getString("username"),
                            resultSet.getString("email"),
                            resultSet.getString("user_role"),
                            resultSet.getBoolean("is_active"),
                            String.valueOf(resultSet.getTimestamp("created_at"))
                    ));
                }
            }
        }

        return users;
    }

    public static void updateUserRole(int userId, String role) throws SQLException {
        String sql = """
            UPDATE AppUsers
            SET user_role = ?
            WHERE id_user = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, role);
            statement.setInt(2, userId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("User was not found.");
            }
        }
    }

    public static void updateUserActiveStatus(int userId, boolean active) throws SQLException {
        String sql = """
            UPDATE AppUsers
            SET is_active = ?
            WHERE id_user = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setBoolean(1, active);
            statement.setInt(2, userId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("User was not found.");
            }
        }
    }

    public static ObservableList<TeamModel> getTeams(String keyword) throws SQLException {
        return getTeams(keyword, null);
    }

    public static ObservableList<TeamModel> getTeams(String keyword, String countryFilter) throws SQLException {
        ObservableList<TeamModel> teams = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT id_comand, namec, country
            FROM Command
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(id_comand AS TEXT)) LIKE LOWER(?)
                    OR LOWER(namec) LIKE LOWER(?)
                    OR LOWER(country) LIKE LOWER(?)
                )
                """);
        }

        if (countryFilter != null && !countryFilter.isBlank()) {
            sql.append(" AND country = ? ");
        }

        sql.append(" ORDER BY id_comand ASC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String searchValue = "%" + keyword + "%";

                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
                statement.setString(index++, searchValue);
            }

            if (countryFilter != null && !countryFilter.isBlank()) {
                statement.setString(index, countryFilter);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    teams.add(new TeamModel(
                            resultSet.getInt("id_comand"),
                            resultSet.getString("namec"),
                            resultSet.getString("country")
                    ));
                }
            }
        }

        return teams;
    }

    public static ObservableList<String> getTeamCountries() throws SQLException {
        ObservableList<String> countries = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT country
            FROM Command
            WHERE country IS NOT NULL AND country <> ''
            ORDER BY country
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                countries.add(resultSet.getString("country"));
            }
        }

        return countries;
    }

    public static TeamModel getTeamById(int teamId) throws SQLException {
        String sql = """
            SELECT id_comand, namec, country
            FROM Command
            WHERE id_comand = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, teamId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new TeamModel(
                            resultSet.getInt("id_comand"),
                            resultSet.getString("namec"),
                            resultSet.getString("country")
                    );
                }
            }
        }

        throw new SQLException("Team not found.");
    }

    public static void addTeam(String name, String country) throws SQLException {
        String sql = """
            INSERT INTO Command (namec, country)
            VALUES (?, ?)
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, name);
            statement.setString(2, country);
            statement.executeUpdate();
        }
    }

    public static void updateTeam(int teamId, String name, String country) throws SQLException {
        String sql = """
            UPDATE Command
            SET namec = ?, country = ?
            WHERE id_comand = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, name);
            statement.setString(2, country);
            statement.setInt(3, teamId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Team not found.");
            }
        }
    }

    public static void deleteTeamById(int teamId) throws SQLException {
        String sql = "DELETE FROM Command WHERE id_comand = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, teamId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Team not found.");
            }
        }
    }

    public static ObservableList<PlayerModel> getPlayers(
            String keyword,
            Integer teamId,
            String position,
            String status
    ) throws SQLException {
        return getPlayers(keyword, teamId, position, status, null);
    }

    public static ObservableList<PlayerModel> getPlayers(
            String keyword,
            Integer teamId,
            String position,
            String status,
            String nationality
    ) throws SQLException {
        ObservableList<PlayerModel> players = FXCollections.observableArrayList();

        StringBuilder sql = new StringBuilder("""
            SELECT
                p.id_player,
                p.id_comand,
                c.namec AS team_name,
                p.full_name,
                p.position,
                p.number,
                p.age,
                p.nationality,
                p.goals,
                p.assists,
                p.yellow_cards,
                p.red_cards,
                p.status
            FROM Players p
            LEFT JOIN Command c ON p.id_comand = c.id_comand
            WHERE 1 = 1
            """);

        if (keyword != null && !keyword.isBlank()) {
            sql.append("""
                AND (
                    LOWER(CAST(p.id_player AS TEXT)) LIKE LOWER(?)
                    OR LOWER(COALESCE(p.full_name, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(c.namec, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(p.position, '')) LIKE LOWER(?)
                    OR LOWER(COALESCE(p.nationality, '')) LIKE LOWER(?)
                )
                """);
        }

        if (teamId != null) {
            sql.append(" AND p.id_comand = ? ");
        }

        if (position != null && !position.isBlank()) {
            sql.append(" AND p.position = ? ");
        }

        if (status != null && !status.isBlank()) {
            sql.append(" AND p.status = ? ");
        }

        if (nationality != null && !nationality.isBlank()) {
            sql.append(" AND p.nationality = ? ");
        }

        sql.append(" ORDER BY p.id_player ASC ");

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.isBlank()) {
                String value = "%" + keyword + "%";

                for (int i = 0; i < 5; i++) {
                    statement.setString(index++, value);
                }
            }

            if (teamId != null) {
                statement.setInt(index++, teamId);
            }

            if (position != null && !position.isBlank()) {
                statement.setString(index++, position);
            }

            if (status != null && !status.isBlank()) {
                statement.setString(index++, status);
            }

            if (nationality != null && !nationality.isBlank()) {
                statement.setString(index++, nationality);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    players.add(mapPlayer(resultSet));
                }
            }
        }

        return players;
    }

    public static ObservableList<String> getPlayerNationalities() throws SQLException {
        ObservableList<String> nationalities = FXCollections.observableArrayList();

        String sql = """
            SELECT DISTINCT nationality
            FROM Players
            WHERE nationality IS NOT NULL AND nationality <> ''
            ORDER BY nationality
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                nationalities.add(resultSet.getString("nationality"));
            }
        }

        return nationalities;
    }

    public static PlayerModel getPlayerById(int playerId) throws SQLException {
        String sql = """
            SELECT
                p.id_player,
                p.id_comand,
                c.namec AS team_name,
                p.full_name,
                p.position,
                p.number,
                p.age,
                p.nationality,
                p.goals,
                p.assists,
                p.yellow_cards,
                p.red_cards,
                p.status
            FROM Players p
            LEFT JOIN Command c ON p.id_comand = c.id_comand
            WHERE p.id_player = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, playerId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapPlayer(resultSet);
                }
            }
        }

        throw new SQLException("Player not found.");
    }

    private static PlayerModel mapPlayer(ResultSet resultSet) throws SQLException {
        return new PlayerModel(
                resultSet.getInt("id_player"),
                resultSet.getInt("id_comand"),
                resultSet.getString("team_name"),
                resultSet.getString("full_name"),
                resultSet.getString("position"),
                resultSet.getInt("number"),
                resultSet.getInt("age"),
                resultSet.getString("nationality"),
                resultSet.getInt("goals"),
                resultSet.getInt("assists"),
                resultSet.getInt("yellow_cards"),
                resultSet.getInt("red_cards"),
                resultSet.getString("status")
        );
    }

    public static void addPlayer(
            int teamId,
            String fullName,
            String position,
            int number,
            int age,
            String nationality,
            int goals,
            int assists,
            int yellowCards,
            int redCards,
            String status
    ) throws SQLException {
        String sql = """
            INSERT INTO Players (
                id_comand,
                full_name,
                position,
                number,
                age,
                nationality,
                goals,
                assists,
                yellow_cards,
                red_cards,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, teamId);
            statement.setString(2, fullName);
            statement.setString(3, position);
            statement.setInt(4, number);
            statement.setInt(5, age);
            statement.setString(6, nationality);
            statement.setInt(7, goals);
            statement.setInt(8, assists);
            statement.setInt(9, yellowCards);
            statement.setInt(10, redCards);
            statement.setString(11, status);

            statement.executeUpdate();
        }
    }

    public static void updatePlayer(
            int playerId,
            int teamId,
            String fullName,
            String position,
            int number,
            int age,
            String nationality,
            int goals,
            int assists,
            int yellowCards,
            int redCards,
            String status
    ) throws SQLException {
        String sql = """
            UPDATE Players
            SET
                id_comand = ?,
                full_name = ?,
                position = ?,
                number = ?,
                age = ?,
                nationality = ?,
                goals = ?,
                assists = ?,
                yellow_cards = ?,
                red_cards = ?,
                status = ?
            WHERE id_player = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, teamId);
            statement.setString(2, fullName);
            statement.setString(3, position);
            statement.setInt(4, number);
            statement.setInt(5, age);
            statement.setString(6, nationality);
            statement.setInt(7, goals);
            statement.setInt(8, assists);
            statement.setInt(9, yellowCards);
            statement.setInt(10, redCards);
            statement.setString(11, status);
            statement.setInt(12, playerId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Player not found.");
            }
        }
    }

    public static void deletePlayerById(int playerId) throws SQLException {
        String sql = "DELETE FROM Players WHERE id_player = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, playerId);

            int rows = statement.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Player not found.");
            }
        }
    }

    public static boolean playerNumberExistsInTeam(int teamId, int number, Integer excludePlayerId) throws SQLException {
        StringBuilder sql = new StringBuilder("""
            SELECT id_player
            FROM Players
            WHERE id_comand = ?
              AND number = ?
            """);

        if (excludePlayerId != null) {
            sql.append(" AND id_player <> ? ");
        }

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            statement.setInt(1, teamId);
            statement.setInt(2, number);

            if (excludePlayerId != null) {
                statement.setInt(3, excludePlayerId);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public static String getUserRole(String username) throws SQLException {
        String sql = """
            SELECT user_role
            FROM AppUsers
            WHERE username = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("user_role");
                }
            }
        }

        return null;
    }

    public static boolean isUserActive(String username) throws SQLException {
        String sql = """
            SELECT is_active
            FROM AppUsers
            WHERE username = ?
            """;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getBoolean("is_active");
                }
            }
        }

        return false;
    }



}
