package com.example.footballproject.Controllers.MenuAdmins;

import com.example.footballproject.Controllers.Logins.DatabaseHandler;
import com.example.footballproject.Models.RefereeModel;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.SQLException;

public class RefereeDialogController {

    @FXML private TextField fullNameField;
    @FXML private TextField experienceYearsField;
    @FXML private TextField categoryField;

    private RefereeModel referee;
    private boolean saved;

    @FXML
    private void initialize() {
        onlyNumbers(experienceYearsField);
    }

    public void setReferee(RefereeModel referee) {
        this.referee = referee;

        if (referee == null) {
            return;
        }

        fullNameField.setText(referee.getFullName());
        experienceYearsField.setText(String.valueOf(referee.getExperienceYears()));
        categoryField.setText(referee.getCategory());
    }

    public boolean isSaved() {
        return saved;
    }

    private void onlyNumbers(TextField field) {
        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.matches("\\d*")) {
                field.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    @FXML
    private void saveReferee() {
        if (!validateFields()) {
            return;
        }

        String fullName = fullNameField.getText().trim();
        int experienceYears = experienceYearsField.getText().trim().isEmpty()
                ? 0
                : Integer.parseInt(experienceYearsField.getText().trim());
        String category = categoryField.getText() == null ? "" : categoryField.getText().trim();

        try {
            if (referee == null) {
                DatabaseHandler.addReferee(fullName, experienceYears, category);
            } else {
                DatabaseHandler.updateReferee(referee.getIdReferee(), fullName, experienceYears, category);
            }

            saved = true;
            closeWindow();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка сохранения", "Не удалось сохранить судью:\n" + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (fullNameField.getText() == null || fullNameField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Проверка", "Введите ФИО судьи.");
            return false;
        }

        if (experienceYearsField.getText() != null && !experienceYearsField.getText().trim().isEmpty()) {
            int experience = Integer.parseInt(experienceYearsField.getText().trim());
            if (experience < 0 || experience > 70) {
                showAlert(Alert.AlertType.WARNING, "Проверка", "Стаж судьи должен быть от 0 до 70 лет.");
                return false;
            }
        }

        return true;
    }

    @FXML
    private void cancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) fullNameField.getScene().getWindow();
        stage.close();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
