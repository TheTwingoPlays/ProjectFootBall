package com.example.footballproject.Models;

public enum CoachPosition {
    HEAD_COACH("Главный тренер"),
    ASSISTANT_COACH("Ассистент тренера"),
    GOALKEEPER_COACH("Тренер вратарей"),
    FITNESS_COACH("Тренер по физподготовке"),
    TACTICAL_COACH("Тактический тренер"),
    YOUTH_COACH("Молодёжный тренер");

    private final String title;

    CoachPosition(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return title;
    }
}
