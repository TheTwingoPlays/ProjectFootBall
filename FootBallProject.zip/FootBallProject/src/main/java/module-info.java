module com.example.footballproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.sql;

    opens com.example.footballproject to javafx.fxml;
    exports com.example.footballproject;

    exports com.example.footballproject.Controllers.Logins;
    opens com.example.footballproject.Controllers.Logins to javafx.fxml;

    opens com.example.footballproject.Controllers.MenuAdmins to javafx.fxml;
    exports com.example.footballproject.Controllers.MenuAdmins;

    requires jakarta.mail;
    requires jbcrypt;
    opens com.example.footballproject.Models to javafx.base;

    opens com.example.footballproject.Controllers.MenuUsers to javafx.fxml;
}
